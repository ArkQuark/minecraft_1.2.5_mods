This is the official Chococraft version 1.5.2 for usage with minecraft 1.2.4. Chococraft has been created by EddieV and is maintained by Torojima.

This version has a modified config file, so if you had run an older version of Chococraft before, the old config file should be deleted so this mod can create a new one.

see the minecraft forums for further informations
http://www.minecraftforum.net/topic/1119809-124-eddievs-chococraft-151-torojimas-official-update/

Torojima