Obsidian Ingots now runs on Forge!
*Mystery Update!*

3.1.5 change list:
*Tools can now be enchanted! Yay!
*Added configuration for SMP.
*Removed 'EnumObsidianToolMaterial' class.
*'BlockIronMain' is now 'BlockObsidian.'
*Fixed all tools, their efficiencies are better-fitting now.
*More bug fixes. That's it!

INSTRUCTIONS:

***
I expect you to have already installed Forge 1.2.5.
***
There will be one folder:
1. ObsidianIngots

PC:
AFTER INSTALLING FORGE:
Click on the 'Start' menu, and click run.  In run, type in, "%appdata%". From there, locate the .minecraft folder, and open the folder called "mods."  If it doesn't exist, just create it.  Now, place the "ObsidianIngots" folder directly into "mods." You can close out of all these windows now.  Run the game and you should be good to go!
***
Mac:
AFTER INSTALLING FORGE:
In finder, on the top toolbar, click on the 'Go' drop-down menu and then click 'Go to Folder.'  In that text box, type in "/Users/<username>/Library/Application Support".  Please note to type in your computer's username in the place where I said '<username>'.  From there, locate your 'minecraft' folder, and after opening it find the folder called "mods."  If it doesn't exist, just create it.  Now, place the "ObsidianIngots" folder directly into "mods."  Yay, you're finished!  Close out of all these windows now, and run Minecraft.  You should be good to go!

NOTE:
Be sure to not place the mod's folder's contents into "mods," place the entire folder in itself.
***
THIS MOD WORKS WITH ALL MODS I HAVE TESTED IT ON.
If a mod is INCOMPATIBLE with Obsidian Ingots, PM me with it's name.

If it doesn't work, please contact me at bradyaidanc@gmail.com.

Thank you for installing!


