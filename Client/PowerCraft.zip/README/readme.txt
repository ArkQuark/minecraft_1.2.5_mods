Installation:

1) get modlaoder working.
2) put this whole zip file into .minecraft/mods folder.


Properties (for id conflicts) are in /config folder, after 1st run.

its for singleplayer only.
all crashes can be solved using prop files.

this mod works with forge, but does not need it.


==== Credits ====

Coder: MightyPork [all modules] + Ercinee [improved conveyors and ACT]
Graphics: MightyPork
Debugger: MightyPork

suggestions and bug reports -> Sirlazer2, community

Apps used: KWrite, Geany, GIMP, MCP, JAD, JADGUI, Krusader

NO STEALING OR MOD-PACKING ALLOWED.
ALL RIGHTS RESERVED.

TESTED TO WORK WITH MINECRAFT 1.2.4
?FORGE COMPATIBLE.
?OPTIFINE COMPATIBLE.
?TMI COMPATIBLE (not all blocks available - bug in TMI)

Read license for more info about rights.
