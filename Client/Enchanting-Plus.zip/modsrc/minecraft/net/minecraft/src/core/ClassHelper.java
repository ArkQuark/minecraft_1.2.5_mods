package net.minecraft.src.core;

import java.lang.reflect.Field;
import java.lang.reflect.Method;

public class ClassHelper //Client Side
{
	public static Object getNewInstance(String s)
    {
    	Object obj = null;
    	try
    	{
    		Class class1 = getCorrectClass(s);
    		obj = class1.newInstance();
    	}
    	catch(Exception e)
    	{
    		e.printStackTrace();
    	}
    	return obj;
    }
    
    public static boolean findClass(String s)
    {
    	Class class1 = getCorrectClass(s);
    	if(class1 == null)
    	{
    		return false;
    	}
    	else
    	{
    		return true;
    	}
    }
    
    public static Class getCorrectClass(String s)
	{
		Class class1 = null;
		try
		{
			class1 = Class.forName("net.minecraft.src."+s);
		}
		catch(Exception e)
		{
			try
			{
				class1 = Class.forName(s);
			}
			catch(Exception e1)
			{
				e.printStackTrace();
			}
		}
		return class1;
	}
	
	public static Object getField(String s, Object obj, String s1)
	{
		Object obj1 = null;
		try
		{
			Field field = getCorrectClass(s).getDeclaredField(s1);
			field.setAccessible(true);
			obj1 = field.get(obj);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return obj1;
	}
	
	public static Object getField(String s, Object obj, int i)
	{
		try
		{
			Field field = getCorrectClass(s).getDeclaredFields()[i];
			field.setAccessible(true);
			return field.get(obj);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			return null;
		}
	}
	
	public static Object initiateMethod(String s, Object obj, String s1, Class aclass[], Object aobj[])
	{
		Object obj1 = null;
		try
		{
			Method method = getCorrectClass(s).getDeclaredMethod(s1, aclass);
			method.setAccessible(true);
			obj1 = method.invoke(obj, aobj);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return obj1;
	}
	
	public static Object initiateMethod(String s, Object obj, String s1, Object aobj[])
	{
		Object obj1 = null;
		try
		{
			Class aclass[] = new Class[aobj.length];
			for(int i = 0; i < aclass.length; i++)
			{
				aclass[i] = aobj[i].getClass();
			}
			Method method = getCorrectClass(s).getDeclaredMethod(s1, aclass);
			method.setAccessible(true);
			obj1 = method.invoke(obj, aobj);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return obj1;
	}
}