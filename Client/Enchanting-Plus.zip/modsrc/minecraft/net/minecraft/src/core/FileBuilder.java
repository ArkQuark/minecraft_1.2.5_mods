package net.minecraft.src.core;

import java.io.*;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;

/**
 * This is allowed to be packaged with a mod that uses this.
 * 
 * @author Gerald
 */
public class FileBuilder
{
	private static FileBuilder crashFile;
	private static FileBuilder logFile;
	public static ArrayList filesList = new ArrayList();
	private static boolean init = false;
	private String defaultPath;
	private int fileType;
	private String name;
	private String path;
	
	public boolean equals(Object obj)
	{
		if(!(obj instanceof FileBuilder))
		{
			return false;
		}
		else
		{
			FileBuilder builder = ((FileBuilder)obj);
			return path == builder.path && name == builder.name && fileType == builder.fileType && this.defaultPath == builder.defaultPath;
		}
	}
	
	private static void init()
	{
		if(!init)
		{
			init = true;
			logFile = new FileBuilder().setFolder("FileBuilder").setFileName("Logger File.txt");
			logFile.makeFile();
			logFile.flush();
			crashFile = new FileBuilder().setFolder("FileBuilder").setFileName("Crash File.txt");
			crashFile.makeFile();
			crashFile.flush();
		}
	}
	
	/**
	 * This determines if the FileBuilder exists.
	 * 
	 * @return - true if the FileBuilder exists
	 */
	public boolean exists()
	{
		return toFile().exists();
	}
	
	public String toString()
	{
		return getPath();
	}
	
	public boolean contains(String s)
	{
		return read(s) != null;
	}
	
	public boolean delete()
	{
		return toFile().delete();
	}
	
	/**
	 * Define the file with setFolder(String) (Optional) and setFileName(String) (Required), in that order.
	 * <p>
	 * The ID is set by what place the FileBuilder is loaded.
	 */
	public FileBuilder()
	{
		File file = null;
		try
		{
			file = (File)Class.forName("net.minecraft.client.Minecraft").getMethod("getMinecraftDir").invoke(null, new Object[]{});
		}
		catch(Exception e)
		{
			try {
				file = (File)Class.forName("net.minecraft.client.Minecraft").getMethod("b").invoke(null, new Object[]{});
			} catch (Exception e1) {
				e1.printStackTrace();
			}
		}

		defaultPath = file.getAbsolutePath();
		path = defaultPath;
		fileType = 0;
		filesList.add(this);
		return;
	}
	
	public FileBuilder(String s)
	{
		defaultPath = s;
		path = defaultPath;
		fileType = 0;
		filesList.add(this);
		return;
	}
	
	/**
	 * This sets the current FileBuilder to use DataStream as Input/Output
	 * 
	 * @return
	 */
	public FileBuilder setDataType()
	{
		fileType = 1;
		return this;
	}
	
	/**
	 * This must be used before writing to a FileBuilder or file outputs will be stacked
	 */
	public void flush()
	{
		PrintWriter print = getPrinter();
		print.flush();
	}
	
	/**
	 * Use this to return a byte from the files location.
	 * 
	 * @param arg - This is what you defined the string with writeReadable 
	 * @return - byte
	 */
	public byte getByte(String definer)
	{
		try
		{
			return Byte.parseByte(read(definer));
		}
		catch(NumberFormatException e)
		{
			return 0;
		}
	}
	
	/**
	 * Use this to return a boolean from the files location.
	 * 
	 * @param definer - This is what you defined the string with writeReadable 
	 * @return - boolean
	 */
	public boolean getBoolean(String definer)
	{
		return Boolean.parseBoolean(read(definer));
	}
	
	/**
	 * Use this to return a double from the files location.
	 * 
	 * @param definer - This is what you defined the string with writeReadable 
	 * @return - double
	 */
	public double getDouble(String definer)
	{
		try
		{
			return Double.parseDouble(read(definer));
		}
		catch(NumberFormatException e)
		{
			return 0;
		}
	}
	
	/**
	 * Use this to return a float from the files location.
	 * 
	 * @param definer - This is what you defined the string with writeReadable 
	 * @return - float
	 */
	public float getFloat(String definer)
	{
		try
		{
			return Float.parseFloat(read(definer));
		}
		catch(NumberFormatException e)
		{
			return 0;
		}
	}
	
	/**
	 * Use this to return a int from the files location.
	 * 
	 * @param definer - This is what you defined the string with writeReadable 
	 * @return - int
	 */
	public int getInt(String definer)
	{
		try
		{
			return Integer.parseInt(read(definer));
		}
		catch(NumberFormatException e)
		{
			return 0;
		}
	}
	
	/**
	 * Use this to return a long from the files location.
	 * 
	 * @param definer - This is what you defined the string with writeReadable 
	 * @return - long
	 */
	public long getLong(String definer)
	{
		try
		{
			return Long.parseLong(read(definer));
		}
		catch(NumberFormatException e)
		{
			return 0;
		}
	}
	
	/**
	 * Use this to return a short from the files location.
	 * 
	 * @param definer - This is what you defined the string with writeReadable 
	 * @return - short
	 */
	public short getShort(String definer)
	{
		try
		{
			return Short.parseShort(read(definer));
		}
		catch(NumberFormatException e)
		{
			return 0;
		}
	}
	
	/**
	 * Use this to return a String from the files location.
	 * 
	 * @param definer - This is what you defined the string with writeReadable 
	 * @return - String
	 */
	public String getString(String definer)
	{
		return read(definer);
	}
	
	/**
	 * Use this to get the default path for the current FileBuilder;
	 * 
	 * @return - String
	 */
	public String getDefaultPath()
	{
		return defaultPath;
	}
	
	/**
	 * Use this to get a FileBuilder from the FileBuilder's name.
	 * <p>
	 * Will return null if there is no FileBuilder with that name.
	 * 
	 * @param name - name
	 * @return - FileBuilder
	 */
	public static FileBuilder getFileBuilder(String name)
	{
		try
		{
			FileBuilder builder = null;
			for(int i = 0; i < filesList.size(); i++)
			{
				FileBuilder builder1 = ((FileBuilder)filesList.get(i));
				if(builder1 != null)
				{
					if(builder1.name != null)
					{
						if(builder1.name.equals(name))
						{
							builder = builder1;
						}
					}
				}
			}
			return builder;
		}
		catch(NullPointerException e)
		{
			e.printStackTrace(crashFile.getPrinter());
			return null;
		}
	}
	
	/**
	 * Use this to get the file name of the FileBuilder.
	 * 
	 * @return - String
	 */
	public String getName()
	{
		return name;
	}
	
	/**
	 * Use this to get the file path of the FileBuilder with "\" replaced with "/".
	 * 
	 * @return - String
	 */
	public String getPath()
	{
		return path.replace('\\', '/');
	}
	
	/**
	 * Use this to get the FileBuilder as a PrintWriter.
	 * 
	 * @return
	 */
	public PrintWriter getPrinter()
	{
		PrintWriter printer = null;
		try
		{
			printer = new PrintWriter(toFile());
		}
		catch(FileNotFoundException e)
		{
			e.printStackTrace();
		}
		return printer;
	}
	
	public BufferedReader getReader()
	{
		
		BufferedReader reader = null;
		try
		{
			FileReader filereader = new FileReader(toFile());
			reader = new BufferedReader(filereader);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return reader;
	}
	
	/**
	 * Use this to create a file as the FileBuilder's path.
	 * <p>
	 * If you are going to read from a file, do not use this when defineing it.
	 * 
	 * @return
	 */
	public boolean makeFile()
	{
		if(!init)
		{
			init();
		}
		if(name == null)
		{
			throw new IllegalArgumentException("Name is missing!");
		}
		File file = new File(path);
		try
		{
			return file.createNewFile();
		}
		catch(IOException e)
		{
			e.printStackTrace(crashFile.getPrinter());
			return false;
		}
	}
	
	/**
	 * This is for reading from a data file that is not have a associated FileBuilder instance.
	 * <p>
	 * This only works for files wrote to as Definer:Value.
	 * <p>
	 * This will only correctly work while parsing.
	 * 
	 * @param s - path from Minecraft Directory
	 * @param s1 - the definer
	 * @return String
	 */
	public static String readFromOldEncFile(String path, String definer)
	{
		String s3 = "";
		try
		{
			File file = new File(path);
			FileInputStream reader = new FileInputStream(file);
			DataInputStream dataIn = new DataInputStream(reader);
			for(String s2 = ""; (s2 = dataIn.readUTF()) != null;)
			{
				String[] as = s2.split(":");
				if(as[0].equals(definer))
				{
					s3 = as[1];
				}
			}
			dataIn.close();
		}
		catch(EOFException e)
		{
			System.out.println("File Ended!");
		}
		catch(IOException e)
		{
			e.printStackTrace(crashFile.getPrinter());
		}
		return s3;
	}
	
	public void remove(String s)
	{
		ArrayList<String> stringList = readAll();
		flush();
		for(String s1 : stringList)
		{
			String[] as = s1.split(":");
			if(!as[0].equals(s))
			{
				setString(as[0], as[1]);
			}
		}
	}
	
	public void replace(String s, String s1)
	{
		Object obj = read(s);
		remove(s);
		set(s1, obj);
	}
	
	/**
	 * This is for reading from a file that is not have a associated FileBuilder instance.
	 * <p>
	 * This only works for files wrote to as Definer:Value.
	 * <p>
	 * This will only correctly work while parsing.
	 * 
	 * @param s - path from minecraft dir
	 * @param s1 - the definer
	 * @return String
	 */
	public static String readFromOldFile(String path, String definer)
	{
		String name1 = null;
		try
		{
			BufferedReader br = new BufferedReader(new FileReader(new File(path)));
			for(String s2 = "";(s2 = br.readLine()) != null;)
			{
				String[] as = s2.split(":");
				if(as[0].equals(definer))
				{
					if(as[1].endsWith("L"))
					{
						as[1] = as[1].replace('L', ' ').trim();
					}
					if(as[1].endsWith("S"))
					{
						as[1] = as[1].replace('S', ' ').trim();
					}
					if(as[1].endsWith("I"))
					{
						as[1] = as[1].replace('I', ' ').trim();
					}
					if(as[1].endsWith("B"))
					{
						as[1] = as[1].replace('B', ' ').trim();
					}
					name1 = as[1];
				}
			}
			br.close();
		}
		catch(IOException e)
		{
			e.printStackTrace(crashFile.getPrinter());
		}
		return name1;
	}
	
	/**
	 * Use this to reset the path.
	 * <p>
	 * This would be used while changing paths from the same FileBuilder.
	 * 
	 */
	public void resetPath()
	{
		path = defaultPath;
	}	
	
	/**
	 * Use this to change the default path set for the current FileBuilder.
	 * <p>
	 * This is only used for <code>resetPath()<code>
	 * 
	 * @param s
	 */
	public FileBuilder setDefaultPath(String path)
	{
		defaultPath = path;
		return this;
	}
	
	public FileBuilder setDefaultPath()
	{
		defaultPath = path;
		return this;
	}
	
	/**
	 * This <b>is</b> required.
	 * <p>
	 * This defines the file name, end it with your file type, ex: File Manager.txt
	 * <p>
	 * If you try to create a file without a name, it <b>WILL</b> throw a error and crash.
	 * 
	 * @param s - File name
	 * @return
	 */
	public FileBuilder setFileName(String name)
	{
		this.name = name;
		path+="\\"+name;
		return this;
	}
	
	/**
	 * Use this to add a new folder to a FileBuilder's path, and if the folder does not exist, create it.  
	 * <p>
	 * Can be used in succession(multiple times).
	 * 
	 * @param s - Name of the folder to make.
	 * @return
	 */
	public FileBuilder setFolder(String name)
	{
		path+="\\"+name;
		File file = new File(path);
		file.mkdir();
		return this;
	}
	
	/**
	 * Use this to set the path of a FileBuilder.
	 * <p>
	 * This does <b>NOT</b> create the files in the path.
	 * 
	 * @param s
	 * @return
	 */
	public FileBuilder setPath(String path)
	{
		this.path = path;
		return this;
	}
	
	/**
	 * Get a instance of the FileBuilder as a file.
	 * 
	 * @return
	 */
	public File toFile()
	{
		return new File(path);
	}
	
	/**
	 * Use this to set a Byte value as the definer.
	 * 
	 * @param s - definer
	 * @param byte0 - value
	 */
	public void setByte(String s, Byte byte0)
	{
		set(s, byte0);
	}
	
	/**
	 * Use this to set a Boolean value as the definer.
	 * 
	 * @param s - definer
	 * @param b - value
	 */
	public void setBoolean(String s, Boolean b)
	{
		set(s, b);
	}
	
	/**
	 * Use this to set a Double value as the definer.
	 * 
	 * @param s - definer
	 * @param d - value
	 */
	public void setDouble(String s, Double d)
	{
		set(s, d);
	}
	
	/**
	 * Use this to set a Integer value as the definer.
	 * 
	 * @param s - definer
	 * @param i - value
	 */
	public void setInteger(String s, Integer i)
	{
		set(s, i);
	}
	
	/**
	 * Use this to set a Float value as the definer.
	 * 
	 * @param s - definer
	 * @param f - value
	 */
	public void setFloat(String s, Float f)
	{
		set(s, f);
	}
	
	/**
	 * Use this to set a Long value as the definer.
	 * 
	 * @param s - definer
	 * @param long0 - value
	 */
	public void setLong(String s, Long long0)
	{
		set(s, long0);
	}
	
	/**
	 * Use this to set a String value as the definer.
	 * 
	 * @param s - definer
	 * @param s1 - value
	 */
	public void setString(String s, String s1)
	{
		set(s, s1);
	}
	
	/**
	 * Use this to set a Short value as the definer.
	 * 
	 * @param s - definer
	 * @param short0 - value
	 */
	public void setShort(String s, Short short0)
	{
		set(s, short0);
	}
	
	/**
	 * Use this to write a comment to a file.
	 * 
	 * @param comment - Comment
	 * @param pound - true to include '#' at start of line.
	 */
	public void comment(String comment, boolean pound)
	{
		if(fileType == 0)
		{
			write(comment, null, pound);
		}
		else
		{
			throw new IllegalArgumentException("Cannot write a comment to a data file.");
		}
	}
	
	private void set(String s, Object o)
	{
		ArrayList<String> list = readAll();
		flush();
		for(String s1 : list)
		{
			if(s1.startsWith("#"))
			{
				continue;
			}
			String as[] = s1.split(":");
			if(as[0].equals(s))
			{
				continue;
			}
			write(as[0], as[1], false);
		}
		write(s, o, false);
	}
	
	public ArrayList<String> readAll()
	{
		ArrayList arraylist = new ArrayList();
		if(fileType == 1)
		{
			try
			{
				if(exists())
				{
					DataInputStream data = new DataInputStream(new FileInputStream(toFile()));
					for(String s = ""; (s = data.readUTF()) != null; )
					{
						arraylist.add(s);
					}
					data.close();
				}
			}
			catch(IOException e)
			{
				e.printStackTrace(crashFile.getPrinter());
			}
		}
		else if(fileType == 0)
		{
			try
			{
				if(exists())
				{
					BufferedReader br = new BufferedReader(new FileReader(toFile()));
					for(String s = "";(s = br.readLine()) != null; )
					{
						if(s.contains("#"))
						{
							continue;
						}
						arraylist.add(s);
					}
					br.close();
				}
			}
			catch(IOException e)
			{
				e.printStackTrace(crashFile.getPrinter());
			}
		}
		return arraylist;
	}

	private String read(String arg)
	{
		if(!init)
		{
			init();
		}
		if(fileType == 1)
		{
			String s1 = null;
			try
			{
				DataInputStream dataIn = new DataInputStream(new FileInputStream(toFile()));
				for(String s2 = ""; (s2 = dataIn.readUTF()) != null;)
				{
					String[] as = s2.split(":");
					if(as[0].equals(arg))
					{
						s1 = as[1];
					}
				}
				dataIn.close();
			}
			catch(EOFException e)
			{
			}
			catch(IOException e)
			{
				e.printStackTrace(crashFile.getPrinter());
			}
			return s1;
		}
		else if(fileType == 0)
		{
			String name1 = null;
			try
			{
				if(toFile().exists())
				{
					BufferedReader br = new BufferedReader(new FileReader(toFile()));
					for(String s = "";(s = br.readLine()) != null;)
					{
						String[] as = s.split(":");
						if(as[0].equals(arg))
						{
							name1 = as[1];
						}
					}
					br.close();
				}
			}
			catch(IOException e)
			{
				e.printStackTrace(crashFile.getPrinter());
			}
			return name1;
		}
		else
		{
			return null;
		}
	}
	
	private void write(String s, Object o, boolean flag)
	{
		if(!init)
		{
			init();
		}
		if(fileType == 1)
		{
			try
			{
				DataOutputStream out = new DataOutputStream(new FileOutputStream(path, true));
				String str = new StringBuilder().append(s).append(":").append(o).toString();
				out.writeUTF(str);
				out.close();
			}
			catch(IOException e)
			{
				e.printStackTrace(crashFile.getPrinter());
			}
		}
		else if(fileType == 0)
		{
			try
			{
				PrintWriter print = new PrintWriter(new FileWriter(path, true));
				if(o == null && flag == false)
				{
					print.printf("%s"+"%n", s);
				}
				else if(o == null && flag == true)
				{
					print.printf("%s"+"%n", "#"+s);
				}
				else
				{
					print.printf("%s"+"%n", s+":"+o);
				}
				print.close();
			}
			catch(IOException e)
			{
				e.printStackTrace(crashFile.getPrinter());
			}
		}
		if(!equals(logFile) && o != null)
		{
			logFile.comment(new StringBuilder().append("Writing ").append(o.getClass().getSimpleName()).append(" as ").append(s).append(" from file: ").append(name).toString(), false);
		}
	}
	
	public FileBuilder copy()
	{
		FileBuilder filebuilder = new FileBuilder();
		filebuilder.defaultPath = defaultPath;
		filebuilder.fileType = fileType;
		filebuilder.name = name;
		filebuilder.path = path;
		return filebuilder;
	}
}