package net.minecraft.src.eplus;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import net.minecraft.src.Block;
import net.minecraft.src.Enchantment;
import net.minecraft.src.EnchantmentData;
import net.minecraft.src.EntityPlayer;
import net.minecraft.src.EnumRarity;
import net.minecraft.src.Item;
import net.minecraft.src.ItemStack;
import net.minecraft.src.NBTTagCompound;
import net.minecraft.src.forge.EnumHelper;
import net.minecraft.src.forge.ITextureProvider;

public class ItemEnchantmentBook extends Item
{
	public ItemEnchantmentBook(int par1) 
	{
		super(par1);
		setHasSubtypes(true);
		setMaxStackSize(1);
		setItemName("enchantmentBook");
		setTextureFile("/eplus/resources/items.png");
	}
	
	public String getItemNameIS(ItemStack var1)
	{
		return getItemName() + "." + var1.getItemDamage();
	}
	
	public void addInformation(ItemStack var1, List var2)
	{
		if(var1.getItemDamage() < 256)
		{
			return;
		}
		var2.add(String.valueOf("Tier "+ getData(var1).enchantmentLevel) + " enchantment");
	}
	
	public int getColorFromDamage(int par1, int par2)
	{
		return 0xab5 + (par1 * 42326);
	}
	
	public void addCreativeItems(ArrayList items)
	{
		for(Enchantment e : Enchantment.enchantmentsList)
		{
			if(e == null)
			{
				continue;
			}
			for(int i = 1; i < e.getMaxLevel() + 1; i++)
			{
				ItemStack stack = new ItemStack(this, 1, getDamage(e, i));
				if(getData(stack) != null)
				{
					items.add(new ItemStack(this, 1, getDamage(e, i)));
				}
			}
		}
	}
	
	public EnumRarity getRarity(ItemStack var1)
	{
		float enchantRarity = ((float)getData(var1).enchantmentLevel / (float)getData(var1).enchantmentobj.getMaxLevel());
		int itemRarity = (int)(((float)EnumRarity.values().length * enchantRarity));
		return EnumRarity.values()[Math.max(0, itemRarity - 1)];
	}
	
	public boolean hasEffect(ItemStack var1)
	{
		return true;
	}
	
	public static EnchantmentData getData(ItemStack var1)
	{
		if(var1.getItemDamage() < 256)
		{
			return null;
		}
		int var2 = var1.getItemDamage() - 256;
		Enchantment e = Enchantment.enchantmentsList[var2 % 256];
		int tier = var2 / 256;
		return new EnchantmentData(e, tier);
	}
	
	public static int getDamage(Enchantment e, int tier)
	{
		int effectID = e.effectId;
		return 256 + (256 * tier) + e.effectId;
	}
}