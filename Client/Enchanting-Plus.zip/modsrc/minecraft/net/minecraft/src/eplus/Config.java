package net.minecraft.src.eplus;

import java.io.File;

import net.minecraft.client.Minecraft;
import net.minecraft.src.Block;
import net.minecraft.src.Enchantment;
import net.minecraft.src.Item;
import net.minecraft.src.ItemStack;
import net.minecraft.src.ModLoader;
import net.minecraft.src.mod_EnchantingPlus;
import net.minecraft.src.forge.Configuration;
import net.minecraft.src.forge.MinecraftForge;
import net.minecraft.src.forge.Property;

public class Config
{
	public static Configuration config;

	public static Block enchantmentTablePlus;
	
	public static Item enchantItem;
	
	public static boolean guiOnly;
	
	public static void initiateConfig()
	{
		config = new Configuration(new File(Minecraft.getMinecraftDir(), "config/ePlus.cfg"));
		config.load();
		
		//Items
		
		Property scroll1Id = config.getOrCreateIntProperty("Enchantment Book", "item", 15090);
		scroll1Id.comment = "This is for every item related the the Enchantment Books";
		
		//General
		
		Property guiOnlyBoolean = config.getOrCreateBooleanProperty("GUI Only", "general", false);
		guiOnlyBoolean.comment = "This, if set to 'true', will only add the Enchantment Table Plus and nothing else. Be careful with this, if you set this to 'true' and load a world with items from this mod in it, you may lose them.";
		guiOnly = guiOnlyBoolean.getBoolean(false);
		
		Property guiEnchantID = config.getOrCreateIntProperty("Enchantment Plus GUI ID", "general", 94);
		guiEnchantID.comment = "This is the ID of the Enchantment Plus GUI";
		
		Block.blocksList[116] = null;
		enchantmentTablePlus = (new BlockEnchantmentTablePlus(116)).setHardness(5.0F).setResistance(2000.0F).setBlockName("enchantmentTablePlus");
		ModLoader.addName(enchantmentTablePlus, "Enchantment Table Plus");
		ModLoader.registerBlock(enchantmentTablePlus);
		
		if(!guiOnly)
		{
			enchantItem = new ItemEnchantmentBook(scroll1Id.getInt()).setIconIndex(1).setItemName("enchantBook");
			for(Enchantment e : Enchantment.enchantmentsList)
			{
				if(e == null)
				{
					continue;
				}
				String eName = e.getTranslatedName(1);
				String name = (String) eName.subSequence(0, eName.length() - 2);
				for(int i = 0; i < e.getMaxLevel(); i++)
				{
					ItemStack stack = new ItemStack(enchantItem, 1, ItemEnchantmentBook.getDamage(e, i + 1));
					ModLoader.addName(stack, "Book of " + name);
				}
			}
		}
		config.save();
	}
}