package net.minecraft.src.eplus;

import org.lwjgl.opengl.GL11;

import net.minecraft.client.Minecraft;
import net.minecraft.src.Enchantment;
import net.minecraft.src.EnchantmentData;
import net.minecraft.src.Gui;

public class GuiDisenchantmentItem extends Gui
{
	public static int startingX;
	public static int startingY;
	public Enchantment type;
	public int level;
	public int hiddenLevel;
	public int shelves;
	public int xPos;
	public int yPos;
	public int width;
	public int height;
	public boolean draw;
	public boolean enabled;
	
	public GuiDisenchantmentItem(Enchantment var1, int var2, int var3, int var4, int var5)
	{
		type = var1;
		level = 0;
		hiddenLevel = var2;
		shelves = var5;
		xPos = var3 + startingX;
		yPos = var4 + startingY;
		width = 144;
		height = 18;
		draw = true;
		enabled = true;
	}
	
	public void draw(Minecraft var1, int var2, int var3)
	{
		if(!draw)
		{
			return;
		}
		GL11.glDisable(GL11.GL_LIGHTING);
        GL11.glDisable(GL11.GL_DEPTH_TEST);
		int var4 = var1.renderEngine.getTexture("/eplus/resources/icons.png");
		var1.renderEngine.bindTexture(var4);
		GL11.glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
		byte var5 = 0;
		int var6 = 0x7E3517;
		if(enabled)
		{
			if(isMouseOver(var2, var3))
			{
				var5 = 3;
				var6 = 0xC38EC7;
			}
			else if(level > 0)
			{
				var5 = 2;
				var6 = 0x7E3117;
			}
		}
		else
		{
			var5 = 1;
			var6 = 0x465E41;
		}
		this.drawTexturedModalRect(xPos, yPos, 0, 18 * var5, width, height);
		String var7 = type.getTranslatedName(level);
		if(level == 0)
		{
			var7= var7.substring(0, var7.lastIndexOf(" "));
		}
		var1.fontRenderer.drawString(var7, xPos + width / 2 - var1.fontRenderer.getStringWidth(var7) / 2, yPos + height / 2 - 4, var6);
	}
	
	public boolean isMouseOver(int var1, int var2)
	{
		return draw && enabled && var1 >= xPos && var2 >= yPos && var1 < xPos + width && var2 < yPos + height;
	}
	
	public void press()
	{
		if(level == 0)
		{
			level = hiddenLevel;
		}
		else
		{
			level = 0;
		}
	}
}