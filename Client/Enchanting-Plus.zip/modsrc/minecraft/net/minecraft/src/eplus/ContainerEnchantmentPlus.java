package net.minecraft.src.eplus;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

import net.minecraft.src.Block;
import net.minecraft.src.core.ClassHelper;
import net.minecraft.src.Container;
import net.minecraft.src.Enchantment;
import net.minecraft.src.EnchantmentData;
import net.minecraft.src.EntityPlayer;
import net.minecraft.src.ItemStack;
import net.minecraft.src.NBTTagCompound;
import net.minecraft.src.NBTTagList;
import net.minecraft.src.Slot;
import net.minecraft.src.World;
import net.minecraft.src.mod_EnchantingPlus;

public class ContainerEnchantmentPlus extends Container
{
	public int xPosition;
	public int yPosition;
	public int zPosition;
	public World gameWorld;
	public int serverShelves;
	
	public ContainerEnchantmentPlus(EntityPlayer var1, int var2, int var3, int var4)
	{
		xPosition = var2;
		yPosition = var3;
		zPosition = var4;
		gameWorld = var1.worldObj;
		addSlot(new Slot(new InventoryEnchantmentPlus(this, "Action", 1), 0, 11, 31));
		addSlot(new Slot(new InventoryEnchantmentPlus(this, "Transformer", 1), 0, 11, 57));
		for (int var5 = 0; var5 < 3; ++var5)
        {
            for (int var6 = 0; var6 < 9; ++var6)
            {
                this.addSlot(new Slot(var1.inventory, var6 + var5 * 9 + 9, 17 + var6 * 18, 147 + var5 * 18));
            }
        }
		for (int var5 = 0; var5 < 9; ++var5)
        {
            this.addSlot(new Slot(var1.inventory, var5, 17 + var5 * 18, 205));
        }
	}

	@Override
	public boolean canInteractWith(EntityPlayer var1) {
		return true;
	}
	
	public void retrySlotClick(int var1, int var2, boolean var3, EntityPlayer var4){}
	
	public boolean canSetStack(ItemStack var2)
	{
		if(mod_EnchantingPlus.isItemEnchantedBook(var2) && !getSlot(1).getHasStack())
		{
			return true;
		}
		if(getSlot(0).getStack() != null && getSlot(1).getStack() != null)
		{
			return false;
		}
		else if(!var2.getItem().isItemTool(var2))
		{
			return false;
		}
		else
		{
			return true;
		}
	}
	
	public int getTotalBookshelves()
    {
        int i = 0;
        if(gameWorld.isRemote)
        {
        	return serverShelves;
        }
        for (int j = -1; j <= 1; j++)
        {
            for (int k = -1; k <= 1; k++)
            {
                if (j == 0 && k == 0 || !gameWorld.isAirBlock(xPosition + k, yPosition, zPosition + j) || !gameWorld.isAirBlock(xPosition + k, yPosition + 1, zPosition + j))
                {
                    continue;
                }
                if (gameWorld.getBlockId(xPosition + k * 2, yPosition, zPosition + j * 2) == Block.bookShelf.blockID)
                {
                    i++;
                }
                if (gameWorld.getBlockId(xPosition + k * 2, yPosition + 1, zPosition + j * 2) == Block.bookShelf.blockID)
                {
                    i++;
                }
                if (k == 0 || j == 0)
                {
                    continue;
                }
                if (gameWorld.getBlockId(xPosition + k * 2, yPosition, zPosition + j) == Block.bookShelf.blockID)
                {
                    i++;
                }
                if (gameWorld.getBlockId(xPosition + k * 2, yPosition + 1, zPosition + j) == Block.bookShelf.blockID)
                {
                    i++;
                }
                if (gameWorld.getBlockId(xPosition + k, yPosition, zPosition + j * 2) == Block.bookShelf.blockID)
                {
                    i++;
                }
                if (gameWorld.getBlockId(xPosition + k, yPosition + 1, zPosition + j * 2) == Block.bookShelf.blockID)
                {
                    i++;
                }
            }
        }
        return i;
    }
	
	public boolean doEnchantment(EntityPlayer entityplayer, List list, int i, boolean flag)
    {
        ItemStack itemstack = ((Slot)inventorySlots.get(0)).getStack();

        if (!entityplayer.worldObj.isRemote && list != null)
        {
        	if(!flag)
        	{
        		entityplayer.removeExperience(i);
        	}
            EnchantmentData enchantmentdata;

            for (Iterator iterator = list.iterator(); iterator.hasNext(); addEnchantmentData(itemstack, enchantmentdata))
            {
                enchantmentdata = (EnchantmentData)iterator.next();
            }

            return true;
        }
        else
        {
            return false;
        }
    }
    
    public boolean doDisenchant(EntityPlayer entityplayer, List list, int i, boolean flag)
    {
    	ItemStack itemstack = ((Slot)inventorySlots.get(0)).getStack();
    	
    	if(!entityplayer.worldObj.isRemote)
    	{
    		if(!flag)
    		{
    			for(int j = 0; j < i; j++)
    			{
    		    	entityplayer.experienceLevel++;
    		    	entityplayer.experienceTotal++;
    			}
    		}
    		EnchantmentData enchantmentdata;
    		
    		for(Iterator iterator = list.iterator(); iterator.hasNext(); removeEnchantment(itemstack, enchantmentdata.enchantmentobj))
    		{
    			enchantmentdata = (EnchantmentData)iterator.next();
    		}
    		return true;
    	}
    	else
    	{
    		return false;
    	}
    }
    
    public boolean doRepair(EntityPlayer entityplayer, int i, boolean flag)
    {
    	ItemStack itemstack = ((Slot)inventorySlots.get(0)).getStack();
    	
    	if(!entityplayer.worldObj.isRemote)
    	{
    		if(!flag)
    		{
    			entityplayer.removeExperience(i);
    		}
    		
    		itemstack.setItemDamage(0);
    		return true;
    	}
    	else
    	{
    		return false;
    	}
    }
    
    public boolean doTransfer(EntityPlayer entityplayer, int i, boolean flag)
    {
    	ItemStack itemstack = ((Slot)inventorySlots.get(0)).getStack();
    	ItemStack itemstack1 = ((Slot)inventorySlots.get(1)).getStack();
    	
    	if(!entityplayer.worldObj.isRemote)
    	{
    		if(!flag)
    		{
    			entityplayer.removeExperience(i);
    		}
    		ArrayList<EnchantmentData> list = new ArrayList();
			if(mod_EnchantingPlus.isItemEnchantedBook(itemstack1))
			{
				list.add(ItemEnchantmentBook.getData(itemstack1));
				((Slot)inventorySlots.get(1)).putStack(null);
			}
			else
			{
				for(int j = 0; j < itemstack1.getEnchantmentTagList().tagCount(); j++)
				{
					NBTTagCompound nbt = (NBTTagCompound)itemstack1.getEnchantmentTagList().tagAt(j);
					int k = nbt.getShort("id");
					int l = nbt.getShort("lvl");
					list.add(new EnchantmentData(Enchantment.enchantmentsList[k], l));
				}
				for(EnchantmentData data : list)
				{
					removeEnchantment(itemstack1, data.enchantmentobj);
				}
			}
			for(EnchantmentData data : list)
			{
				addEnchantmentData(itemstack, data);
			}
			return true;
    	}
		else
		{
			return false;
		}
    }

    public void addEnchantmentData(ItemStack itemstack, EnchantmentData enchantmentdata)
    {
        if (itemstack.stackTagCompound == null)
        {
            itemstack.setTagCompound(new NBTTagCompound());
        }

        if (!itemstack.stackTagCompound.hasKey("ench"))
        {
            itemstack.stackTagCompound.setTag("ench", new NBTTagList("ench"));
        }

        NBTTagList nbttaglist = (NBTTagList)itemstack.stackTagCompound.getTag("ench");
        NBTTagCompound nbttagcompound = new NBTTagCompound();
        nbttagcompound.setShort("id", (short)enchantmentdata.enchantmentobj.effectId);
        nbttagcompound.setShort("lvl", (byte)enchantmentdata.enchantmentLevel);
        nbttagcompound.setByte("bs", (byte)getTotalBookshelves());
        nbttaglist.appendTag(nbttagcompound);
    }
    
    public void removeEnchantment(ItemStack itemstack, Enchantment enchantment)
    {
    	if(itemstack.stackTagCompound == null)
    	{
    		throw new IllegalArgumentException("The item must be enchanted!");
    	}
    	
    	if(!itemstack.stackTagCompound.hasKey("ench"))
    	{
    		throw new IllegalArgumentException("The item must be enchanted!");
    	}
    	
    	NBTTagList nbttaglist = (NBTTagList)itemstack.stackTagCompound.getTag("ench");
    	NBTTagList nbttaglist1 = new NBTTagList();
    	for(int i = 0; i < nbttaglist.tagCount(); i++)
    	{
    		NBTTagCompound nbttagcompound = (NBTTagCompound)nbttaglist.tagAt(i);
    		short short0 = nbttagcompound.getShort("id");
    		if(short0 != enchantment.effectId)
    		{
    			nbttaglist1.appendTag(nbttagcompound);
    		}
    	}
    	itemstack.stackTagCompound.setTag("ench", nbttaglist1);
    	if(itemstack.getEnchantmentTagList().tagCount() == 0)
    	{
    		HashMap map = (HashMap)ClassHelper.getField(itemstack.stackTagCompound.getClass().getSimpleName(), itemstack.stackTagCompound, 0);
    		map.remove("ench");
    	}
    }
	
}