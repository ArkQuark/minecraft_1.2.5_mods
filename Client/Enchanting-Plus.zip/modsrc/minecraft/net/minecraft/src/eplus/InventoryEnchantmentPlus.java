package net.minecraft.src.eplus;

import net.minecraft.src.InventoryBasic;

public class InventoryEnchantmentPlus extends InventoryBasic
{
	final ContainerEnchantmentPlus container;
	
	public InventoryEnchantmentPlus(ContainerEnchantmentPlus var1, String par2Str, int par3) {
		super(par2Str, par3);
		container = var1;
	}
	
	public int getInventoryStackLimit()
	{
		return 1;
	}
}