package net.minecraft.src.eplus;

import java.util.Random;

import net.minecraft.src.*;

public class BlockEnchantmentTablePlus extends BlockContainer
{
	public BlockEnchantmentTablePlus(int i)
	{
		super(i, 166, Material.rock);
        this.setBlockBounds(0.0F, 0.0F, 0.0F, 1.0F, 0.75F, 1.0F);
        this.setLightOpacity(0);
	}
	
	public boolean renderAsNormalBlock()
    {
        return false;
    }
	
	public void randomDisplayTick(World par1World, int par2, int par3, int par4, Random par5Random)
    {
        super.randomDisplayTick(par1World, par2, par3, par4, par5Random);

        for (int var6 = par2 - 2; var6 <= par2 + 2; ++var6)
        {
            for (int var7 = par4 - 2; var7 <= par4 + 2; ++var7)
            {
                if (var6 > par2 - 2 && var6 < par2 + 2 && var7 == par4 - 1)
                {
                    var7 = par4 + 2;
                }

                if (par5Random.nextInt(16) == 0)
                {
                    for (int var8 = par3; var8 <= par3 + 1; ++var8)
                    {
                        if (par1World.getBlockId(var6, var8, var7) == Block.bookShelf.blockID)
                        {
                            if (!par1World.isAirBlock((var6 - par2) / 2 + par2, var8, (var7 - par4) / 2 + par4))
                            {
                                break;
                            }

                            par1World.spawnParticle("enchantmenttable", (double)par2 + 0.5D, (double)par3 + 2.0D, (double)par4 + 0.5D, (double)((float)(var6 - par2) + par5Random.nextFloat()) - 0.5D, (double)((float)(var8 - par3) - par5Random.nextFloat() - 1.0F), (double)((float)(var7 - par4) + par5Random.nextFloat()) - 0.5D);
                        }
                    }
                }
            }
        }
    }
	
	public boolean isOpaqueCube()
    {
        return false;
    }
	
	public int getBlockTextureFromSideAndMetadata(int par1, int par2)
    {
        return this.getBlockTextureFromSide(par1);
    }
	
	public int getBlockTextureFromSide(int par1)
    {
        return par1 == 0 ? this.blockIndexInTexture + 17 : (par1 == 1 ? this.blockIndexInTexture : this.blockIndexInTexture + 16);
    }
	
	public TileEntity getBlockEntity()
    {
        return new TileEntityEnchantmentTable();
    }
	
	public boolean blockActivated(World par1World, int par2, int par3, int par4, EntityPlayer par5EntityPlayer)
    {
        if (par1World.isRemote)
        {
        	return true;
        }
        else
        {
        	ModLoader.openGUI(par5EntityPlayer, new GuiEnchantmentPlus(par5EntityPlayer, par2, par3, par4));
        	return true;
        }
    }
	
	public BlockEnchantmentTablePlus setHardness(float var1)
	{
		super.setHardness(var1);
		return this;
	}
	
	public BlockEnchantmentTablePlus setResistance(float var1)
	{
		super.setResistance(var1);
		return this;
	}
}