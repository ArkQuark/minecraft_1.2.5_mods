package net.minecraft.src;

import net.minecraft.client.Minecraft;
import net.minecraft.src.eplus.Config;
import net.minecraft.src.eplus.ItemEnchantmentBook;
import net.minecraft.src.forge.NetworkMod;

public class mod_EnchantingPlus extends NetworkMod
{	
	public static boolean useModdedGui = false;
	
	public String getVersion() 
	{
		return "1.0b";
	}
	
	public void load() 
	{
		ModLoader.setInGameHook(this, true, true);
		Config.initiateConfig();
	}
	
	public boolean onTickInGame(float var1, Minecraft var2)
	{
		if(!var2.isMultiplayerWorld())
		{
			useModdedGui = true;
		}
		return true;
	}
	
	public static boolean isItemEnchantedBook(ItemStack var1)
	{
		return var1.getItem() instanceof ItemEnchantmentBook && var1.getItemDamage() > 256;
	}
}