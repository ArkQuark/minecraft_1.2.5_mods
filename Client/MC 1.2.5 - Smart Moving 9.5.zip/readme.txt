================
Smart Moving Mod
================

Version 9.5 for Minecraft Client 1.2.5

by Divisor



Description
===========

The Smart moving mod provides various additionaly moving possibilities:

* Climbing only via gaps in the walls
* Climbing ladders with different speeds depending on ladder coverage and/or neighbour blocks
* Alternative animations for flying and falling
* Climbing along ceilings and up vines
* Jumping up & back while climbing
* Configurable sneaking
* Alternative swimming
* Alternative diving
* Alternative flying
* Faster sprinting
* Side & Back jumps
* Charged jumps
* Head jumps
* Crawling
* Sliding

Exact behavior depends on configuration (see chapter 'Configuration' below)



Required Mods
=============

The ModLoader client installation package requires

    * either ModLoader or Minecraft Forge and
    * Player API client 1.0 or higher

to be installed too. Additionally

    * Render Player API 1.1 or higher

can be installed to improve the compatibiltity to other mods.


The stand alone client installation packages do not need any other mods to be installed.



Installation
============

Installation varies depending on your minecraft installation.
So choose your package and install it - do NOT install more than one package.

In any case, NEVER forget: ALWAYS back up your stuff!


Standalone
----------
* Your minecraft installation does not use any mod management system.
* You don't care about other mods, you just want to smart move while playing Minecraft.

Copy all files inside one of the included "Standalone" zip packages to their corresponding locations in your "Minecraft.jar" in your "/.minecraft/bin/".
Do not forget to delete the "META-INF" directory while you are at it.

Choosing the package depends on the other mods you want to be installed in your "Minecraft.jar".

The standalone package "Minecraft-adl-ki-rk" overwrites the files "net/minecraft/client/Minecraft.class", "ki.class" and "rk.class".
The standalone package "hu-oe-vq" overwrites the files "hu.class" and "vq.class".

Each package should not be combined with other mods that overwrite any of its corresponding files.


ModLoader
---------
* You are allready playing minecraft using either Minecraft Forge or Risugamis ModLoader.
* You don't use any of them but you might want to install other mods in the future.

Move the contents of the Smart Moving installation package "Smart Moving Client for ModLoader.zip" to their corresponding locations in your "Minecraft.jar" in your "/.minecraft/bin/".

Don't forget to:
* ensure you have the mod Player API installed!
* ensure you have the latest version of Minecraft Forge or Risugamis ModLoader installed!



Configuration
=============

The file "smart_moving_options.txt" can be used to configure the behavior this mod.
It is located in your ".minecraft" folder next to minecrafts "options.txt".
If does not exist at Minecraft startup time it is automatically generated.

You can use its content to manipulate this mod's various features.
