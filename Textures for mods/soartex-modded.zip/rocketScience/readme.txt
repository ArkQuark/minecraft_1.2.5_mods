Rocket Science Texture Pack 64x64p.
Items = 32x32p 

by redled72 -> http://www.youtube.com/user/Redled72

Feedback to Youtube-Channel.

Changelog:
----------

Ver. 1.2.3
- Edit new Blocks (Offence, Defence etc.) for better Look

Ver.1.2.2
- Update to Rocket Science 0.89
- Add new Block-Textures (Laser, Offence, Defence)

Ver. 1.2
- edit blocks for better Rockets & Maschines

Ver. 1.1
- edit items for better look

Ver. 1.0a 
- Initial Release
  



