"Transformers 1.2" Texture Pack 64x64p.

by redled72 -> http://www.youtube.com/user/Redled72

1. Installation:
-------------
Extract the Content (all .png) from Archiv to TransformersClient v1.2.zip

Feedback to Youtube-Channel.

Changelog:
----------

Ver. 1.0 for Transformers v.1.2




