BY jmittsch
Credits:

I'll give credits to MrCrayFish for his very good furniture mod and Soartex an his/her team for the great texture pack!



Additional:

download soartex texture pack at:
http://soartex.net/

(C) jmittsch