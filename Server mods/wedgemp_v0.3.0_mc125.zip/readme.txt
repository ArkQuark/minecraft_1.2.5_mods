WorldGenEditMP (WedgeMP) for Minecraft 1.2.5 version 0.3.0 pre1
                      by Ryan "UMM" Holtz

          TABLE OF CONTENTS
-------------------------------------

1.........................About Wedge
2....................How To Use Wedge
3.................Contact Information



             ABOUT WEDGE
-------------------------------------

WorldGenEdit, or Wedge, is a world generation toolkit for Minecraft. It allows
the user to create a custom world, editing nearly every parameter pertaining to
the default "Surface" terrain generator. Wedge also has a handy preview window
for previewing a few chunks of a given set of terrain settings without needing
to create an entirely new world, which is useful given the odd nature of many
of the given settings.

Wedge will eventually extend into tweaking BiomeGen settings as well, and in
time, the creation and modification of tree generators, cave generators, and
other features involved in Minecraft's auto-generated terrain.



          HOW TO USE WEDGE
-------------------------------------

Install the latest version of ModLoader, then install Wedge. It edits only one
base class, limiting itself to WorldProviderSurface, which is hopefully
esoteric enough that major utility such as Optifine don't collide. It is also
designed such that if installed after Forge, it will not collide.

Jot down your preferred values from the Client version of Wedge and plug them
into the correspondingly-named (sort of) variables mod_Wedge.ini, then generate
a new world. Enjoy.



        CONTACT INFORMATION
-------------------------------------

AIM: mega64man1
IRC: irc.esper.net, UltraMoogleMan
E-Mail: rholtz at batcountryentertainment beans dot com, hold the beans

- UMM, 10 Apr. 2012