BigTrees (server) 1.2.5
A Minecraft mod by Karob.
Site: http://www.minecraftforum.net/index.php?showtopic=782646

Installation
""""""""""""
1) Backup minecraft-server.jar and all data you don't want corrupted. (Suggested)
2) Start with a fresh, clean, mod-free minecraft-server.jar. (May not be necessary.)
3) Open minecraft-server.jar and BigTrees-server-1.2.5.zip with an appropriate archiver.
4) Copy all files directly from the "jar" folder of BigTrees-server-1.2.5.zip to minecraft-server.jar.
5) If you want to be able to change the configuration file, copy kbigtrees.txt to the folder that minecraft-server.jar is in.
6) Start the server.
7) Play Minecraft!

You may be asking one of the following questions:
- What is an appropriate archiver?
    In Windows, 7-Zip is a good free one. Not all free archivers will work
    properly, but 7-Zip has worked every time for me. In Linux everything
    seems to work fine. :)
- Is this compatible with other mods?
    It is compatible with some mods. It really depends on what classes are
    modified and how critical they are. If you want to try this mod with
    another, try installing one of them first. If that doesn't work, try
    installing the other first. Further down is a list of possibly
    compatible mods.

Features
""""""""
- Big trees added to different biomes:
   * Most biomes have Great Oak, Thick Pine, Block Oak, and Post Oak.
   * Desert has big dead trees. It may not make sense, but it looks cool. :)
   * Swamp biome has Great Swamp Oak, Cyprus, and Hat Trees.
   * Taiga biome has Thick Pine in some regions.
   * The classic birch and pine trees are taller.
   * Jungle trees are taller and have longer branches.
- Roots from some trees grow through ground, sometimes into caves.
- Place sapling and blocks in patterns to choose what sort of tree grows there. (See below)
- Config file 'kbigtrees.txt' allows for changing many things.
- New look, same great taste!

Tree Growth Guide
"""""""""""""""""
To grow a tree of any of these types, place saplings and wood blocks in these
patterns. There must be an air block over each wood block. The wood blocks
must be the same elevation as the sapling.

    [o = sapling (any type), w = wood (any type)]

        w w                             w w w w
      w w w w      w w         w        w w w w
      w w w w      w w           o      w w w w
        w w o          o                w w w o
      -------    -------  ---------    ---------
     great oak  block oak  post oak    swamp oak

              w      w     w     w w
            w w w      w w     w     w
              w o      w w     w     w
                     w     o     w w o
          --------   ------   ---------
         thick pine  cyprus    hat tree

Two new patterns added by request:

       w
       w             w
       w             w
 w w w o w w w   w w o w w
       w             w
       w             w
       w
--------------   ---------
 7x7 hat tree   5x5 hat tree
