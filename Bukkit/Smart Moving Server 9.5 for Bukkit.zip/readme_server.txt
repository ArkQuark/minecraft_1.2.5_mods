=======================
Smart Moving Server Mod
=======================

Version 9.5 for Minecraft Server 1.2.5

by Divisor



Description
===========

The Smart Moving Server mod provides smart moving specific communication between different SMP clients.

Additionally using a SMP server with this mod avoids bugs that can happen when using Smart Moving clients with standard SMP servers.

In summary using a SMP server with Smart Moving provides the following features:
* crawling into small holes without taking damage
* climbing down without suffering ground arrival damage
* smart moving anmiations for the other players
* correct item placement while being small sized



Required Mods
=============

The server installation packages require

    * Player API server 1.0 or higher

respectively

    * Player API bukkit 1.9 or higher

to be installed too.



Installation
============

Installation varies depending on the minecraft server you are using.
So choose your package and install it - do NOT install more than one package.

In any case, NEVER forget: ALWAYS back up your stuff!


ModLoaderMp Server
------------------
* Your are running a standard minecraft server
* Your server allready has ModLoaderMp installed.

Move the contents of the Smart Moving installation package "SmartMoving Server for ModLoaderMp.zip" to their corresponding locations in your "minecraft_server.jar".

Don't forget to:
* ensure you have the latest version of PlayerAPI installed!
* ensure you have the latest version of SDK's ModLoaderMp server installed!
* ensure all your clients have SDK's ModLoaderMp client installed!


Minecraft Forge Server
----------------------
* Your are running a standard minecraft server
* Your server allready has Minecraft Forge installed.

Move the contents of the Smart Moving installation package "SmartMoving Server for Minecraft Forge.zip" to their corresponding locations in your "minecraft_server.jar".

Don't forget to:
* ensure you have the latest version of PlayerAPI installed!
* ensure you have the latest version of Minecraft Forge server installed!
* ensure all your clients have Minecraft Forge client installed!


Bukkit Server
-------------
* You are running a Bukkit minecraft server.

When you don't allready have Player API installed on your Bukkit server install it. (http://www.minecraftforum.net/topic/738498-124api-player-api/)
You will need the Player API release for bukkit build 1.2.5-%bukkit.playerapi.build.version% not lower not higher. This specific Player API release has been build against a the Bukkit server build 1.2.5-%bukkit.playerapi.build.version%.

After you successfully installed Player API for Bukkit build 1.2.5-R5.0 on the Bukkit server build 1.2.5-R5.0:
* Move the plugin file inside of the Smart Moving installation package "SmartMoving Server for Bukkit.zip" to the plugin folder of your Bukkit server.

Don't forget to:
* ensure you have the build 1.2.5-R5.0 of the Bukkit server.
* ensure you have the PlayerAPI release for Bukkit 1.2.5-R5.0.


MCPortCentral Server
--------------------
* You are running a MCPortCentral minecraft server.

When you don't allready have Player API installed on your MCPortCentral server install it. (http://www.minecraftforum.net/topic/738498-124api-player-api/)
You will need the Player API release for bukkit build 1.2.5-%bukkit.playerapi.build.version% not lower not higher. This specific Player API release has been build against a the Bukkit server build 1.2.5-%bukkit.playerapi.build.version%.

After you successfully installed Player API for Bukkit build 1.2.5-R5.0 on the MCPortCentral server build 1.2.5-R4.0-MCPC-SNAPSHOT-126:
* Move the plugin file inside of the Smart Moving installation package "SmartMoving Server for Bukkit.zip" to the plugin folder of your MCPortCentral server.

Don't forget to:
* ensure you have the build 1.2.5-%bukkit.build.mcportcentral.version% of the MCPortCentral server.
* ensure you have the PlayerAPI release for Bukkit 1.2.5-R5.0.


CraftBukkit++ Server
--------------------
* You are running a CraftBukkit++ minecraft server.

When you don't allready have Player API installed on your Bukkit server install it. (http://www.minecraftforum.net/topic/738498-124api-player-api/)
You will need the Player API release for bukkit build 1.2.5-%bukkit.playerapi.build.version% not lower not higher. This specific Player API release has been build against a the Bukkit server build 1.2.5-%bukkit.playerapi.build.version%.

After you successfully installed Player API for Bukkit build 1.2.5-R5.0 on the Bukkit server build 1.2.5-%bukkit.build.craftbukkitplusplus.version%:
* Move the plugin file inside of the Smart Moving installation package "SmartMoving Server for Bukkit.zip" to the plugin folder of your CraftBukkit++ server.

Don't forget to:
* ensure you have the build 1.2.5-%bukkit.craftbukkitplusplus.build.version% of the CraftBukkit++ server.
* ensure you have the PlayerAPI release for Bukkit 1.2.5-R5.0.



Compatibility
=============

The server mod replaces specific previously created instances with proprietary ones:

* Server 'NetServerHandler' at "EntityPlayerMP.playerNetServerHandler"
  Server mods that use similar replacements will not work correctly with this Server mod.

* Bukkit 'NetServerHandler' at "EntityPlayer.netServerHandler"
  Bukkit mods that use similar replacements will not work correctly with this Bukkit plugin.



Configuration
=============

The file "smart_moving_options.txt" can be used to configure the behavior this mod.
It is located in your minecraft server's working directory.
If does not exist at Minecraft server startup time it is automatically generated.

You can use its content to manipulate this mod's various features on all connected clients.



SBC Support
===========
Smart Moving provides support for Simple Block code (http://dev.bukkit.org/server-mods/sbc/)
Have a look at the website to find the exact codes to block specific Smart Moving features for server players.
