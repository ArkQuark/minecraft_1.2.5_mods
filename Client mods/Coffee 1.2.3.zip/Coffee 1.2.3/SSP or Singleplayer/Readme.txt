Coffee -- in Minecraft!
*Official Release!*

1.2.2 change list:
*Fixed 99% of SMP bugs. Items now have fixed IDs.
*Fixed minor client bugs.

INSTRUCTIONS:

***
I expect you to have already installed ModLoader and Forge 1.2.5.
***
There will be one folder:
1. Coffee

PC:
AFTER INSTALLING MODLOADER AND FORGE:
Click on the 'Start' menu, and click run.  In run, type in, "%appdata%". From there, locate the .minecraft folder, and open the folder called "mods."  If it doesn't exist, just create it.  Now, place the "Coffee" folder directly into "mods." You can close out of all these windows now.  Run the game and you should be good to go!
***
Mac:
AFTER INSTALLING MODLOADER AND FORGE:
In finder, on the top toolbar, click on the 'Go' drop-down menu and then click 'Go to Folder.'  In that text box, type in "/Users/<username>/Library/Application Support".  Please note to type in your computer's username in the place where I said '<username>'.  From there, locate your 'minecraft' folder, and after opening it find the folder called "mods."  If it doesn't exist, just create it.  Now, place the "Coffee" folder directly into "mods."  Yay, you're finished!  Close out of all these windows now, and run Minecraft.  You should be good to go!

NOTE:
Be sure to not place the mod's folder's contents into "mods," place the entire folder in itself.
***
THIS MOD WORKS WITH ALL MODS I HAVE TESTED IT ON.
If a mod is INCOMPATIBLE with Coffee, PM me with it's name.

If it doesn't work, please contact me at bradyaidanc@gmail.com.

Thank you for installing!


