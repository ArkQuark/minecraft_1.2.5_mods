INSTRUCTIONS:

***
I expect you to have already installed Forge 1.2.5.
***
There will be one folder:
1. Coffee

MAC & PC:
AFTER INSTALLING FORGE:
In the server's folder, find the folder called "mods."  If it doesn't exist, just create it.  Now, place the "Coffee" folder directly into "mods." You can close out of these windows now.  Run the server and you should be good to go!

NOTE:
Be sure to not place the mod's folder's contents into "mods," place the entire folder in itself.

If it doesn't work, please contact me at bradyaidanc@gmail.com.

Thank you for installing!


