README
Halo 3 Weapons - Custom content for Flan's mods
v1.0.0a (a for alpha!)
author: 504Dug
subauthors: NONE

******************

DISCLAIMER:

	I am not responsible for any damage this may cause you, your computer, your minecraft, or anything else. Make backups or I'll kill a kitten. :3 (Not really.)

******************

INSTALLATION INSTRUCTIONS

	==For WINDOWS Users==
1) Extract the everything from the .ZIP
2) Hit the Windows key + R on your keyboard.
3) In the window that appears, type in %appdata%/.minecraft/Flan (if it doesn't exist, make it) and hit enter.
4) Copy the folder "Halo 3 Weapons Pack" and paste it there.
5) Enjoy it, why don't you!

	==For MACINTOSH Users==
(copied from the wiki because I have a PC)
1) Extract the everything from the .ZIP
2) While in finder go to Go -> Go to Folder or press [COMMAND] + [SHIFT] + G then enter ~/Library/Application Support/minecraft/Flan (if it doesn't exist, make it). 
3) Copy the folder "Halo 3 Weapons Pack" and paste it there.
4) Enjoy it, why don't you!

******************

About the pack...

Why hello there interwebz!

	I've put together a custom Halo 3 Content Pack for Flan's Mods! (conveniently linked here -> http://www.minecraft...otally-awesome/). As of right now, It's still a work-in-progress, so be patient while I optimize everything! But enough chitchat, here is what you will find in this pack:
	
	UNSC Weaponry
	UNSC Vehicles (Not yet finished)
	Covenant Weaponry (Not yet finished)
	Covenant Vehicles (Not yet finished, this one may take a while).

	So while I continue to work on this add-on, I will update the download with the latest progress.

	ALSO!!!!
	I know some of the textures and scopes and such are not great - that is why this is in ALPHA! Thanks so much for downloading!

						Yours Truly,
						504Dug