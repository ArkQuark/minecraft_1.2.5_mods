package flyingturtle;

import org.lwjgl.opengl.GL11;
import net.minecraft.src.*;

public class RenderFlyingTurtle extends RenderLiving
{
	public RenderFlyingTurtle(ModelBase modelbase, float f)
	{
		super(modelbase, f);
	}

	public void renderFlyingTurtle(EntityLiving entityFlyingTurtle, double d, double d1, double d2, float f, float f1)
	{
		super.doRenderLiving(entityFlyingTurtle, d, d1, d2, f, f1);
	}

	public void doRenderLiving(EntityLiving entityliving, double d, double d1, double d2, float f, float f1)
	{
		renderFlyingTurtle((EntityFlyingTurtle) entityliving, d, d1, d2, f, f1);
	}

	public void doRender(Entity entity, double d, double d1, double d2, float f, float f1)
	{
		renderFlyingTurtle((EntityFlyingTurtle) entity, d, d1, d2, f, f1);
	}

	protected void preRenderScale(EntityFlyingTurtle entity, float f)
	{
		GL11.glScalef(1.25F, 1.25F, 1.25F);
	}

	protected void preRenderCallback(EntityLiving entityliving, float f)
	{
		preRenderScale((EntityFlyingTurtle) entityliving, f);
	}
}