package flyingturtle;

import java.util.List;
import java.util.Random;
import net.minecraft.src.*;

public class EntityFlyingTurtle extends EntityFlying implements IMob
{
    public double waypointX;
    public double waypointY;
    public double waypointZ;

    public EntityFlyingTurtle(World par1World)
    {
        super(par1World);
        texture = "/flyingturtle/flyingturtlemob.png";
        getNavigator().setAvoidsWater(true);
        setSize(1.0F, 0.9F);
    }

    public int getMaxHealth()
    {
        return 2;
    }

    protected void updateEntityActionState()
    {
        double d = waypointX - posX;
        double d1 = waypointY - posY;
        double d2 = waypointZ - posZ;
        double d3 = MathHelper.sqrt_double(d * d + d1 * d1 + d2 * d2);

        if (d3 < 1.0D || d3 > 60D)
        {
            waypointX = posX + (double)((rand.nextFloat() * 8.0F - 4.0F) * 32F);
            waypointY = posY + (double)((rand.nextFloat() * 8.0F - 4.0F) * 32F);
            waypointZ = posZ + (double)((rand.nextFloat() * 8.0F - 4.0F) * 32F);
        }

            if (isCourseTraversable(waypointX, waypointY, waypointZ, d3))
            {
                motionX += (d / d3) * 0.10000000000000001D;
                motionY += (d1 / d3) * 0.10000000000000001D;
                motionZ += (d2 / d3) * 0.10000000000000001D;
            }
            else
            {
                waypointX = posX;
                waypointY = posY;
                waypointZ = posZ;
            }
        }
    
    private boolean isCourseTraversable(double par1, double par3, double par5, double par7)
    {
        double d = (waypointX - posX) / par7;
        double d1 = (waypointY - posY) / par7;
        double d2 = (waypointZ - posZ) / par7;
        AxisAlignedBB axisalignedbb = boundingBox.copy();

        for (int i = 1; (double)i < par7; i++)
        {
            axisalignedbb.offset(d, d1, d2);

            if (worldObj.getCollidingBoundingBoxes(this, axisalignedbb).size() > 0)
            {
                return false;
            }
        }

        return true;
    }
    
    protected String getLivingSound()
    {
        return "Mechanolith";
    }
    
    protected String getHurtSound()
    {
        return null;
    }
    
    protected String getDeathSound()
    {
        return null;
    }
    
    protected float getSoundVolume()
    {
        return 10F;
    }
    
    protected boolean canDespawn()
    {
        return true;
    }
    
    public boolean interact(EntityPlayer par1EntityPlayer)
    {
        if (!super.interact(par1EntityPlayer))
        {
            {
                par1EntityPlayer.mountEntity(this);
                return true;
            }
        }
        else
        {
            return true;
        }
    }
}
