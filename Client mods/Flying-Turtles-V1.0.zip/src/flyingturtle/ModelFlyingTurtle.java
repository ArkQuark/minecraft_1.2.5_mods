package flyingturtle;

import net.minecraft.src.*;

public class ModelFlyingTurtle extends ModelBase
{
	ModelRenderer base;
	ModelRenderer edge1;
	ModelRenderer edge2;
	ModelRenderer edge3;
	ModelRenderer edge4;
	ModelRenderer top;
	ModelRenderer head;
	ModelRenderer frontleft;
	ModelRenderer frontback;
	ModelRenderer backleft;
	ModelRenderer backright;

	public ModelFlyingTurtle()
	{
		textureWidth = 128;
		textureHeight = 64;

		base = new ModelRenderer(this, 0, 0);
		base.addBox(-7F, -2F, -7F, 14, 4, 14);
		base.setRotationPoint(0F, 19F, 0F);
		base.setTextureSize(128, 64);
		base.mirror = true;
		setRotation(base, 0F, 0F, 0F);
		edge1 = new ModelRenderer(this, 0, 59);
		edge1.addBox(-7F, -2F, 0F, 14, 4, 1);
		edge1.setRotationPoint(0F, 19F, -8F);
		edge1.setTextureSize(128, 64);
		edge1.mirror = true;
		setRotation(edge1, 0F, 0F, 0F);
		edge2 = new ModelRenderer(this, 0, 59);
		edge2.addBox(-7F, -2F, 0F, 14, 4, 1);
		edge2.setRotationPoint(-8F, 19F, 0F);
		edge2.setTextureSize(128, 64);
		edge2.mirror = true;
		setRotation(edge2, 0F, 1.570796F, 0F);
		edge3 = new ModelRenderer(this, 0, 59);
		edge3.addBox(-7F, -2F, 0F, 14, 4, 1);
		edge3.setRotationPoint(0F, 19F, 8F);
		edge3.setTextureSize(128, 64);
		edge3.mirror = true;
		setRotation(edge3, 0F, 3.141593F, 0F);
		edge4 = new ModelRenderer(this, 0, 59);
		edge4.addBox(-7F, -2F, 0F, 14, 4, 1);
		edge4.setRotationPoint(8F, 19F, 0F);
		edge4.setTextureSize(128, 64);
		edge4.mirror = true;
		setRotation(edge4, 0F, -1.570796F, 0F);
		top = new ModelRenderer(this, 0, 18);
		top.addBox(-6F, -1F, -6F, 12, 2, 12);
		top.setRotationPoint(0F, 16F, 0F);
		top.setTextureSize(128, 64);
		top.mirror = true;
		setRotation(top, 0F, 0F, 0F);
		head = new ModelRenderer(this, 30, 58);
		head.addBox(-2F, -1F, -4F, 4, 2, 4);
		head.setRotationPoint(0F, 19F, -8F);
		head.setTextureSize(128, 64);
		head.mirror = true;
		setRotation(head, 0F, 0F, 0F);
		frontleft = new ModelRenderer(this, 0, 32);
		frontleft.addBox(-1F, -1F, -12F, 3, 1, 12);
		frontleft.setRotationPoint(5F, 20F, -5F);
		frontleft.setTextureSize(128, 64);
		frontleft.mirror = true;
		setRotation(frontleft, 0.1745329F, -0.8901179F, 0.0872665F);
		frontback = new ModelRenderer(this, 0, 32);
		frontback.addBox(-1F, -1F, -12F, 3, 1, 12);
		frontback.setRotationPoint(-5F, 20F, -5F);
		frontback.setTextureSize(128, 64);
		frontback.mirror = true;
		setRotation(frontback, 0.1745329F, 0.8901179F, 0F);
		backleft = new ModelRenderer(this, 0, 45);
		backleft.addBox(-1F, 0F, 0F, 3, 1, 7);
		backleft.setRotationPoint(5F, 19F, 6F);
		backleft.setTextureSize(128, 64);
		backleft.mirror = true;
		setRotation(backleft, -0.2617994F, 0.5585054F, 0.1047198F);
		backright = new ModelRenderer(this, 0, 45);
		backright.addBox(-2F, 0F, 0F, 3, 1, 7);
		backright.setRotationPoint(-5F, 19F, 6F);
		backright.setTextureSize(128, 64);
		backright.mirror = true;
		setRotation(backright, -0.2617994F, -0.5585054F, -0.1047198F);
	}

	public void render(Entity entity, float f, float f1, float f2, float f3, float f4, float f5)
	{
		super.render(entity, f, f1, f2, f3, f4, f5);
		setRotationAngles(f, f1, f2, f3, f4, f5);
		base.render(f5);
		edge1.render(f5);
		edge2.render(f5);
		edge3.render(f5);
		edge4.render(f5);
		top.render(f5);
		head.render(f5);
		frontleft.render(f5);
		frontback.render(f5);
		backleft.render(f5);
		backright.render(f5);
	}

	private void setRotation(ModelRenderer model, float x, float y, float z)
	{
		model.rotateAngleX = x;
		model.rotateAngleY = y;
		model.rotateAngleZ = z;
	}

	public void setRotationAngles(float f, float f1, float f2, float f3, float f4, float f5)
	{
		super.setRotationAngles(f, f1, f2, f3, f4, f5);
	}
}