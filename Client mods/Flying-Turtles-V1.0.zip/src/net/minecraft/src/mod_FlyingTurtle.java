package net.minecraft.src;

import java.util.Map;
import flyingturtle.*;

public class mod_FlyingTurtle extends BaseMod
{
	public static Item flyingTurtleItem = (new ItemFlyingTurtle(3050)).setItemName("flyingTurtleItem");
	
	public String getVersion()
	{
		return "V1.0 (MC 1.2.5)";
	}
	
	public void load()
	{
		ModLoader.registerEntityID(EntityFlyingTurtle.class, "flyingTurtle", ModLoader.getUniqueEntityId());
		
		ModLoader.addName(flyingTurtleItem, "Flying Turtle");
		
		flyingTurtleItem.iconIndex = ModLoader.addOverride("/gui/items.png", "/flyingturtle/flyingturtle.png");
		
		ModLoader.addRecipe(new ItemStack(flyingTurtleItem, 64), new Object[] {" a ", "cbc", " c ", Character.valueOf('a'), Block.slowSand, Character.valueOf('b'), Block.dirt, Character.valueOf('c'), Block.waterlily});
	}
	
	public void addRenderer(Map map)
	{
		map.put(EntityFlyingTurtle.class, new RenderFlyingTurtle(new ModelFlyingTurtle(), 0.0F));
	}
	
	public mod_FlyingTurtle()
	{
	}
}
