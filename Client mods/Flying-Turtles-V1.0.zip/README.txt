Put "Flying Turtles.zip" into /.minecraft/mods, and put the mod folder into /.minecraft/resources.

Note that Flying Turtles requires ModLoader and AudioMod.

The "src" folder is only for people who are interested in how this mod was made.

Enjoy your Turtles.