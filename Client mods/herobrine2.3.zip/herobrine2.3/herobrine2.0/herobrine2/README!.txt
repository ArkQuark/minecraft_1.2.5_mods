###########################################################
#Herobrine Mod V.2.1 2011 By Burnner                      #
#                                                         #
#He will scare the shit out of you!                       #
###########################################################

----------------
HOW TO INSTALL
----------------
1. Run EasyModInstaller.jar
2. Select your minecraft.jar
3. done!

Note: under linux you have to switch your working dir with 
cd


---------------------
How to Install MANUAL
-----------------------
!!REQUIRES MODLOADER!!
!!For the disc's you will also need audio mod!!

1. Move the files from the intominecraft.jar folder into minecraft.jar (obviously)

2. Copy the Herobrine folder into the .minecraft folder 

3. Open Minecraft, load a world, build a totem, light it, and get ready to shit your pants!


-----------
How to Use
-----------
1. You may want to backup your map. You have been warned.

2. Craft a Herobrine Totem block.

Recipe:
BBB   B=bone
BSB   S=SoulSand
BBB
3. Build the Herobrine Totem by stacking 2 gold blocks, then the totem block, then a piece of netherrack, like so:

N         N=netherrack
H         H=Herobrine Totem Block
G         G=gold block
G         G=gold block

4. Light the netherrack with a flint and steel.

5. Wait for a few seconds. The eyes on the totem block will turn red when the totem is activated.

6. Check and make sure you are NOT on peaceful. If you are on Peaceful, HE WILL NOT SPAWN.

7. To make him stop spawning, either punch out the fire on the netherrack or remove a gold block.

8. Feel free to make a video and freak out your superstitous friends!


You can find some screenshots of the totem and the recipe for it in the folder.

PS: You can chance the herobrine spawn interval by editing the herobrine.ini!


check out for updates here: 
http://www.minecraftforum.net/topic/511421-173herobrine-v05-new-version-is-comming-soon/

If you like it, plz donate :)

-------------
Disclaimer
-------------
Use at your own risk! Im not accountable for random hearth attacks,
poop in the pants, and other paranormal things I won't buy you
new pants!


Have Fun!

Burnner


21.12.2011
