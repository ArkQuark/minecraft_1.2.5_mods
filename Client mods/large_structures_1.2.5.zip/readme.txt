INSTALLATION:
=============

1. Open your minecraft.jar in %appdata%/.minecraft/bin/
2. Copy and paste the .class files from this zip into minecraft.jar
3. If neccessary, delete the META-INF folder in minecraft.jar

ModLoader is not required!

Enjoy!