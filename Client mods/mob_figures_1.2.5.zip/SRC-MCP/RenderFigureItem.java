package net.minecraft.src;

import java.util.Random;

import org.lwjgl.opengl.GL11;

public class RenderFigureItem extends RenderItem {

	public RenderFigureItem() {
		super();
        random = new Random();
	}
	
	public void doRenderFigureItem(EntityItem entityitem, double d, double d1, double d2,
			float f, float f1) {
        random.setSeed(187L);
        GL11.glPushMatrix();
        float f2 = MathHelper.sin(((float)entityitem.age + f1) / 10F + entityitem.field_804_d) * 0.1F + 0.1F;
        float f3 = (((float)entityitem.age + f1) / 20F + entityitem.field_804_d) * 57.29578F;
        byte byte0 = 1;
        if(entityitem.item.stackSize > 1)
        {
            byte0 = 2;
        }
        if(entityitem.item.stackSize > 5)
        {
            byte0 = 3;
        }
        if(entityitem.item.stackSize > 20)
        {
            byte0 = 4;
        }
        GL11.glTranslatef((float)d, (float)d1 + f2, (float)d2);
        GL11.glEnable(32826 /*GL_RESCALE_NORMAL_EXT*/);
        GL11.glRotatef(f3, 0.0F, 1.0F, 0.0F);
        float f4 = 1.0F; //0.25F;
        for(int j = 0; j < byte0; j++)
        {
            GL11.glPushMatrix();
            if(j > 0)
            {
                float f5 = ((random.nextFloat() * 2.0F - 1.0F) * 0.2F) / f4;
                float f7 = ((random.nextFloat() * 2.0F - 1.0F) * 0.2F) / f4;
                float f9 = ((random.nextFloat() * 2.0F - 1.0F) * 0.2F) / f4;
                GL11.glTranslatef(f5, f7, f9);
            }

//            renderManager.renderEntityWithPosYaw(new EntityFigure(entityitem.worldObj, entityitem.item.getItemDamage()), d, d1, d2, f, f1);
            EntityFigure ef = new EntityFigure(entityitem.worldObj, ItemFigure.entityIndexMap.get(entityitem.item.getItemDamage()));
            renderManager.renderEntityWithPosYaw(ef, 0, 0, 0, 0, f1);
            ef.callAfterRender();
            GL11.glPopMatrix();
        }
        
		GL11.glPopMatrix();
	}
	
	public void doRender(Entity entity, double d, double d1, double d2,
			float f, float f1) {
		if (entity instanceof EntityItem) {
			EntityItem ei = (EntityItem)entity;
//			if (ei.item.itemID == mod_Figure.figure.shiftedIndex && ei.item.getItemDamage() != 0) {
			if (ei.item.itemID == mod_Figure.figure.shiftedIndex && ei.item.getItemDamage() > 0) {
				doRenderFigureItem(ei, d, d1, d2, f, f1);
				return;
			}
		}
		
		super.doRender(entity, d, d1, d2, f, f1);
	}

    public void drawItemIntoGui(FontRenderer fontrenderer, RenderEngine renderengine, int i, int j, int k, int l, int i1)
    {
    	if  (i == mod_Figure.figure.shiftedIndex && j != 0) {
        	// ���ꃌ���_�[GUI����
    		GL11.glPushMatrix();
            GL11.glTranslatef(l - 2, i1 + 3, -3F);
            GL11.glScalef(10F, 10F, 10F);
            GL11.glTranslatef(1.0F, 0.5F, 1.0F);
            GL11.glScalef(1.0F, 1.0F, -1F);
            GL11.glRotatef(210F, 1.0F, 0.0F, 0.0F);
            GL11.glRotatef(45F, 0.0F, 1.0F, 0.0F);
            
//            renderManager.renderEntityWithPosYaw(new EntityFigure(ModLoader.getMinecraftInstance().theWorld, j), 0, 0, 0, 0, 0);
            EntityFigure ef = new EntityFigure(renderManager.worldObj, ItemFigure.entityIndexMap.get(j));
            renderManager.renderEntityWithPosYaw(ef, 0, 0, 0, 0, 0);
            ef.callAfterRender();
    		
    		GL11.glPopMatrix();
    	} else {
    		super.drawItemIntoGui(fontrenderer, renderengine, i, j, k, l, i1);
    	}
    }
    
    
	private Random random;

}
