package net.minecraft.src;

import java.util.ArrayList;
import java.util.Map;
import java.util.TreeMap;

public class ItemFigure extends Item {
	  
    public static World lasetWorld;
    public static Map<Integer, Entity> entityIndexMap = new TreeMap<Integer, Entity>();
    public static Map<String, Entity> entityStringMap = new TreeMap<String, Entity>();

	
	
	public ItemFigure(int i) {
        super(i);
        maxStackSize = 16;
        setHasSubtypes(true);
        setMaxDamage(0);
	}

	public static void checkCreateEntity(World world) {
		// Entity�̃��X�g���쐬
		if (world != null && lasetWorld != world) {
			entityIndexMap.clear();
			entityStringMap.clear();
			for (Map.Entry<String, Class<Entity>> me : mod_Figure.entityClassMap.entrySet()) {
				if (me.getKey() == null) continue;
				Entity entity1 = EntityList.createEntityByName(me.getKey(), world);
				if (entity1 != null) {
					entityIndexMap.put(Integer.valueOf(EntityList.getEntityID(entity1)), entity1);
					entityStringMap.put(me.getKey(), entity1);
				}
			}
			lasetWorld = world;
		}
	}
	
	@Override
	public ItemStack onItemRightClick(ItemStack itemstack, World world, EntityPlayer entityplayer) {
    	// �����`�F�b�N
    	checkCreateEntity(world);
    	
    	// �ݒu
        float f = 1.0F;
        float f1 = entityplayer.prevRotationPitch + (entityplayer.rotationPitch - entityplayer.prevRotationPitch) * f;
        float f2 = entityplayer.prevRotationYaw + (entityplayer.rotationYaw - entityplayer.prevRotationYaw) * f;
        double d = entityplayer.prevPosX + (entityplayer.posX - entityplayer.prevPosX) * (double)f;
        double d1 = (entityplayer.prevPosY + (entityplayer.posY - entityplayer.prevPosY) * (double)f + 1.6200000000000001D) - (double)entityplayer.yOffset;
        double d2 = entityplayer.prevPosZ + (entityplayer.posZ - entityplayer.prevPosZ) * (double)f;
        Vec3D vec3d = Vec3D.createVector(d, d1, d2);
        float f3 = MathHelper.cos(-f2 * 0.01745329F - 3.141593F);
        float f4 = MathHelper.sin(-f2 * 0.01745329F - 3.141593F);
        float f5 = -MathHelper.cos(-f1 * 0.01745329F);
        float f6 = MathHelper.sin(-f1 * 0.01745329F);
        float f7 = f4 * f5;
        float f8 = f6;
        float f9 = f3 * f5;
        double d3 = 5D;
        Vec3D vec3d1 = vec3d.addVector((double)f7 * d3, (double)f8 * d3, (double)f9 * d3);
        MovingObjectPosition movingobjectposition = world.rayTraceBlocks_do(vec3d, vec3d1, true);
        if(movingobjectposition == null)
        {
            return itemstack;
        }
        if(movingobjectposition.typeOfHit == EnumMovingObjectType.TILE)
        {
            int i = movingobjectposition.blockX;
            int j = movingobjectposition.blockY;
            int k = movingobjectposition.blockZ;
    		double my = Block.blocksList[world.getBlockId(i, j, k)].maxY;
        	if (world.getBlockMaterial(i, j + 1, k) == Material.air || my <= 0.5D) {
                if(!world.isRemote)
                {
                	Entity se = null;
                	if (itemstack.getItemDamage() != 0) {
                    	se = EntityList.createEntityByID(itemstack.getItemDamage(), world);
                	}
                	if (se == null) {
                		int l = (Integer)(entityIndexMap.keySet().toArray())[entityplayer.rand.nextInt(entityIndexMap.size())];
                		se = EntityList.createEntityByID(l, world);
                		System.out.println("Selection null.");
                	}
                	EntityFigure ef = new EntityFigure(world, se);
                	if (itemstack.getItemDamage() == 0) {
                		if (entityplayer instanceof EntityPlayerSP) {
                        	ModLoader.openGUI(entityplayer, new GuiFigureSelect(ef));
                		}
                	}
                    // �������߂͂����ɓ����
                	System.out.println(String.format("dir:%d", movingobjectposition.sideHit));
                	double x, y, z;
                	if (movingobjectposition.sideHit == 1) {
                		// �V�ӂ�I�������ꍇ�ڍׂȔz�u���ł���
                		double dd = (j + my - vec3d.yCoord) / (vec3d1.yCoord - vec3d.yCoord);
                		x = (vec3d1.xCoord - vec3d.xCoord) * dd + vec3d.xCoord;
                		y = j + my; 
                		z = (vec3d1.zCoord - vec3d.zCoord) * dd + vec3d.zCoord;
                		System.out.println(String.format("%f, %f, %f", x, y, z));
                	} else {
                		x = i + 0.5D;
                		y = j + 1.0D; 
                		z = k + 0.5D;
                	}
                	
                    ef.setPositionAndRotation2(x, y, z, (entityplayer.rotationYaw + 180F) % 360F, 0, 1);
                    se.setPositionAndRotation(0, 0, 0, ef.rotationYaw, 0);
                    if (se instanceof EntityLiving) {
                        EntityLiving sel = (EntityLiving)se;
                    	sel.prevRotationYawHead = sel.rotationYawHead = ef.rotationYaw;
                    }
                    ef.getGui().setRotation();
                    world.spawnEntityInWorld(ef);
                }
                world.playSoundAtEntity(entityplayer, "step.wood", 0.5F, 0.4F / (itemRand.nextFloat() * 0.4F + 0.8F));
                itemstack.stackSize--;
        	}
        }
        
        return itemstack;
    }
    
	@Override
    public String getItemNameIS(ItemStack itemstack)
    {
    	if (itemstack.getItemDamage() != 0) {
    		checkCreateEntity(mod_Figure.mc.theWorld);
            Entity e = entityIndexMap.get(itemstack.getItemDamage());
            if (e != null) {
                return (new StringBuilder()).append(super.getItemName()).append(".").append(EntityList.getEntityString(e)).toString();
            } else {
//            	System.out.println(String.format("figua-e-id lost:%d", itemstack.getItemDamage()));
            	itemstack.setItemDamage(0);
            }
    	}
    	return super.getItemName();
    }
	

	// Forge
	public void addCreativeItems(ArrayList itemList) {
		itemList.add(new ItemStack(mod_Figure.figure, 1));
		if (!entityIndexMap.isEmpty()) {
			for (Map.Entry<Integer, Entity> ei : entityIndexMap.entrySet()) {
				itemList.add(new ItemStack(mod_Figure.figure, 1, ei.getKey()));
			}
		}
	}

}
