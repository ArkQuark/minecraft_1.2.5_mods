package net.minecraft.src;

import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL13;

public class GuiFigurePause extends GuiScreen {

    protected String screenTitle;
    protected EntityFigure targetEntity;
    protected String button10[] = {"Dismount", "Ride"};
    protected String button11[] = {"Stand", "Sneak"};
    protected static float button13[] = {1, 2, 4, 6};
    protected GuiFigureSlider figureYaw;


    public GuiFigurePause(EntityFigure entityfigure)
    {
        screenTitle = "Figure Pause";
        targetEntity = entityfigure;
    }

    @Override
    public void initGui()
    {
        StringTranslate stringtranslate = StringTranslate.getInstance();

        controlList.add(new GuiButton(10, width / 2 + 60, height / 6 + 48 + 12, 80, 20, stringtranslate.translateKey(button10[targetEntity.renderEntity.isRiding() ? 1 : 0])));
        controlList.add(new GuiButton(11, width / 2 + 60, height / 6 + 72 + 12, 80, 20, stringtranslate.translateKey(button11[targetEntity.renderEntity.isSneaking() ? 1 : 0])));
        controlList.add(new GuiButton(13, width / 2 + 60, height / 6 + 0 + 12, 80, 20, stringtranslate.translateKey(String.format("1 / %.0f", targetEntity.zoom))));
//        controlList.add(new GuiButton(200, width / 2 - 100, height / 6 + 168, 200, 20, stringtranslate.translateKey("gui.done")));
        figureYaw = new GuiFigureSlider(15, width / 2 -50, height / 6 + 96 + 12, String.format("%.2f", targetEntity.additionalYaw), (targetEntity.additionalYaw + 180F) / 360F);
        controlList.add(figureYaw);

        controlList.add(new GuiButton(20, width / 2 + 80, height / 6 + 24 + 12, 40, 20, String.format("%.2f", targetEntity.renderEntity.yOffset)));
        controlList.add(new GuiButton(21, width / 2 + 60, height / 6 + 24 + 12, 20, 20, stringtranslate.translateKey("+")));
        controlList.add(new GuiButton(22, width / 2 + 120, height / 6 + 24 + 12, 20, 20, stringtranslate.translateKey("-")));
    }

    public void readEntityFromNBT(NBTTagCompound nbttagcompound) {
    	// ����ȃf�[�^�ǂݍ��݂����s
    }

	public void writeEntityToNBT(NBTTagCompound nbttagcompound) {
		// ����ȃf�[�^�������݂����s
	}
	
	public void setRotation() {
		// �p������p
	}
    
	@Override
    protected void actionPerformed(GuiButton guibutton)
    {
        if(!guibutton.enabled)
        {
            return;
        }
        if(guibutton.id == 10)
        {
        	if (targetEntity.renderEntity.isRiding()) {
        		// �ڂ��Ă�
//            	targetEntity.setEntityFlag(2, false);
            	targetEntity.renderEntity.setFlag(2, false);
            	guibutton.displayString = button10[0];
        	} else {
        		// �ڂ��ĂȂ�
//            	targetEntity.setEntityFlag(2, true);
            	targetEntity.renderEntity.setFlag(2, true);
            	guibutton.displayString = button10[1];
        	}
        }
        if(guibutton.id == 11)
        {
        	if (targetEntity.renderEntity.isSneaking()) {
        		// ���Ⴊ��
//            	targetEntity.setEntityFlag(1, false);
            	targetEntity.renderEntity.setFlag(1, false);
            	guibutton.displayString = button11[0];
        	} else {
        		// ����
//            	targetEntity.setEntityFlag(1, true);
            	targetEntity.renderEntity.setFlag(1, true);
            	guibutton.displayString = button11[1];
        	}
        }
        if(guibutton.id == 13)
        {
        	// �{��
        	int i = 0;
        	float z;
        	for (int j = 0; j < button13.length; j++) {
        		z = button13[j] > 0 ? button13[j] : 1 / -button13[j];
        		if (targetEntity.zoom == z) {
                	if (j + 1 < button13.length) {
                    	i = j + 1;
                	}
        			break;
        		}
        	}
    		z = button13[i] > 0 ? button13[i] : 1 / -button13[i];
        	targetEntity.setZoom(z);
        	if (z >= 1) {
            	guibutton.displayString = String.format("1 / %.0f", targetEntity.zoom);
        	} else {
            	guibutton.displayString = String.format("%.0f / 1", -button13[i]);
        	}
        }
        
        if (guibutton.id == 20) {
        	targetEntity.renderEntity.yOffset = 0;
        }
        if (guibutton.id == 21) {
        	targetEntity.renderEntity.yOffset += 0.05;
        }        
        if (guibutton.id == 22) {
        	targetEntity.renderEntity.yOffset -= 0.05;
        }        
        for(int k = 0; k < controlList.size(); k++)
        {
            GuiButton gb = (GuiButton)controlList.get(k);
            if (gb.id == 20) {
            	gb.displayString = String.format("%.2f", targetEntity.renderEntity.yOffset);
            }
        }
        
        if(guibutton.id == 200)
        {
            mc.gameSettings.saveOptions();
            mc.displayGuiScreen(null);
        }
    }

    @Override
    public void drawScreen(int i, int j, float f)
    {
        drawDefaultBackground();
        drawCenteredString(fontRenderer, screenTitle, width / 2, 20, 0xffffff);

        // ��̌�����ύX
        targetEntity.additionalYaw = figureYaw.getSliderValue();
        // �L����
        int l = width / 2;
        int k = height / 6 + 72;//height / 2;
        EntityLiving elt = (EntityLiving)targetEntity.renderEntity;
        GL11.glEnable(32826 /*GL_RESCALE_NORMAL_EXT*/);
        GL11.glEnable(2903 /*GL_COLOR_MATERIAL*/);
        GL11.glPushMatrix();
        GL11.glTranslatef(l, k + 30F, 50F);
//        float f1 = 45F;
        float f1 = 80F / elt.height;
        GL11.glScalef(-f1, f1, f1);
        GL11.glRotatef(180F, 0.0F, 0.0F, 1.0F);
        float f2 = elt.renderYawOffset;
        float f5 = (float)(l + 0) - i;
        float f6 = (float)((k + 30) - 50) - j;
        GL11.glRotatef(135F, 0.0F, 1.0F, 0.0F);
        RenderHelper.enableStandardItemLighting();
        GL11.glRotatef(targetEntity.additionalYaw - 135F, 0.0F, 1.0F, 0.0F);
//        elt.renderYawOffset = getGuiRenderYawOffset();
        elt.renderYawOffset = 0F;
        elt.rotationYaw = (float)Math.atan(f5 / 40F) * 40F;
        elt.rotationPitch = -(float)Math.atan(f6 / 40F) * 20F;
        elt.rotationYawHead = elt.rotationYaw;
        elt.prevRotationYawHead = elt.rotationYaw;
        setRotation();
        GL11.glTranslatef(0.0F, elt.yOffset, 0.0F);
        RenderManager.instance.playerViewY = 180F;
        RenderManager.instance.renderEntityWithPosYaw(elt, 0.0D, 0.0D, 0.0D, 0.0F, 1.0F);
        elt.renderYawOffset = f2;
        elt.prevRotationYaw = elt.rotationYaw + f2;
        elt.prevRotationPitch = elt.rotationPitch;
        elt.rotationYawHead = elt.rotationYaw + f2;
        elt.prevRotationYawHead = elt.rotationYaw + f2;
        setRotation();
        
//        System.out.println(String.format("f: %f, %f, %f", elt.rotationYaw, elt.prevRotationYaw, elt.renderYawOffset));
        // �e�����o�C�I�[�������̏���?
        GL13.glMultiTexCoord2f(33985 /*GL_TEXTURE1_ARB*/, 240.0F, 240.0F);
        GL11.glPopMatrix();
        RenderHelper.disableStandardItemLighting();
        GL11.glDisable(32826 /*GL_RESCALE_NORMAL_EXT*/);

        super.drawScreen(i, j, f);
    }
    
    @Override
    public boolean doesGuiPauseGame() {
    	// �t�B�M���A���������Ă���Ǝ���Y����ˁH
        return false;
    }
    
    public float getGuiRenderYawOffset() {
    	return 0.0F;
    }

    public static void afterRender(EntityFigure entityfigure) {
    	// �L�����N�^�[�������_�����O������̓��ꏈ��
    	// static�Ȃ̂Ōp������킯�ł͂Ȃ����玩���ō��B
    }

}
