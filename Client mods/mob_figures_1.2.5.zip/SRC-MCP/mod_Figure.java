package net.minecraft.src;

import java.lang.reflect.Array;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.TreeMap;

import net.minecraft.client.Minecraft;

public class mod_Figure extends BaseMod {

	@MLProp(info = "ItemID(shiftIndex = ItemID - 256)", min = 256, max = 32000)
	public static int itemID = 22203;
	@MLProp(info = "Override RenderItem.")
	public static boolean renderHacking = true;
	@MLProp(info = "Override Icon.(false = Icon:GoldenApple)")
	public static boolean useIcon = true;
	@MLProp(info = "Zoom rate.")
	public static String zoomRate = "1, 2, 4, 6";
	
	public static RenderItem renderItem;	// ����RenderItem
	public static int iconIndex;
	public static Item figure;
	public static Minecraft mc;
	public static Map<String, Class<Entity>> entityClassMap = new TreeMap<String, Class<Entity>>();
	public static Map<String, Class> guiClassMap = new HashMap<String, Class>();

	
	
	@Override
	public String getVersion() {
		return "1.2.5-1";
	}

	@Override
	public void load() {
		mc = ModLoader.getMinecraftInstance();
		iconIndex = ModLoader.addOverride("/gui/items.png", "/item/figure.png");
		if (useIcon) {
			figure = new ItemFigure(itemID - 256).setIconIndex(iconIndex).setItemName("Figure");
		} else {
			figure = new ItemFigure(itemID - 256).setIconCoord(11, 0).setItemName("Figure");
		}
        ModLoader.registerEntityID(net.minecraft.src.EntityFigure.class, "Figure", ModLoader.getUniqueEntityId());
	
        // ���̕ϊ��e�[�u���̒ǉ�
        ModLoader.addLocalization(
        		(new StringBuilder()).append(figure.getItemName()).append(".name").toString(),
        		(new StringBuilder()).append("Figure").toString()
        		);
        // ���V�s�̒ǉ�
       	ModLoader.addShapelessRecipe(new ItemStack(figure, 1, 0), new Object[]{Item.stick, Item.clay});
       	ModLoader.addShapelessRecipe(new ItemStack(Item.clay), new Object[]{figure});

       	// �Q�[���N����̐ݒ�p�t�b�N
       	ModLoader.setInGUIHook(this, true, false);
       	
       	// �{���ݒ�
       	String s[] = zoomRate.split(",");
       	if (s.length > 0) {
           	float az[] = new float[s.length];
           	for (int i = 0; i < s.length; i++) {
           		az[i] = Float.valueOf(s[i].trim());
           	}
         	GuiFigurePause.button13 = az;
       	}

       	// �v���[���[�X�L���\���pMOB�̒ǉ�
        ModLoader.registerEntityID(EntityFigurePlayer.class, "FigurePlayer", ModLoader.getUniqueEntityId());

	}
		
	@Override
    public void addRenderer(Map map)
    {
        map.put(EntityFigure.class, new RenderFigure());
        map.put(EntityFigurePlayer.class, new RenderFigurePlayer());
        if (renderHacking) {
        	map.put(net.minecraft.src.EntityItem.class, new RenderFigureItem());
        }
    }
    
    @Override
    public void modsLoaded() {
    	// CreativeAPI�p
    	boolean isCreativeAPI = false;
    	Method mes = null;
        try {
        	Package pac = this.getClass().getPackage();
        	String s;
        	if (pac == null) s = "CreativeAPI";
        	else s = pac.getName().concat(".CreativeAPI");
        	mes = Class.forName(s).getMethod("addItem", new Class[] {Item.class, int.class});
           	isCreativeAPI = true;
		} catch (Exception e) {
			ModLoader.getLogger().fine((new StringBuilder("Creative API not found! ")).toString());
		}
        
        // �S����Entity���ǉ����ꂽ�H
    	try {
        	Map<String, Class<Entity>> sc = (Map<String, Class<Entity>>)ModLoader.getPrivateValue(EntityList.class, null, 0);
        	Map<Class<Entity>, Integer> ci = (Map<Class<Entity>, Integer>)ModLoader.getPrivateValue(EntityList.class, null, 3);
            ClassLoader classloader1 = mod_Figure.class.getClassLoader();
            Package packege1 = mod_Figure.class.getPackage();
            String strpackege = "";
            if (packege1 != null) {
            	strpackege = packege1.getName();
            }
            if (!strpackege.isEmpty()) {
            	strpackege += ".";
            }
            if (sc != null && ci != null) {
        		for (Map.Entry<String, Class<Entity>> me : sc.entrySet()) {
        			Class<Entity> cl = (Class<Entity>)me.getValue();
        			if (EntityLiving.class.isAssignableFrom(cl) && !cl.isAssignableFrom(EntityLiving.class) && !cl.isAssignableFrom(EntityMob.class)) {
        				entityClassMap.put(me.getKey(), me.getValue());
        				// �������V�s�Ɩ��̂̒ǉ�
//        				ModLoader.AddShapelessRecipe(new ItemStack(Item.clay), new Object[]{new ItemStack(figure, 1, ci.get(me.getValue()))});
        		        ModLoader.addLocalization(
        		        		(new StringBuilder()).append(figure.getItemName()).append(".").append(me.getKey()).append(".name").toString(),
        		        		(new StringBuilder()).append("Figure ").append(me.getKey()).toString()
        		        		);
        		        // �I�[�g��GUI��ǉ�
        		        String cls = (new StringBuilder()).append(strpackege).append("GuiFigurePause_").append(me.getKey()).toString();
        		        try {
        		        	Class class1 = classloader1.loadClass(cls);
        		            addGui(me.getKey(), class1);
        		        	System.out.println("success:" + cls);
        		        }
        		        catch (Exception e) {
        		        	System.out.println("fali:" + cls);
        		        }

        		        // CreativeAPI�p
        		        if (isCreativeAPI) {
            		        try {
            	        		mes.invoke(null, figure, ci.get(cl));
            		        } catch (Exception e) {
            		        }
        		        }

        			}
        		}
        	}
        }
        catch(Exception exception) {
            exception.printStackTrace();
        }
		// �������V�s�̒ǉ�
		ModLoader.addShapelessRecipe(new ItemStack(Item.clay), new Object[]{new ItemStack(figure, 1, -1)});

    }

    @Override
    public boolean onTickInGUI(float f, Minecraft minecraft, GuiScreen guiscreen) {
    	// �A�C�e�������_�[���I�[�o�[���C�h
//    	System.out.println(String.format("tick"));
        if (renderHacking) {
        	minecraft.entityRenderer.itemRenderer = new ItemRendererFigure(minecraft);
        	RenderManager.instance.itemRenderer = new ItemRendererFigure(minecraft);
        	// GUI�̕\����ς���ɂ͏펞�Ď����K�v�H
        }
        // ���ł���
        return false;
    }

    public void addGui(String name, Class cl)
    {
    	if (name != null && name.length() > 0) {
    		guiClassMap.put(name, cl);
    	}
    }
    

}
