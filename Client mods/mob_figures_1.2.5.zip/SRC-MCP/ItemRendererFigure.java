package net.minecraft.src;

import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL13;

import net.minecraft.client.Minecraft;

public class ItemRendererFigure extends ItemRenderer {

	public ItemRendererFigure(Minecraft minecraft) {
		super(minecraft);
	}
	
    public void renderItem(EntityLiving entityliving, ItemStack itemstack, int i) {
    	if (itemstack != null && itemstack.itemID == mod_Figure.figure.shiftedIndex && itemstack.getItemDamage() != 0) {
    		//���ꃌ���_�[��
    		GL11.glPushMatrix();
    		GL11.glTranslatef(-0.5F, 0.0F, 0.5F);
    		GL11.glRotatef(180F, 0F, 1F, 0F);
    		GL11.glScalef(2.5F, 2.5F, 2.5F);
    		
    		
            EntityFigure ef = new EntityFigure(entityliving.worldObj, ItemFigure.entityIndexMap.get(itemstack.getItemDamage()));
            RenderManager.instance.renderEntityWithPosYaw(ef, 0, 0, 0, 0, 0);
            ef.callAfterRender();
//    		RenderManager.instance.renderEntityWithPosYaw(new EntityFigure(entityliving.worldObj, ItemFigure.entityIndexMap.get(itemstack.getItemDamage())), 0, 0, 0, 0, 0);

    		GL11.glPopMatrix();
    	} else {
    		super.renderItem(entityliving, itemstack, i);
    	}
    }
    
    public void renderItemInFirstPerson(float f) {
    	Minecraft mc = ModLoader.getMinecraftInstance();
	    ItemStack itemToRender;
	    float equippedProgress;
	    float prevEquippedProgress;

	    try {
	    	// ���[�J���ϐ����m��
    	    itemToRender = (ItemStack)ModLoader.getPrivateValue(ItemRenderer.class, this, 1);
    	    equippedProgress = (Float)ModLoader.getPrivateValue(ItemRenderer.class, this, 2);
    	    prevEquippedProgress = (Float)ModLoader.getPrivateValue(ItemRenderer.class, this, 3);
/*
    	    if (itemToRender != null)
    	    	System.out.println(String.format("itemid:%d", itemToRender.itemID));
    	    else
    	    	System.out.println(String.format("itemid:null"));
*/   
	    }
    	catch (Exception exception) {
    		System.out.println("can't get local value.");
    		super.renderItemInFirstPerson(f);
    		return;
    	}

	    // �莝���A�C�e�����t�B�M���A�Ō`��ݒ肳��Ă���Ƃ���������`��
    	if (itemToRender != null && itemToRender.itemID == mod_Figure.figure.shiftedIndex && itemToRender.getItemDamage() != 0) {
    		// ���̃R�[�h�ۃp�N��
            EntityPlayerSP entityplayersp = mc.thePlayer;
    		float f1 = prevEquippedProgress + (equippedProgress - prevEquippedProgress) * f;
            float f2 = ((EntityPlayer) (entityplayersp)).prevRotationPitch + (((EntityPlayer) (entityplayersp)).rotationPitch - ((EntityPlayer) (entityplayersp)).prevRotationPitch) * f;
    		// �e�����o�C�I�[�������̏���?�e�����������Ȃ�̂�␳
            int i = entityplayersp.getBrightnessForRender(f);
            int j = i % 0x10000;
            int k = i / 0x10000;
            OpenGlHelper.setLightmapTextureCoords(OpenGlHelper.lightmapTexUnit, (float)j / 1.0F, (float)k / 1.0F);

            GL11.glPushMatrix();
            GL11.glRotatef(f2, 1.0F, 0.0F, 0.0F);
            GL11.glRotatef(((EntityPlayer) (entityplayersp)).prevRotationYaw + (((EntityPlayer) (entityplayersp)).rotationYaw - ((EntityPlayer) (entityplayersp)).prevRotationYaw) * f, 0.0F, 1.0F, 0.0F);
            RenderHelper.enableStandardItemLighting();
            GL11.glPopMatrix();
            ItemStack itemstack = itemToRender;
            float f3 = mc.theWorld.getLightBrightness(MathHelper.floor_double(((EntityPlayer) (entityplayersp)).posX), MathHelper.floor_double(((EntityPlayer) (entityplayersp)).posY), MathHelper.floor_double(((EntityPlayer) (entityplayersp)).posZ));
            GL11.glColor4f(f3, f3, f3, 1.0F);

            GL11.glPushMatrix();
            float f5 = 0.8F;
            float f9 = entityplayersp.getSwingProgress(f);
            float f13 = MathHelper.sin(f9 * 3.141593F);
            float f17 = MathHelper.sin(MathHelper.sqrt_float(f9) * 3.141593F);
            GL11.glTranslatef(-f17 * 0.4F, MathHelper.sin(MathHelper.sqrt_float(f9) * 3.141593F * 2.0F) * 0.2F, -f13 * 0.2F);
            GL11.glTranslatef(0.7F * f5, -0.65F * f5 - (1.0F - f1) * 0.6F, -0.9F * f5);
            GL11.glRotatef(45F, 0.0F, 1.0F, 0.0F);
            GL11.glEnable(32826 /*GL_RESCALE_NORMAL_EXT*/);
            f9 = entityplayersp.getSwingProgress(f);
            f13 = MathHelper.sin(f9 * f9 * 3.141593F);
            f17 = MathHelper.sin(MathHelper.sqrt_float(f9) * 3.141593F);
            GL11.glRotatef(-f13 * 20F, 0.0F, 1.0F, 0.0F);
            GL11.glRotatef(-f17 * 20F, 0.0F, 0.0F, 1.0F);
            GL11.glRotatef(-f17 * 80F, 1.0F, 0.0F, 0.0F);
            f9 = 0.5F;//0.4F;
            GL11.glScalef(f9, f9, f9);
            GL11.glRotatef(45F, 0.0F, 1.0F, 0.0F);
    		GL11.glTranslatef(0.25F, 0.0F, -0.5F);

            renderItem(entityplayersp, itemstack, 0);
            GL11.glPopMatrix();

            RenderHelper.disableStandardItemLighting();
    	} else {
    		super.renderItemInFirstPerson(f);
    	}
    	
    }
	
}
