package net.minecraft.src;
import java.util.*;


class SortedProperties extends Properties {
  @SuppressWarnings("unchecked")
  public synchronized Enumeration keys() {
     Enumeration keysEnum = super.keys();
     Vector keyList = new Vector();
     while(keysEnum.hasMoreElements()){
       keyList.add(keysEnum.nextElement());
     }
     Collections.sort(keyList);
     return keyList.elements();
  }
}