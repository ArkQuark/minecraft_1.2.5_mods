package net.minecraft.src;

import org.lwjgl.opengl.GL11;

public class RenderFallingSand extends Render
{
    private RenderBlocks renderBlocks;

    public RenderFallingSand()
    {
        renderBlocks = new RenderBlocks();
        shadowSize = 0.5F;
    }

    /**
     * The actual render method that is used in doRender
     */
    public void doRenderFallingSand(EntityFallingSand par1EntityFallingSand, double par2, double par4, double par6, float par8, float par9)
    {
        GL11.glPushMatrix();
        GL11.glTranslatef((float)par2, (float)par4, (float)par6);
        loadTexture("/terrain.png");
        Block block = Block.blocksList[par1EntityFallingSand.blockID];
        World world = par1EntityFallingSand.getWorld();
        GL11.glDisable(GL11.GL_LIGHTING);

        if (block == Block.dragonEgg)
        {
            renderBlocks.blockAccess = world;
            Tessellator tessellator = Tessellator.instance;
            tessellator.startDrawingQuads();
            tessellator.setTranslation((float)(-MathHelper.floor_double(par1EntityFallingSand.posX)) - 0.5F, (float)(-MathHelper.floor_double(par1EntityFallingSand.posY)) - 0.5F, (float)(-MathHelper.floor_double(par1EntityFallingSand.posZ)) - 0.5F);
            renderBlocks.renderBlockByRenderType(block, MathHelper.floor_double(par1EntityFallingSand.posX), MathHelper.floor_double(par1EntityFallingSand.posY), MathHelper.floor_double(par1EntityFallingSand.posZ));
            tessellator.setTranslation(0.0D, 0.0D, 0.0D);
            tessellator.draw();
        }
        else
        {
            myRenderBlockFallingSand(block, par1EntityFallingSand.meta, renderBlocks, world, MathHelper.floor_double(par1EntityFallingSand.posX), MathHelper.floor_double(par1EntityFallingSand.posY), MathHelper.floor_double(par1EntityFallingSand.posZ));
        }

        GL11.glEnable(GL11.GL_LIGHTING);
        GL11.glPopMatrix();
    }

    public void myRenderBlockFallingSand(Block par1Block, int meta, RenderBlocks rb, World par2World, int par3, int par4, int par5)
    {
        int colmul = par1Block.colorMultiplier(par2World, par3, par4, par5);
        
        if(par1Block.blockID == Block.sand.blockID){
            colmul = par1Block.getRenderColor(meta);        
        }
        
        float cr = (float)(colmul >> 16 & 0xff) / 255F;
        float cg = (float)(colmul >> 8 & 0xff) / 255F;
        float cb = (float)(colmul & 0xff) / 255F;

        float f = 0.5F;
        float f1 = 1.0F;
        float f2 = 0.8F;
        float f3 = 0.6F;
        Tessellator tessellator = Tessellator.instance;
        tessellator.startDrawingQuads();
        tessellator.setBrightness(par1Block.getMixedBrightnessForBlock(par2World, par3, par4, par5));
        float f4 = 1.0F;
        float f5 = 1.0F;

        if (f5 < f4)
        {
            f5 = f4;
        }

        tessellator.setColorOpaque_F(f1 * cr, f1 * cg, f1 * cb);
        rb.renderTopFace(par1Block, -0.5D, -0.5D, -0.5D, par1Block.getBlockTextureFromSideAndMetadata(1, meta));
        f5 = 1.0F;

        if (f5 < f4)
        {
            f5 = f4;
        }

        if(par1Block.blockID == Block.grass.blockID){
            cr=1F; cg=1F; cb=1F;
        }

        tessellator.setColorOpaque_F(f * cr, f * cg, f * cb);
        rb.renderBottomFace(par1Block, -0.5D, -0.5D, -0.5D, par1Block.getBlockTextureFromSideAndMetadata(0, meta));
        f5 = 1.0F;

        if (f5 < f4)
        {
            f5 = f4;
        }

        tessellator.setColorOpaque_F(f2 * cr, f2 * cg, f2 * cb);
        rb.renderEastFace(par1Block, -0.5D, -0.5D, -0.5D, par1Block.getBlockTextureFromSideAndMetadata(2, meta));
        f5 = 1.0F;

        if (f5 < f4)
        {
            f5 = f4;
        }

        tessellator.setColorOpaque_F(f2 * cr, f2 * cg, f2 * cb);
        rb.renderWestFace(par1Block, -0.5D, -0.5D, -0.5D, par1Block.getBlockTextureFromSideAndMetadata(3, meta));
        f5 = 1.0F;

        if (f5 < f4)
        {
            f5 = f4;
        }

        tessellator.setColorOpaque_F(f3 * cr, f3 * cg, f3 * cb);
        rb.renderNorthFace(par1Block, -0.5D, -0.5D, -0.5D, par1Block.getBlockTextureFromSideAndMetadata(4, meta));
        f5 = 1.0F;

        if (f5 < f4)
        {
            f5 = f4;
        }

        tessellator.setColorOpaque_F(f3 * cr, f3 * cg, f3 * cb);
        rb.renderSouthFace(par1Block, -0.5D, -0.5D, -0.5D, par1Block.getBlockTextureFromSideAndMetadata(5, meta));
        tessellator.draw();
    }



    public void doRender(Entity par1Entity, double par2, double par4, double par6, float par8, float par9)
    {
        doRenderFallingSand((EntityFallingSand)par1Entity, par2, par4, par6, par8, par9);
    }
}
