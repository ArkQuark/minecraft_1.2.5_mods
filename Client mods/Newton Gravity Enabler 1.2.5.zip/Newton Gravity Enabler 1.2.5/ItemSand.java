// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) braces deadcode 

package net.minecraft.src;


// Referenced classes of package net.minecraft.src:
//            ItemBlock, Block, BlockCloth, ItemDye, 
//            ItemStack

public class ItemSand extends ItemBlock
{

    public ItemSand(int i)
    {
        super(i);
        setMaxDamage(0);
        setHasSubtypes(true);
    }

    public int getIconFromDamage(int i)
    {
        return Block.sand.getBlockTextureFromSideAndMetadata(2, i);
    }

    public int getMetadata(int i)
    {
        return (i==0 || i==15)?0:BlockSand.MAXWET;
    }

    public String getItemNameIS(ItemStack itemstack)
    {
        if(itemstack.getItemDamage()==0 || itemstack.getItemDamage()==15){
	    return super.getItemName();
        }
        //System.out.println((new StringBuilder()).append(super.getItemName()).append(".").append("wet").toString());
        return (new StringBuilder()).append(super.getItemName()).append(".").append("wet").toString();
    }
}
