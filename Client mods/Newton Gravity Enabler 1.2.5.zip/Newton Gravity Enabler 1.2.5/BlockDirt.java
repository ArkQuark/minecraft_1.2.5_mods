package net.minecraft.src;

public class BlockDirt extends BlockSand
{
    protected BlockDirt(int par1, int par2)
    {
        super(par1, par2, Material.ground);
    }

//     public boolean canHangOn(World world, int i, int j, int k){
//         return world.getBlockId(i,j,k) == Block.dirt.blockID || world.getBlockId(i,j,k) == Block.grass.blockID || world.getBlockId(i,j,k) == Block.tilledField.blockID;
//     }
}
