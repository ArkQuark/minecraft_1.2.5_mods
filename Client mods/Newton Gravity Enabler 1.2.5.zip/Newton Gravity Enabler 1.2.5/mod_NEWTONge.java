package net.minecraft.src;
import net.minecraft.client.Minecraft;
import java.util.*;
import java.io.*;

public class mod_NEWTONge extends BaseMod{

    public static int wetSandTexture;
    public static SortedProperties cfg = new SortedProperties();
    public static boolean propsLoaded=false;
    public static boolean mustSave=false;
    private static Minecraft mc = ModLoader.getMinecraftInstance();
    
    public static boolean canFall(String name){
        if(!propsLoaded){
            boolean propsOk=true;
            try {
                cfg.load(new FileInputStream(mc.getMinecraftDir() + "/config/NEWTON.cfg"));
            } catch (IOException e) {
                cfg = new SortedProperties();
                mustSave=true;
            }
        }
        
        String t = cfg.getProperty("FALL_"+name);
        if(t==null){
            cfg.setProperty("FALL_"+name,"True");
            mustSave=true;
            t="true";
        }
        return t.toLowerCase().equals("true");
    }

    public static void saveCfg(){
        if(mustSave){
            try {
                cfg.store(new FileOutputStream(mc.getMinecraftDir() + "/config/NEWTON.cfg"), "NEWTON gravity enabler mod CFG file.\nMod by MightyPork.");
            } catch (IOException e) {
            }
        }
    }

    public mod_NEWTONge()
    {}
    
    public void load(){

        Item.itemsList[Block.sand.blockID] = null;
        Item.itemsList[Block.sand.blockID] = (new ItemSand(Block.sand.blockID - 256)).setItemName("sand");
        System.out.println(
"\n\n"+
"***********************************\n"+
"*   \"NEWTON\" -  GRAVITY ENABLER   *\n"+
"*        by MightyPork            *\n"+
"***********************************\n"+
"\nMod, which adds realistic gravity and lets you build sandcastles.\n\n"
);
    
	//names        
	ModLoader.addLocalization("tile.sand.wet.name","Wet Sand");
	ModLoader.addShapelessRecipe(new ItemStack(Block.sand,1,1), new Object[] {Item.bucketWater, Block.sand});
	ModLoader.addShapelessRecipe(new ItemStack(Block.sand,2,1), new Object[] {Item.bucketWater, Block.sand, Block.sand});
	ModLoader.addShapelessRecipe(new ItemStack(Block.sand,3,1), new Object[] {Item.bucketWater, Block.sand, Block.sand, Block.sand});
	ModLoader.addShapelessRecipe(new ItemStack(Block.sand,4,1), new Object[] {Item.bucketWater, Block.sand, Block.sand, Block.sand, Block.sand});
	ModLoader.addShapelessRecipe(new ItemStack(Block.sand,5,1), new Object[] {Item.bucketWater, Block.sand, Block.sand, Block.sand, Block.sand, Block.sand});
	ModLoader.addShapelessRecipe(new ItemStack(Block.sand,6,1), new Object[] {Item.bucketWater, Block.sand, Block.sand, Block.sand, Block.sand, Block.sand, Block.sand});
	ModLoader.addShapelessRecipe(new ItemStack(Block.sand,7,1), new Object[] {Item.bucketWater, Block.sand, Block.sand, Block.sand, Block.sand, Block.sand, Block.sand, Block.sand});
	ModLoader.addShapelessRecipe(new ItemStack(Block.sand,8,1), new Object[] {Item.bucketWater, Block.sand, Block.sand, Block.sand, Block.sand, Block.sand, Block.sand, Block.sand, Block.sand});
    }

    public String getVersion()
    {
	return "1.2.3";
    }
}
