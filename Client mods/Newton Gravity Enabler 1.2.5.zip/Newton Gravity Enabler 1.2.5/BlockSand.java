package net.minecraft.src;

import java.util.Random;

public class BlockSand extends Block
{
    public static final int MAXWET = 5;
    public static final int DRYING_CHANCE = 10;
    private boolean canFall=true;

    /** Do blocks fall instantly to where they stop or do they fall over time */
    public static boolean fallInstantly = false;
    
    public boolean sticky=true;
    /** Block is STICKY if it can use 2-sides and on-wall rules 
     *  only TRUE GRAVITY BLOCKS have this disabled, while sand has its own special rules if its wet.
     */
    public Block setSticky(boolean state){
        sticky=state;
        return this;
    }

    public boolean isSticky(){
        return sticky;
    }

    public Block setBlockName(String par1Str)
    {
        super.setBlockName(par1Str);
        
        
        //if not sand/gravel, check property whether it shall fall.
        if(blockID != 12 && blockID != 13){
            canFall = mod_NEWTONge.canFall(par1Str);
        }
        
        return this;
    }

    public BlockSand(int par1, int par2) //used only by sand and gravel
    {
        super(par1, par2, Material.sand);
        setTickRandomly(true);
        setSticky(false); //sand and gravel
    }

    public BlockSand(int par1, int par2, Material par3Material)
    {
        super(par1, par2, par3Material);
        setTickRandomly(true);
    }

    public BlockSand(int par1, Material par3Material)
    {
        super(par1, par3Material);
        setTickRandomly(true);
    }

    public int getBlockTextureFromSideAndMetadata(int i, int j)
    {
        return blockIndexInTexture;
    }

    public int getBlockColor()
    {
        return 0xffffff;
    }

    public int getRenderColor(int par1)
    {
        if(Block.sand.blockID != blockID){return 0xffffff;}
        if(par1>0 && par1<15) return 0xccccaa;
        return 0xffffff;
    }

    public int colorMultiplier(IBlockAccess par1IBlockAccess, int par2, int par3, int par4)
    {
        if(Block.sand.blockID != blockID){return 0xffffff;}
        
        int meta = par1IBlockAccess.getBlockMetadata(par2,par3,par4);
        if(meta>0 && meta<15) return 0xccccaa;
        return 0xffffff;
    }



    protected int damageDropped(int i)
    {
        if(Block.sand.blockID != blockID){return i;}
        if(i==0 || i==15){return 0;}
        else{return MAXWET;}
    }

    public void onBlockPlacedBy(World world, int i, int j, int k, EntityLiving entityliving)
    {
        world.scheduleBlockUpdate(i, j, k, blockID, 3);
    }

    public void onBlockAdded(World world, int i, int j, int k)
    {
        if(Block.sand.blockID == blockID && waterNearby(world,i,j,k)){world.setBlockMetadataWithNotify(i,j,k,MAXWET);}
        //world.scheduleBlockUpdate(i, j, k, blockID, 3);
    }

    public void onNeighborBlockChange(World world, int i, int j, int k, int l)
    {
        world.scheduleBlockUpdate(i, j, k, blockID, 3);
    }

    public void onFallenUpon(World world, int i, int j, int k, Entity entity, float f)
    {
        if(canFall){
            tryToFall(world, i, j, k);
        }        
    }

    public void onEntityWalking(World world, int i, int j, int k, Entity entity)
    {
        if(canFall){
            tryToFall(world, i, j, k);
        }  
    }

    public void updateTick(World world, int i, int j, int k, Random random)
    {
        if(Block.sand.blockID == blockID){
            tryToMoisten(world, i, j, k);
            if(random.nextInt(DRYING_CHANCE)==0 && isWet(world,i,j,k) && !waterNearby(world,i,j,k) && !world.worldInfo.isRaining()){ //drying up
                int newmeta=world.getBlockMetadata(i,j,k)-1;
                if(newmeta<=0){newmeta=15;}
                world.setBlockMetadata(i,j,k,newmeta);
                world.markBlockNeedsUpdate(i,j,k);
                return;
            }
        }
        
        if(canFall && ((blockID == 13 || blockID == 14) || !BlockSand.fallInstantly)){
            tryToFall(world, i, j, k);
        }
    }

    public void tryToMoisten(World world, int i, int j, int k){
        if(Block.sand.blockID != blockID){return;}
        for(int I=-1; I<2; I++){
        for(int J=-1; J<2; J++){
        for(int K=-1; K<2; K++){
            int id = world.getBlockId(i+I,j+J,k+K);
            if(id == Block.waterMoving.blockID || id == Block.waterStill.blockID){
                world.setBlockMetadata(i,j,k,MAXWET);
                world.markBlockNeedsUpdate(i,j,k);
                return;
            }
            if(world.getBlockMetadata(i,j,k)!=15 && world.getBlockMetadata(i,j,k)!=0 && id == Block.lavaMoving.blockID || id == Block.lavaStill.blockID || id == Block.fire.blockID){
                world.setBlockMetadata(i,j,k,0);
                world.markBlockNeedsUpdate(i,j,k);
                return;
            }
        }
        }
        }
    }

    public boolean waterNearby(World world, int i, int j, int k){
        for(int I=-1; I<2; I++){
        for(int J=-1; J<2; J++){
        for(int K=-1; K<2; K++){
            int id = world.getBlockId(i+I,j+J,k+K);
            if(id == Block.waterMoving.blockID || id == Block.waterStill.blockID){
                return true;
            }
        }
        }
        }
        return false;
    }

    public boolean canHangOn(World world, int i, int j, int k){
        return Block.blocksList[world.getBlockId(i,j,k)] != null && Block.blocksList[world.getBlockId(i,j,k)].blockMaterial.isSolid(); //world.getBlockId(i,j,k) == blockID;
    }

    private boolean isSuperSticky(World world, int i, int j, int k){
        return world.getBlockId(i,j,k) == Block.slowSand.blockID;     
    }

    private boolean isWet(World world, int i, int j, int k){
        int meta = world.getBlockMetadata(i,j,k);
        return meta >= 1 && meta < 15; //15...dried up.
    }

    private boolean isPistonDirect(World world, int i, int j, int k, int side){
        return world.getBlockId(i-Facing.offsetsXForSide[side],j-Facing.offsetsYForSide[side],k-Facing.offsetsZForSide[side])==Block.pistonStickyBase.blockID && (world.getBlockMetadata(i-Facing.offsetsXForSide[side],j-Facing.offsetsYForSide[side],k-Facing.offsetsZForSide[side])&7)==side;
    }

    private boolean isPistonStickyHead(World world, int i, int j, int k, int side){
        return world.getBlockId(i-Facing.offsetsXForSide[side],j-Facing.offsetsYForSide[side],k-Facing.offsetsZForSide[side])==Block.pistonExtension.blockID && (world.getBlockMetadata(i-Facing.offsetsXForSide[side],j-Facing.offsetsYForSide[side],k-Facing.offsetsZForSide[side])&7)==side && world.getBlockId(i-Facing.offsetsXForSide[side]*2,j-Facing.offsetsYForSide[side]*2,k-Facing.offsetsZForSide[side]*2)==Block.pistonStickyBase.blockID;
    }

    public boolean isHanging(World world, int i, int j, int k){
        
        int nearby = (canHangOn(world,i-1,j,k)?1:0) + (canHangOn(world,i+1,j,k)?1:0) + (canHangOn(world,i,j,k-1)?1:0) + (canHangOn(world,i,j,k+1)?1:0);
        
        return 
            nearby >= 2 || 
            (canHangOn(world,i-1,j,k) && canHangOn(world,i-1,j-1,k)) || // near and under
            (canHangOn(world,i+1,j,k) && canHangOn(world,i+1,j-1,k)) ||
            (canHangOn(world,i,j,k-1) && canHangOn(world,i,j-1,k-1)) ||
            (canHangOn(world,i,j,k+1) && canHangOn(world,i,j-1,k+1));
    }

    private void tryToFall(World world, int i, int j, int k)
    {
        int l = i;
        int i1 = j;
        int j1 = k;
        int metadata = world.getBlockMetadata(i,j,k);
        
        if(isSuperSticky(world,i-1,j,k) ||
            isSuperSticky(world,i+1,j,k) ||
            isSuperSticky(world,i,j,k-1) ||
            isSuperSticky(world,i,j,k+1)){return;}
            

        //hang if its sticky or wet sand
        if((Block.sand.blockID == blockID || sticky) && isHanging(world,i,j,k) && (metadata > 0 || sticky)){return;}

        boolean hangingOnPiston = 
        isPistonDirect(world,i,j,k,2) || 
        isPistonDirect(world,i,j,k,3) || 
        isPistonDirect(world,i,j,k,4) || 
        isPistonDirect(world,i,j,k,5) || 
        isPistonDirect(world,i,j,k,0) ||
        isPistonStickyHead(world,i,j,k,2) || 
        isPistonStickyHead(world,i,j,k,3) || 
        isPistonStickyHead(world,i,j,k,4) || 
        isPistonStickyHead(world,i,j,k,5) || 
        isPistonStickyHead(world,i,j,k,0);
        
        if(hangingOnPiston) return;

        if(canFallBelow(world, l, i1 - 1, j1) && i1 >= 0)
        {
            byte byte0 = 32;
            if(BlockSand.fallInstantly || !world.checkChunksExist(i - byte0, j - byte0, k - byte0, i + byte0, j + byte0, k + byte0))
            {
                world.setBlockWithNotify(i, j, k, 0);
                for(; canFallBelow(world, i, j - 1, k) && j > 0; j--) { }
                if(j > 0)
                {
                    world.setBlockAndMetadataWithNotify(i, j, k, blockID, metadata);
                }
            } else
            {
                EntityFallingSand entityfallingsand = new EntityFallingSand(world, (float)i + 0.5F, (float)j + 0.5F, (float)k + 0.5F, blockID);
                world.spawnEntityInWorld(entityfallingsand);
                entityfallingsand.meta=metadata;
                if(Block.sand.blockID == blockID){entityfallingsand.meta=(metadata==15)?0:metadata;}
            }
        }
    }

    public int tickRate()
    {
        return 5;
    }


    public static boolean canFallBelow(World par0World, int par1, int par2, int par3)
    {
        int i = par0World.getBlockId(par1, par2, par3);

        if (i == 0)
        {
            return true;
        }

        if (i == Block.fire.blockID)
        {
            return true;
        }

        Material material = Block.blocksList[i].blockMaterial;

        if (material == Material.water)
        {
            return true;
        }

        return material == Material.lava;
    }
}
