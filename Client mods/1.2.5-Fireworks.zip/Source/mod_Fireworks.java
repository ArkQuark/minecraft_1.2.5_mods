package net.minecraft.src;

public class mod_Fireworks extends BaseMod{
	
	
    @Override
	public String getVersion() 
	{
		return "1.6";
	}

    public mod_Fireworks() 
	{
        ModLoader.registerBlock(fireworks);
		ModLoader.addName(fireworks, "Fireworks");
		ModLoader.addRecipe(new ItemStack(fireworks), new Object[] 
		{
            "# #", "#%#", "###",
            '#', Item.ingotIron, '%', Block.torchRedstoneActive
        });
		
    }
	
	
    public static final Block fireworks;
	public static FireworksSkyrocketManager props = new FireworksSkyrocketManager();
    static
    {
		int topTexture = ModLoader.addOverride("/terrain.png", "/Fireworks/FireworksTop.png"); 
		int sideTexture = ModLoader.addOverride("/terrain.png", "/Fireworks/FireworksSide.png");
        fireworks = (new FireworksLauncher(props.blockID, topTexture, sideTexture, props)).setHardness(1.0F).setStepSound(Block.soundStoneFootstep).setBlockName("Fireworks");
		
    }
	@Override
	public void load() {
		// TODO Auto-generated method stub
		
	}
}