package net.minecraft.src;

import java.io.*;
import java.lang.reflect.Field;
import java.util.*;
import net.minecraft.client.Minecraft;
import org.lwjgl.input.Keyboard;

public class FireworksSkyrocketManager {
    public String modname = "Fireworks";
    public File dir;
    //public File config;
	public File[] config;
	
	public String skyrockets[] = {
        "_Example.skyrocket",
        "OrangeDream.skyrocket", 
		"SilverWillow.skyrocket", 
		"SmallBlue.skyrocket", 
		"SmallBlueSphere.skyrocket", 
		"SmallGreen.skyrocket", 
		"SmallGreenSphere.skyrocket", 
		"SmallPurple.skyrocket", 
		"SmallPurpleSphere.skyrocket", 
		"SmallRed.skyrocket", 
		"SmallRedSphere.skyrocket", 
		"SmallYellow.skyrocket", 
		"SmallYellowSphere.skyrocket", 
		
    };
	

	String[][] allSettings;
	int blockID = 175;
	
	
    public Map classToStringMapping;
    public Map<Class<? extends EntityLiving>, Integer> weights = new HashMap<Class<? extends EntityLiving>, Integer>();
    public Map<Class<? extends EntityLiving>, EnumCreatureType> types  = new HashMap<Class<? extends EntityLiving>, EnumCreatureType>();
	
    public FireworksSkyrocketManager() {

        dir = Minecraft.getAppDir("minecraft/mods/"+modname+"/Skyrockets/");

        if (!dir.exists()) 
            dir.mkdirs();
		
		if(dir.listFiles().length < 1) {
			System.out.println("Directory is empty, creating new skyrockets");
			forceInstall();
		}
      	
		config = dir.listFiles();
		setBlockID();
		loadConfig();
      
    }
	
	/*
    public Properties getCurrentProperties()  {
        Properties props = new Properties();
     	for (Class<? extends EntityLiving> c: weights.keySet()) {
            props.setProperty((String)classToStringMapping.get(c), Integer.toString(weights.get(c)));
        }
	        return props;
    }
	*/
	public void setBlockID() {
		File dir2 = Minecraft.getAppDir("minecraft/mods/"+modname+"/");
		File file2 = new File(dir2, "BlockID.txt");
		
		try {
			if (!file2.exists()) {
				FileWriter fstream = new FileWriter(file2,true);
				BufferedWriter out = new BufferedWriter(fstream);
				out.write(Integer.toString(blockID));
				out.close();
				System.out.println("BockID.txt created.");
			}
			FileReader fstream2 = new FileReader(file2);
			BufferedReader in = new BufferedReader(fstream2);
			
			blockID = Integer.valueOf(in.readLine());
			System.out.println("BlockID is now: " + blockID);
		} 	
		catch (IOException e) {
			System.out.println(e);
		}
	}
	
    public void loadConfig() {
		File[] allSkyrockets = dir.listFiles();
		Properties[] props = new Properties[allSkyrockets.length];
		for(int i = 0; i < allSkyrockets.length; i++) {
			props[i] = new Properties();
		}
		for(int i = 0; i < allSkyrockets.length; i++) {
		
			if (!config[i].exists() || !config[i].canRead() || !config[i].isFile()) {
				System.out.println(modname+": couldn't load config");
				return;
			}

			
			FileInputStream in = null;

			try {
				in = new FileInputStream(config[i]);
				props[i].load(in);
			} catch (IOException e) {
				System.out.println(modname+": couldn't load config");
				return;
			} finally {
				if (in != null) {
					try {
						in.close();
					} catch (IOException e) {}
				}
			}
		}	
		loadConfig(props);
		
    }
	
    public void loadConfig(Properties[] props) 
	{   
		File[] allSkyrockets = dir.listFiles();
		allSettings = new String[allSkyrockets.length][28];
		for(int i = 0; i < props.length; i++) {
			allSettings[i][0] = props[i].getProperty("xMotion");
			allSettings[i][1] = props[i].getProperty("yMotion");
			allSettings[i][2] = props[i].getProperty("zMotion");
			allSettings[i][3] = props[i].getProperty("red");
			allSettings[i][4] = props[i].getProperty("green");
			allSettings[i][5] = props[i].getProperty("blue");
			allSettings[i][6] = props[i].getProperty("redTarget");
			allSettings[i][7] = props[i].getProperty("greenTarget");
			allSettings[i][8] = props[i].getProperty("blueTarget");
			allSettings[i][9] = props[i].getProperty("cRange");
			allSettings[i][10] = props[i].getProperty("numberOfSubrockets");
			allSettings[i][11] = props[i].getProperty("ageRocket");
			allSettings[i][12] = props[i].getProperty("ageSubrocket");
			allSettings[i][13] = props[i].getProperty("ageParticles");
			allSettings[i][14] = props[i].getProperty("particleSize");
			allSettings[i][15] = props[i].getProperty("emitParticles");
			allSettings[i][16] = props[i].getProperty("explosionStrength");
			allSettings[i][17] = props[i].getProperty("gravity");
			allSettings[i][18] = props[i].getProperty("type");
			allSettings[i][19] = props[i].getProperty("motionRandom");
			allSettings[i][20] = props[i].getProperty("redRandom");
			allSettings[i][21] = props[i].getProperty("greenRandom");
			allSettings[i][22] = props[i].getProperty("blueRandom");
			allSettings[i][23] = props[i].getProperty("redTRandom");
			allSettings[i][24] = props[i].getProperty("greenTRandom");
			allSettings[i][25] = props[i].getProperty("blueTRandom");
			allSettings[i][26] = props[i].getProperty("ageRandom");
			allSettings[i][27] = props[i].getProperty("strengthRandom");
		}
		
		String[] allFireworks = dir.list();
			for(int j = 0; j < allFireworks.length; j++) {
				System.out.println(allFireworks[j]);
			}
	}
		

	
	public boolean forceInstall() {
        return install(true);
    }
	
	public boolean install(boolean force) 
	{
		boolean allInstalled = true;
        for (String f: skyrockets) {
            allInstalled = allInstalled && install(f, force);
        }
        return allInstalled;
    }
		
		
		
	public boolean install(String f, boolean force) {
        File file = new File(dir, f);

        if (file.exists()) {
            if (force) {
                System.err.println("Overwriting "+f);
            } else {
                System.err.println("Not creating "+f+", already exists.");
                return false;
            }
        }

        System.err.println("Creating "+file);
        OutputStream o = null;
        InputStream i = null;

        try {
            o = new FileOutputStream(file);
            i = mod_Fireworks.class.getResourceAsStream("/Fireworks/Skyrockets/"+f);
            byte[] b = new byte[4096];
            int read;

            while ((read = i.read(b)) != -1) {
                o.write(b, 0, read);
            }

            o.flush();
        } catch (IOException e) {
            System.err.println("bsh: can't create "+file);
            e.printStackTrace();
            return false;
        } finally {
            try {
                if (o!=null) o.close();

                if (i!=null) i.close();
            } catch (Throwable e) {}
        }

        return true;
    }
}
