Fireworks, by Mr.6 aka Mysticyx.

INSTALLATION:
 1. Get modloader AND audiomod at:
    http://www.minecraftforum.net/viewtopic.php?t=80246
    and install it.
 2. Delete the META-INF folder.
 3. Put the CONTENTS of the folders into the right places, replace all.
     so the contents of:
       CONTENTS IN .MINECRAFT FOLDER go into /AppData/Roaming/.minecraft/
     and the contents of:
       CONTENTS IN JAR go into the the minecraft.jar
 4. Run minecraft!
 5. OPTIONAL: Change the BlockID (currently 110) by changing the 
    number in .minecraft/mods/Fireworks/BlockID.txt


HOW TO MAKE YOUR OWN FIREWORKS:
 1. Run the game with the mod installed at least once.
 2. Go to .minecraft/mods/Fireworks/Skyrockets
 3. There you will see all the different types of skyrockets the mod 
    currently has. 
 4. Copy _Example.skyrocket, rename it and open it. They have the 
    .skyrocket-extension, but just open them with notepad or any other
    .txt-editor.
 5. Here you see all the variables that can be changed. Every variable
    has #comments which tell you what happens and what a reasonable
    range is.
 6. Experiment!
 7. Save!
 8. OPTIONAL: remove the other files if you want your rocket to be the
    only rocket in game, usefull for testing.
 9. Run the game!


SHARE THEM WITH ME:
Did you make anything cool? Take a screenshot and email both the
screenshot and the .skyrocket-file to me:
 fireworksmod@gmail.com

If I like it, I will add it to the frontpage of the forumthread, and include
it in a later update!


HELP! THE GAME CRASHES WHEN I LAUNCH IT AFTER CREATING MY OWN ROCKET!
 Sorry, I should have added proper mistake-detection.
 You did something wrong, like giving red a value of "any_nonnumber_here"
 Fix it by deleting the Skyrockets folder (see step 2).
 Run the game, a new folder will be created.


RECIPE:
iron               iron
iron redstonetorch iron
iron     iron      iron


CREDITS:
Extrusion - for helping me with the renderdistance-problem.
_303 - for helping me with ALL my other (mod-related) problems.
King Dedede - for the willow idea.
cybrbeast - for the crossette idea.
Andreas_H33 - for the crafting recipe.