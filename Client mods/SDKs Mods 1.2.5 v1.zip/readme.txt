SDK's Mods

http://www.minecraftforum.net/viewtopic.php?f=25&t=92206