FlowerChild's Better Than Wolves Mod V3.59
(Compatible with Minecraft Version 1.2.5)

[*** COPYRIGHT NOTICE ***]
 This document and the files contained in this package are Copyright �(2011, 2012) and is the intellectual property of the author. It may not be reproduced under any circumstances except for personal, private use as long as it remains in its unaltered, unedited form. It may not be placed on any web site or otherwise distributed publicly without advance written permission. Use of this mod on any other website is strictly prohibited, and a violation of copyright.
 
Note: I DO NOT grant redistribution rights to this mod to anyone that asks, whether that be for a mod-pack or whatever. Don't bother asking, as it won't happen.
[************************]

For detailed item descriptions (including crafting recipes), an up to date version of this mod, video feature demonstrations, and other useful info, please consult the following thread in the Minecraft forums:

http://www.minecraftforum.net/viewtopic.php?f=1032&t=275333

****** Installation Instructions ******

1) Make sure minecraft is not running.
2) Install Risugami's ModLoader (http://www.minecraftforum.net/viewtopic.php?f=1032&t=80246)
3) Open your minecraft.jar with Winrar or other program
4) Delete the META-INF folder in minecraft.jar (you should have already done this when you installed ModLoader)
5) Copy all the files and folders in this mod's MINECRAFT-JAR folder into your minecraft.jar (overwriting any existing files).
...
8) Profit!

NOTE: This mod can NOT be installed by using the ModLoader method of simply copying this zip file into the ".minecraft/mods/" folder.  It modifies base classes, and thus this ModLoader functionality can not be supported (as explicitly stated in the ModLoader documentation).  You MUST copy the appropriate files into minecraft.jar as described above for this mod to function properly.

***OPTIONAL***

-FOR ADVANCED USERS ONLY: If you want to remap the block and item ids to ensure compatibility with another mod copy BTWConfig.txt into your \.minecraft folder and edit it to your liking.  WARNING: Make sure you know what you're 
doing if you attempt this.  Tampering with this file can corrupt save games and result in crashes if you screw up.  YOU HAVE BEEN WARNED.

********* Compatibility Information **********

Better Than Wolves is designed as a standalone mod and as such does not support compatibility with any other.  Existing compatibly with any given mod is purely coincidental and may be removed without notice in future updates.

********* Minecraft Forge **********

Minecraft Forge is not required to be installed for this mod to function (installing it separately will actually interfere with the proper functioning of this mod).  However, BTW contains several Forge files.

The following files are direct copies of those found in the 1.3 release of Forge, and the source code for them may be found here, as per the Forge license:

http://www.minecraftforum.net/topic/514000-api-minecraft-forge/

forge/BlockTextureParticles.java
forge/ICustomItemRenderer.java
forge/IMultipassRender.java
forge/IRenderContextHandler.java
forge/ISidedInventory.java
forge/ITextureProvider.java

Additionally, the following files are modified versions of those found in version 1.3 of the Forge, and the source code for them is included along with the mod download (in the FORGE-SRC directory):

forge/ForgeHooksClient.java
forge/MinecraftForgeClient.java

********** Change Log ************

Version 3.59

-Updated to version 1.2.5 of Minecraft.
-Added support for jungle trees into the mod.  This includes things like growing them on Planters, and in front of Detector Blocks.
-Added the ability for sideways-facing Siding to transmit Turntable rotation to the block above.
-Added ability to overpower *any* mechanical device that is hooked up directly to a Wind Mill during a storm.  This generally results in breakage of the device, but it also opens up the possibility for other effects as it provides a general interface to do so for the eventual mod API.
-Added code back in for breaking attached Axles when a Gear Box is rotated on a Turntable.  I hated what that change in a recent release did to the mechanical system.  This applies to other mechanically powered blocks, like the Bellows and Saw, as well.
-Fixed splash-screen texts referencing the "Cauldron" instead of the "Stewing Pot".
-Fixed problem with being able to place lily pads on Planters.
-Fixed problem with Water Wheels & Wind Mills staying in place if the Axle they're attached to is rotated to an alignment that no longer supports them.
-Removed mod code for shift-clicking to the furnace, since that is now done in vanilla MC.

Version 3.58

-Updated to verstion 1.2.4 of Minecraft.
-Changed Blood Wood logs to craft into reddish planks (same as jungle trees).
-Changed the Saw to output planks of the appropriate color when cutting logs.
-Removed Mojang's new code for saving and loading the sit state of pets, as it was bugged and caused wolves to stand up when they weren't supposed to on chunk load.  I've reverted it back to the way it previously was, in which pets would always be sitting on load to fix this.
-Removed all trace of the juicy stuff I'm working on for the April 10th release, so don't bother looking :)

Version 3.57

-Added a separate block ID for Soulforged Steel so that it has its own unique (and rather interesting) properties.  Old blocks will need to be harvested and placed before they exhibit the new attributes.
-Fixed problem with netherwart constantly popping off of Planters.
-Fixed problem with Lens beams not properly propagating into the space in front of a Detector Block if that space was previously occupied by a block.
-Fixed problem with Lens beams not properly propagating through a series of Lenses spaced 1-apart if that beam was then interrupted by an entity.
-Changed creative mode functionality so that mod blocks from other mods don't automatically appear in the creative inventory, as it was causing a crash with Millenaire when the inventory was accessed.
-Changed the internals of the mod-block facing-code to better integrate with BC's Builders in BTB.

Version 3.56

-Added 2 extra inventory slots for rope to the Pulley to accommodate the new map height introduced in Minecraft 1.2.
-Added code back into the mod to prevent sitting wolves from standing to attack when their owner was attacked by a monster, or attacked one.  This was removed in a previous release due to the AI-rewrite in 1.2.
-Fixed problem with the Crucible not detecting stoked fire under it when it is first placed.
-Fixed problem with not being able to light fires in front of a Detector Block, or in a Lens beam, with flint & steel.

Version 3.55

-Added the ability to consume Foul Food.
-Added occasional subtle random creak sounds to Axles when powered to provide general ambiance to large mechanical devices.
-Changed Bloodwood Sapling recipe so that it now include a Jungle Sapling, and it is performed in the Cauldron instead of on a Workbench.
-Change Donuts so that they can always be consumed regardless of hunger level.  They're junk-food afterall.
-Changed tamed Wolves and Cats so that they always recognize the player in SSP as being their owner, regardless of whether it's the same player that originally tamed them.
-Changed pets (Wolves and Cats) so that they teleport *behind* the player instead of just randomly around when they are following you.  This should help prevent them from getting under-foot while you are walking around.
-Changed the sound of the Gear Box powering-up to be a creaking rather than a bang.
-Removed the Ocelot's ability to eat fish laying on the ground as it was causing bugs with untamed Ocelots entering breeding mode and was not an intentional feature.  I'll likely do something with this in the future, but for now they can only be fed by hand.
-Fixed problem with the player not having infinite enchanting levels in Creative Mode.

Version 3.54

-Fixed problem introduced in last release where the animal birthing process would no longer produce particles or sound effects.
-Fixed problem introduced in last release where animals wearing Breeding Harnesses could still move around.

Version 3.53

-Updated to version 1.2.3 of Minecraft.  WARNING:  This was a hellish update and it wouldn't surprise me if it introduced bugs.  Please make sure to backup your savegames before installing.
-Fixed problem with the Lens using the Slats texture when it projected a beam onto a solid surface.
-Fixed vanilla map-conversion crash-bug that would result from slabs at height level 128 on old maps.
-Removed many of the tweaks the mod made to wolf behavior due to the rewrite of Minecraft's AI system.  These will be readded to the mod (if necessary) in the future once the dust settles on the AI code.

Version 3.52

-Added Nether Sludge and Nether Bricks as new items.
-Added the ability to use the Lens as a light-level detector when used in combination with a Detector Block.  Just point a Lens directly at a Detector Block (in a neighboring block), and off you go!
-Added a placeable version of the Slats (see name change of Rollers below) that functions in the same way as iron bars or glass panes.
-Added ability to create Potash out of Blood Wood (1 to 1), and Saw/Soul Dust (16 to 1 ).
-Added the ability to shift-click items into the Anvil crafting-grid.  Also added this same functionality to the vanilla workbench, and furnace.  This should make mass crafting, particularly of storage-type blocks, much more convenient.
-Added the ability to render Ink Sacks into glue at an 8 to 1 conversion ratio.
-Added the ability to rotate the following blocks on the Turntable (if they have the correct orientations to make this possible): Anchor, Siding, Moulding, Corner.
-Added the ability for the Block Dispenser to spit out items into blocks that are normally "replaceable" (eg. water, lava, snow, etc.).  It should now eject items under the same circumstances under which it can place blocks.
-Added a separate texture for the top block of Hemp plants.  This is to allow texture-pack creators to create an independent image for the top, but I also made a slight change to the default texture to take advantage of this.  Note that this will only work if the tops of the plants are freshly grown; old tops will remain unaffected by this change.
-Added sheep running away when the player attempts to apply Dung to them.  They don't like that.
-Changed the name of the "Rollers" to "Slats", and changed the textures representing them to reflect this.
-Changed how the Block Dispenser places redstone repeaters so that they are always facing away from the Block Dispenser.  This is useful in employing the BD as a base-3 memory unit.
-Changed (reduced) the volume of the sound that clay and Unfired Pottery make when being rotated on the Turntable. This is to make the sound less overwhelming in large-scale automated setups.
-Changed the Mill Stone Gui to display its contents horizontally instead of vertically.  The vertical display was due to an old feature idea that got scrapped long ago, with the horizontal making far more sense for the way it operates.
-Fixed problem with the Block Dispenser not being able to place Blood Wood Saplings on Planters that contain soul sand.
-Fixed problem with water-flow not being able to transport items over Planters (those that don't contain soul sand...such planters will still stop item flow, just like with regular soul sand).
-Fixed problem with Water Wheels and Wind Mills catching fire due to being hit with flaming arrows, and displaying a huge flame sprite as a result.
-Removed the ability to use Foul Food as fertilizer.  Too much potential for abuse.
-Removed the ability to push Axles with pistons to prevent exploits involving the creation of infinite mechanical energy loops.

Version 3.51

Note: This release is NOT compatible with the 2.X versions of Better Then BuildCraft.  If you are using that mod, please upgrade to the 3.x branch of BTB.  A new release of BTB will be coming out shortly after this release of BTW to handle this incompatibility issue.

-Added magical visual effect to the Soul Urn.  Your lives are now complete.
-Added the ability for the output of one Lens to feed directly into the input of another.
-Added the internal FCIBlockClimbable interface for the upcoming mod API to provide add-on mods the ability to designate individual blocks as climbable by the player.
-Added internal functionality for getting and setting mod block facing based on a meta-data value to better interface with the BuildCraft Builder in Better Then BuildCraft.
-Added an internal hook to allow for the adding of multiple variations of the same item type to the creative-mode inventory to support Better Then BuildCraft.
-Fixed problem with Lens not lighting up the area around non-solid blocks when the beam first intersects with them.
-Fixed problem with the end point of a Lens beam being able to activate another Lens, even if the beam wasn't facing directly into the Lens input.
-Fixed problem with the Lens projecting onto a surface if there was an entity right next to that surface.
-Fixed the Hopper recipe to not work with stone Corners.
-Fixed problem with a Lens not registering that a beam feeding into its input was turned off if that beam was interrupted by a block.

Version 3.50

Note: This release is NOT compatible with the 2.X versions of Better Then BuildCraft.  If you are using that mod, please upgrade to the 3.x branch of BTB.  A new release of BTB will be coming out shortly after this release of BTW to handle this incompatibility issue.

-Added the Lens as a new block type (finally).  I'm not shitting you. I'm not trolling.  This is for really real time.
-Added a new variety of the Planter that may be created by placing soul sand in an empty Planter, instead of dirt (no bone meal is required).  This allows for the growing of netherwart and Bloodwood trees, but will not allow for maturation of these plants outside of the Nether.  Bloodwood saplings can plant themselves on these blocks just like with regular soul-sand.
-Added the ability to power mechanical devices with a Hand Crank sitting on top of them.
-Added internal hooks for the swallowing of BC pipes by the Block Dispenser for use in Better Then BuildCraft.
-Changed the way Wheat grows so that its growth rate will be at maximum if growing in a Planter, regardless of the status of neighboring blocks.
-Changed the Rollers recipe to use 4 Moulding instead of 9, to fit the recent changes to Wicker & Grates.
-Changed the size of the collision volume on a Hopper without a filter, to match that of one with a filter.  This resolves a number of issues with items falling through the cracks between blocks in certain setups, and makes Hopper behavior more consistent overall.  It should also now be possible to flow items over a Hopper with a filter in the same way as one without.
-Changed the way Urns render so that they appear directly beneath a Hopper if they are placed under one.  This makes the whole botteling of souls process look better and makes it a tad more intuitive.
-Changed the Planter with soil recipe to include bone meal in between the dirt and the Planter.
-Changed the Crucible so that overheating combustible ingredients within it will have the same unfortunate consequences as with the Cauldron.
-Changed the way the Detector Block handles the detection of wheat growth internally.  This is so that beams from the Lens aren't blocked by the block above fully gown wheat.  There should be no noticeable change to how this works with the 
DB, but I mention it just in case problems crop up.  Please let me know if they do.
-Changed the communication layer with Better Then BuildCraft to make future version of the two mods less dependent on each other.
-Fixed problem with Plate Armor not returning enough Soulforged Steel when melted down in the Crucible.
-Removed ability to convert Urns to Soul Urns within the Hopper inventory.  Now, the Urn MUST be placed beneath the Hopper in order to do this.  This is to avoid confusion with what is essentially duplicate functionality that was causing people to not even realize the process could be automated.  It also serves to encourage automation of the simplest portion of the overall process of creating Soul Urns which will hopefully lead to players deciding to undertake other aspects of it as well.

Version 3.492

-Added the ability to enchant Composite Bows.  Note that the infinity enchantment will only provide you with an infinite supply of *regular* arrows, not Broadheads.  It makes for a nice back-up though if you run out of Broadheads. Also, the requirement for an infinity bow to have a single arrow in your inventory to fire appears to be a bug in the MC code, rather than an intentional design-decision, so this requirement doesn't apply to the Composite Bow.  In other words, if you run out of Broadhead Arrows with an infity bow, it will always continue to fire regular arrows as a back-up regardless of whether you have regular arrows in your inventory or not.
-Added "magical arrow" render for arrows fired from infinite bows to help distinguish them visually, and make it less confusing as to why the arrows can't be picked up again after firing.
-Added ability for Broadhead arrows to receive the enchantment of the firing bow (again, with the exception of infinity).
-Added ability to pick-up arrow entities (arrows fired from bows) in the Hopper.  This applies to arrows regardless of their source (skeletons, dispensers...whatever), but not to the magic arrows described above that are fired from infinity bows.
-Added ability for Saws to harvest vines, just like shears.
-Added ability to cut fences into wood Corners with the Saw since you now tend to accumulate an excess of them while exploring mine-shafts.
-Added internal functionality for placing items with the Block Dispenser, both to act as an interface in the upcoming API, and to allow for placing BuildCraft Pipes in Better Then BuildCraft.
-Changed zombie pig-men and magma cube spawning so that they may only spawn on netherrack or netherbrick.  This allows the player to create bases in the nether that won't become occasionally infested with pig-men.  There's a config file setting to disable these changes if you desire.
-Changed the way the Hopper processes collisions with items internally, which should result in a slight increase to performance.  This should have no apparent effect, but let me know if any problems arise.
-Changed the Grate recipe to use 4 sticks instead of 9.
-Changed Gear Boxes so that they may be rotated on the Turntable withou breaking any attached axles (to match functionality of rotating by hand).
-Fixed problem with being able to apply a Breeding Harness to an animal that's already wearing one.
-Fixed problem with sheep regrowing wool while wearing a breeding harness.
-Fixed problem with colored wool not being converted into Glue in the Cauldron.
-Fixed problem with Blood Leaves dropping apples.
-Fixed problem with mechanical power distribution if you manually rotate a Gear Box that is neigboring on an Axle that has a Wind Mill or Water Wheel on it.
-Fixed vanilla bug with requiring the player's inventory to contain arrows when the bow has an infinity enchantment, to match the functionality of the composite bow.  See above for details.

Version 3.491

-Updated the mod to version 1.1.0 of Minecraft
-Changed Hardcore Bucket mode so that lava may no longer be collected in a bucket to avoid exploits involving using it as a fuel.  Attempting to do so will result in the player taking damage.
-Changed the Block Dispenser to be able to properly place and retract Blood Leaves.
-Changed shears to be effective vs Blood Leaves.

Version 3.49

-NOTE: This release is for Minecraft 1.0, NOT 1.10.  Don't bother asking.
-Added method of synthesizing redstone dust through metling down Concentrated Hellfire & golden nuggets in a Crucible.  Gold Bars may also be used if sufficient Concentrated Hellfire is present (requires 9 to 1).
-Added ability to rotate Axles and Gear Boxes by activating (right clicking) them with an empty hand.
-Added high-effeciency fence gate recipe using Moulding and a Siding.
-Added ability to render down saddles in the Stewing Pot for 3 Glue.
-Added ability for villagers to toss the milk.
-Changed the name of the Cauldron to the "Stewing Pot" to avoid confusion with the vanilla Cauldron.
-Changed picks to be effective against the Detector Rail Variants.
-Changed the Crucible recipes so that the creation of Steel always takes place before all other activities.
-Changed the Hopper so that Pipes don't suck the Filters out in Better Then BuildCraft.
-Changed the code for animal-breeding partner-selection to further reduce the likelihood that animals will ignore closer breeding partners for ones that are farther away.
-Fixed problem with the Kiln not resetting its cook state when its contents are switched.
-Fixed problem with Cement causing a crash if it spreads below the limits of the world (only applies to user-created maps without a bedrock layer at the bottom).

Version 3.48

-This is an emergency release to handle incompatibility problems between BTW 3.47 and BTB 1.01.  It will be immediately followed by a release of BTB (V1.02) for the same reason.
-Added internal functionality to facilitate communication between BTW and BTB and remove install-order depedency between the two mods.

Version 3.47

-Added functionality so that if you activate (right-click) Siding, Mouldings, or Corners with an empty hand, it will toggle the orientation of those blocks, allowing you to easily reallign them should the initial placement not be to your satisfaction.
-Added notifications so that the Buddy Block will react when a neighboring chest opens or closes.
-Added the ability to rotate chests on the Turntable.
-Added ability to transform Blood Wood into charcoal in both the furnace and Kiln.
-Added shapeless conversion recipes for stone Corners to Moulding, and Moulding to Siding.
-Added a mod installation integrity test to BlockFire so that the mod won't work at all if it isn't installed properly instead of just crashing at some unspecified point.
-Added internal functionality to toggle the facing of various mod-blocks to act as an interface with the BC wrench in BTB.  This is strictly an internal code change, but affects the following blocks: Anchor, Anvil, Axle, Bellows, Block Dispenser, Buddy Block, Companion Cube, Corner, Detector Block, Gear Box, Mining Charge, Moulding, Saw and Siding.
-Added click sound when switching timing settings on the Turntable to provide a little more feedback.
-Changed the Tallow texture to look like a bar, as I don't know what the hell it was supposed to look like before :)
-Changed wolves to drop cooked wolf-chops on death instead of raw if they're on fire.
-Changed (reduced) the number of planks that are produced when a Gearbox breaks, so that you can't profit from it when building them out of Siding.
-Changed (refactored) the mechanical power code internally to be more modular both to make BTB simpler, and for the upcoming BTW API.
-Changed (refactored) the refined tools code to consolidate the functionality that makes regular tools effective against particular blocks with that for the refined tools.  This is to aid in making tools effective against particular BTB blocks.
-Fixed problem with Buddy not powering down if it is pushed by a piston while in its on state.  This change will also cause Buddy to emit a redstone pulse when first placed, which makes sense given the way it operates (maybe also useful when used in combination with BD?).
-Fixed problem with the Saw breaking when various aesthetic blocks were placed in front of it.  This affects the Block of Wicker, Table, Wicker Slab, Grate pane, and Wicker pane.
-Fixed problem with saplings sending out neighbor notifications and setting off Buddy in the middle of their growth cycle.
-Fixed problem with Unfired Pottery sometimes not reverting to item form when pushed over an empty space by a piston.

Version 3.46

-Added the Refined Shovel and Long Sword back into the mod.  The Long Sword is now simply called the "Refined Sword".  Along with the following changes, this is intended to provide flexibility for people that wish to apply individual specialized enchantments to each of their tools, while retaining the ability to have general purpose tools for sane people like me that prefer that option :)
-Changed the Refined Pick to not work as a shovel, changed its icon back to what it previously was, and changed its recipe to use 3 iron instead of 4.
-Added the Mattock as a new item.  It replaces the dual pick/shovel functionality that the Refined Pick previously had.
-Added the Refined Axe as a new item.
-Changed the Buddy Block recipe to reflect the new 4X4 Anvil crafting.
-Changed the recipes for the Detector Block and Block Dispenser to both better fit the 4X4 crafting grid, and to represent the more complex internal circuitry you'd expect these devices to require.
-Changed the recipes for all the Plate Armor pieces to both look better in the 4X4 crafting grid, and to consume more Soulforged Steel overall.

Version 3.45

-Added the ability for the Block Dispenser to pick up the following block types without altering them: dirt with grass, book shelves, coal ore, lapis ore, diamond ore, redstone ore, giant mushroom blocks and Mycelium.  This should allow it to function similarly to tools with the silk touch enchantment.
-Added the ability for the Refined Pick to function as both a pick and a shovel.
-Added ability to melt down the Cauldron in the Crucible.
-Added high-effeciency piston recipe involving wood Siding instead of planks.
-Changed the Anvil crafting grid to be 4X4 instead of 3X3, and changed all the recipes associated with the Anvil to require the larger crafting grid.  This was done to resolve player confusion over which recipes require the Anvil as it will now be readily apparent from the recipes themselves, plus this method fits the overall vanilla design and tech-progression much better, and allows for much more costly recipes at higher tech-levels.
-Changed the following recipes to match the new 4X4 crafting grid of the Anvil: Refined Pick, Refined Hoe, Battle Axe, Armor Plate, Plate Helm, Chest Plate, Plate Leggings, Plate Boots, Broadhead Arrowhead, Stone Siding, Stone Moulding, Stone Corner, Obsidian Pressure Plate, Redstone Eye, Detector Block, Block Dispenser, Column, Pedestal, and Block of Soulforged Steel.  Almost all these items are now more expensive to produce to help balance their power.
-Changed wolf behavior so that they'll only lean their head at you if you are holding food and they are either hungry or wounded.  This provides a visual feedback mechanism as to when they need to be fed to supplement their whining. (Thanks to RaustBlackDragon for suggesting this!)
-Changed the Buddy Block internally for a slight increase in performance.
-Changed the Battle Axe to enchant as a weapon instead of a tool.  Who really bothers to enchant axes to begin with?
-Changed the Battle Axe so that it can cut through spider webs.
-Changed the way enchantment levels are (randomly) selected on the enchantment table.  First a maximum enchantment level is selected based on the number of bookshelves, capped by the player's current level (so that enchantments aren't displayed beyond the level currently possible for the player).  The top slot will always display a random value up to the maximum level possible, the second slot will display half the maximum level (rounded down), and third slot will always display the maximum enchantment level possible.  Additional fine-tuning can be achieved by placing or removing bookshelves (sticky pistons and/or Block Dispensers can be useful for this).  This should save the player a TON of clicking when attempting to enchant items to a particular level.
-Changed the Block of Soulforged Steel so that it can be melted down in the Crucible, but can't otherwise be broken up into individual bars through regular crafting.
-Fixed problem with the mechanical system that allowed infinite power loops to be created.
-Fixed the Hopper being able to place items on the potion brewing stand, as it was not intended to be able to do this.
-Fixed problem with being able to pick up Light Blocks in their lit state using silk touch.
-Fixed problem with shovels not being effective vs Unfired Pottery.
-Removed crafting recipes for the Refined Shovel and Long Sword, as their functionality is entirely integrated into the Refined Pick, and Battle Axe.  Your old items will still function, and can still be melted down, but these tools are no longer officially part of the mod.

Version 3.41

-Added a placeable version of the Wicker item, which functions like a glass pane.
-Added functionality for Blood Leaves to not render as translucent when the fast graphics option is enabled.  This unfortunately required the Blood Leaves to use their own block ID.  This change will only apply to leaves generated after this update is applied.
-Added leaf-decay to Blood Leaves.  This change will only apply to leaves generated after this update is applied.
-Added ability to fire throwable potions out of the Block Dispenser, just as with the regular dispenser.
-Added the ability for the Block Dispenser to "process" sheep.
-Changed the way mod blocks are added to creative mode internally to make it easier for me to add in new blocks with time and to provide a unified system for doing this once the mod API is released.
-Changed Wind Mills and Water Wheels so that their top can extend beyond the block height-limit (normally 128), without causing any problems.
-Changed vanilla animal breeding behavior so that animals will always select the *closest* animal already in love-mode to attempt to breed with.  This should prevent animals getting "stuck" trying to breed with an inaccessible animal when there is a more suitable partner nearby.
-Changed the Rollers Hopper filter to allow leather to pass through it.
-Changed Blood Wood Saplings to anger the residents of the Nether when you plant them.
-Changed Blood Wood Sapling growth so that they will not grow if they are up against the height-limit of the world.
-Changed Wind Mills and Water Wheels to be destroyed with a single hit from the player in creative mode.
-Changed Hopper Filters to properly filter all the vanilla items added in version 1.0.
-Fixed bug with nether wart being able to grow on Planters, when it's not supposed to be able to.
-Fixed a number of instances where an item would lose its enchantments when entering or exiting a mod-block's inventory (like with Hoppers).
-Fixed problem with Detector Blocks, Hoppers, and Buddy Blocks, sometimes failing to properly notify their neighbors of redstone state-changes.
-Fixed problem with the Saw breaking when double wood-slabs were placed in front of it.
-Fixed vanilla bug in creative mode that was causing weird results when attempting to break blocks near entities, as it was causing a lot of problem with Wind Mills and Water Wheels.

Version 3.40

-Added the Blood Wood Sapling as a new block type.
-Added Blood Wood as a new block type.
-Added Blood Leaves as a new block type.
-Added Soul Dust as a new item type.
-Added ability to burn Saw Dust as a furnace fuel.
-Added ability to cut wood slabs into Moulding using the Saw.
-Changed the Vine Trap block to be named "Aesthetic Vegetation" both internally and in the config file, since it is now sharing a block ID with Blood Leaves and Blood Wood Saplings.  NOTE: If you changed the value of the block ID on Vine Trap blocks in the previous release, make sure to update the names in your config file before loading an old world!
-Fixed problem where items ejected from destroyed mod blocks with inventories, would lose their enchantments.

Version 3.30

-Added the Vine Trap as a new block type.  Crafted with 3 vines in a row, mobs will think it's a solid block only to fall right through when they walk on it.
-Added the Breeding Harness as a new item.
-Added all the mod blocks to creative mode.  If you have any other mods installed, it should also display blocks from them as well.
-Added sounds and particles to the birthing of baby animals.
-Changed baby animals so that they can jump only half as high as adults.  This allows for separation of adults from babies in automated breeding facilities.
-Changed baby animals so that they won't eat loose wheat that's laying about.
-Changed wolves so that they will ONLY produce Dung when they have been fed.
-Changed wolves so that they will whine when they are hungry, not just when they are wounded.
-Changed (increased) the amount of XP dropped from villagers.
-Changed enchanting so that you can re-enchant an item that is already enchanted, losing the original enchantment in the process.
-Fixed problem with minecarts not running properly over the detector rail variants provided by the mod.
-Fixed problem with the Refined Pick Axe and Refined Axe not being effective against certain mod blocks.
-Fixed problem with Saws ignorning armor when damaging a player.
-Fixed problem with rope sometimes disappearing at certain viewing angles on top of a moving Anchor.
-Fixed flint and steel not producing fire in front of a Detector Block.
-Fixed nether portals not being able to form in front of a Detector Block.
-Fixed problems with occasionally being able to walk through the collision area of Wind Mills.
-Fixed problem with Platforms sometimes descending through other Platforms and destroying them.
-Fixed the straps of the Leather Vest not displaying over the shoulders of the player.

Version 3.27

-Added XP for slaying villagers.  In the battle against the Enderdragon, the souls of the innocent/barely-sentient are the most valuable of all!
-Added ability to feed animals by just throwing wheat on the ground near to them in order to help with automating breeding.
-Changed animals so that they will change the target of their affections if the desired animal has already bred with another.  This avoids confusion in group situations.
-Changed Wolves so that they won't move to attack a mob that has hit the player, if they are sitting.
-Changed wolves so that they will only eat loose food if they are hungry or wounded.
-Changed Cauldron recipe to have bone on top of the water bucket, as it is more intuitive that way.
-Changed the time it takes to update the Bellows, slowing it down by 1 tick (1/20th of a second), to avoid confusion due to some very fast timers only sometimes working with them.
-Changed axes to be effective against melons.
-Changed potions to increase their maximum stack size to 8.
-Fixed the growth rate of Hemp which was reduced to a quarter of what it should have been by a change to the way chunks update that Mojang made in 1.0.
-Fixed rate of flowers growing on Planters for the same reasons as above.
-Fixed size of collision area around Grates so that they are more like glass panes and iron bars.
-Fixed crash bug when attempting to plant seeds with the Block Dispenser.

Version 3.26

-Fixed problem with brewing stands crashing the game when opened.  ***WARNING***: This fix will delete the contents of Cauldrons already in your world.  Make sure to empty out your Cauldrons BEFORE installing this version, or you will lose anything they contain.  This was unfortunately necessary due to Mojang naming the tile entities for the Brewing Stand, as "Cauldron", creating a nasty conflict between the two block types that could only be resolved through resetting the tile entities on the Cauldrons, wiping their contents clean in the process.
-Fixed problem with Ropes not being climable.

Version 3.25

-Updated to version 1.0 of Minecraft.
-Removed support for the Forge.
-Added massive amounts of incompatibility with just about every mod out there!  This feature was added due to popular demand and so that players will no longer have to spend time worrying about what other mods to install!
-Added ability to enchant refined tools and armor.  Due to the inherently magical nature of Soulforged Steel, they have the same increased capacity to receive enchantments that gold does.
-Added a damage value to the Composite Bow, similar to that of the regular bow.  It has a durability of 1.5 times that of the vanilla bow.
-Changed the Buddy Block so that it doesn't react to changes in the invisible detection block in front of a Block Detector.
-Changed (reduced) damage on the Longsword so that it is the same as the Battle Axe.  However, the Battle Axe enchants as a tool, while the Longsword enchants as a weapon, making it a potentially much more effective dedicated instrument of mob dismemberment.
-Changed the Detector Block and Buddy to be solid blocks within the code and modified the redstone code to accept solid blocks as valid sources of power.  This allows stuff like torches to stick to the side of them despite the loss of the Forge functionality mentioned below, and also corrects a visual glitch where redstone wire running over the top of them wouldn't correctly appear to connect down the sides of the block.
-Changed (reduced) the amount of Tallow produced by beef, chicken, eggs, and wolf chops so that pork is by far the greatest source of fat in the game.  Each of those other foods will now require multiple units to produce a single unit of Tallow (with chicken and wolf producing the least fat of all).  This is to provide a specific purpose to farming pigs since they were no longer a very useful animal to keep around.
-Changed the Hibachi to no longer incinerate pistons, or piston arms, that are above it.
-Fixed problem with aesthetic blocks (like columns) not rendering properly when next to a Grate block.
-Removed the "axe tweaks" from the mod since vanilla now handles the axe versus various appropriate blocks on its own.
-Removed the refined pick-axe's particular effectiveness versus several vanilla blocs (like redstone ore), since vanilla now makes all picks effective against them.
-Removed the refined shovel's particular effectiveness versus soul sand, as this is now vanilla functionality.
-Removed ability to "stick" objects like torches and redstone wire to Siding and Tables.  Sorry guys, but this was a necessary side-effect of moving away from the Forge, as continuing to support this functionality would have required an inordinate number of changes to a large number of base-class files.
-Removed recipes to tan leather using wood logs, as these were a temporary measure to help correct the lack of wolves spawning in 1.8 (this has since been fixed in 1.0).
-Removed mod recipe for crafting pumpkins into pumpkin seeds, since that is now provided in vanilla Minecraft.


Version 3.22

-Added ability to grow mossy cobble.  Monster Spawners will now slowly (and I do mean slowly) cause any cobblestone within their vicinity to transform into mossy cobble with time.  This feature is specially dedicated to Battosay who has been waiting on it very patiently :)
-Added a block version of the Grate so that it can be placed just like glass panes or iron bars.
-Added the stone Moulding as a new block.  It's made on the Anvil with stone Siding.
-Added the stone Corner as a new block.  It's made on the Anvil with stone Moulding.
-Added seperate texture for the top and bottom of the Pedestal.  This won't be visible with the default mod textures, but was added to aid in texture pack creation.  My apologies, but it required a slight rearangment of the texture file to maintain the overall format.
-Fixed Mining Charge recipe involving slime-balls to produce the appropriate 2 Mining Charges instead of 1.
-Fixed Kiln outputting the block version of the Urn instead of the item version.

Version 3.21

-Added an abstract block type called "Aesthetique Opaque".  This allows for each of the following new blocks to be contained in a single block ID (as well as allowing for future additions):
-----------
-Added a Wicker block (made of 4 pieces of Wicker). There is also a recipe to convert Wicker Blocks back into Wicker.
-Added a Dung block (made with 9 pieces of Dung), along with return conversion recipe.
-Added a Steel block (made with 9 pieces of Steel), along with return conversion recipe.  Both recipes can only be performed on the Anvil.
-Added a Concentrated Hellfire block (made with 9 pieces of Concentrated Hellfire), along with return conversion recipe.
-Added a Padding block (made with 9 pieces of Padding), along with return conversion recipe.
-Added a Soap block (made with 9 pieces of Soap), along with return conversion recipe.
-Added a Rope block (made with 9 pieces of Rope), along with return conversion recipe.
-----------
-Added an abstract block type called "Aesthetique Non Opaque".  This allows for each of the following new blocks to be contained in a single block ID (as well as allowing for future additions):
-----------
-Added a block version of the Urn.  This allows the Urn to be placed *beneath* a powered Hopper in order to collect the souls coming out of it to aid in the automatic production of Soul Urns (the old method of putting the Urns directly in the Hopper also works). 
-Added the Column as a new block type, made using three smooth stone in a vertical line, on the Anvil.
-Added the Pedestal as a new block type (it can face upwards or downwards), made with three smooth stone in a horizontal line with another just above in the middle slot, on the Anvil.
-Added the Table as a new block type (3 Siding above 2 Moulding).  Table legs will reposition themselves to conform to neighboring Tables.
-Added a Wicker slab (made from 3 pieces of Wicker as per the standard slab recipe, or by cutting a Wicker block in half with a Saw).  There is also a recipe to convert Wicker Slabs back into Wicker.
-----------
-Added high effeciency chest recipe using wood Siding.
-Added a recipe to convert Wicker back into sugar cane.
-Added ability to melt iron bars in the Crucible at an 8 to 3 conversion ratio.
-Changed Unfired Pottery to require a solid surface beneath it or it will revert into item form.  This is to aid in automatic production, as you can now easily push it off the Turntable with a piston to convert it to an item.
=Changed the Saw to produce 4 planks and 2 units of Saw Dust whenever it cuts a log.
-Changed the Mining Charge so that it may be indirectly powered by redstone.
-Changed the Mining Charge recipe so that it outputs 2 Mining Charges instead of 1.
-Changed the Dynamite recipe to use three pieces of paper instead of one (all along the left side).
-Changed the pitch and volume of the click the Block Dispenser makes when it can't dispense a block or item so that it's less annoying.
-Changed Wicker recipe to only require 4 sugar cane instead of 9.
-Changed Nethercoal recipe to only require 1 unit of Hellfire Dust, and 1 of Carbon Powder.
-Fixed mechanical devices sounding weird due to Mojang's new explosion sounds.

Version 3.20

-Added the Mining Charge as a new block type.
-Added Dynamite as a new item.
-Changed the way the Block Dispenser updates so that it will more reliably respond to rapid changes in redstone state.  This should improve its usability as a ROM, and make it easier to work with in combination with Buddy.
-Changed the Buddy Block to introduce a minimal delay (1 tick or 1/20th of a second) before powering up when it detects a change to fix problems with certain blocks (like ladders) being placed next to its output side.
-Changed Hand Crank so that it can be placed on top of the Buddy Block, and so that it only sends out update notifications when it powers on and off.
-Changed the Detector Block so that you can stick stuff to the sides and top of it (torches, minecart rails, redstone wire, etc.)
-Changed Saw Dust, Potash, Soap, Redstone Eye, Filament, & Hardboiled Eggs to be properly filtered by Hoppers.
-Changed Siding so that you can stick stuff to the solid side of it.
-Fixed problems where Urns that were in mid-flight when a game was saved, and reloaded, would dissapear.

Version 3.10

-Added the Buddy Block which acts as a BUD (block update detector) with a uni-directional redstone output (facing determined on placement).  The recipe consists of Redstone Eyes (1 on each side), smooth-stone (in each corner), and redstone dust (in the center).
-Added high-effeciency ladder recipe using Moulding, and a book shelf recipe using Siding.
-Added ability to convert Sticky Pistons back into regular pistons by heating them in a Cauldron with Soap (at a 4 to 1 piston/soap ratio).
-Changed Composite Bow to have a draw-time similar to how the vanilla bow functions as of 1.8.
-Changed the Turntable to notify neighboring blocks when it rotates, or when blocks on top of it rotate.  This is to allow the Buddy Block to be used in counting Turntable rotations (particularly useful in automating the spinning of Pottery).
-Changed the way saplings grow into trees so that wood and leaf blocks properly notify their neighbours when they come into existence.  This is so that they work properly with the Buddy Block, and Saws.
-Fixed a problem with player taking damage while riding a minecart on a descending Platform.

Version 3.0

-Added features that bring the mod into the New Age!  The moment you've all been waiting for is finally here, but I won't rob you of the pleasure of discovering it for yourselves :)
-Changed the amount of damage Wind Mills and Water Wheels can sustain so that they are much more resistant to attack.
-Fixed problem with Hardcore Buckets mode being enabled by default unless the config file for the mod was installed.
-Fixed the Plate Helm returning only 5 Steel when melted in the Crucible instead of the proper 6.
-Fixed problem with the Block Dispenser not being able to eject items when powered the way it's supposed to.
-Fixed power transfer problems when Wind Mills and Water Wheels were destroyed in cases where they are directing mechanical power in two directions simultaneously.  This was causing some axles to break at odd times when the attached power-source was destroyed.
-Fixed problem with vines not being able to grow in front of Detector Blocks.

Version 2.99

-Added Wool Slabs, both as an aesthetic block and as a method of providing color-coded off-bits when using the Block Dispenser as a ROM.  They are fully functional with regards to the various dying methods in vanilla Minecraft and the mod, and may be created using the same standard "3-blocks in a line" recipe used for other slabs in the game.  They can also be created by placing a wool block in front of the Saw.
-Added optional "Harcore Bucket" mode (off by default...can be turned on in the config file).  This basically prevents the player from being able to transport water & lava source blocks and is a mode intended to make fluid flow (and by extension, the generation of mechanical power) far more interesting without causing additional performance overhead, by requiring the player to actually build canals and such to have access to liquids.  Give it a try and let me know what you think.
-Added Hard Boiled Eggs as an item.
-Added ability to render eggs into Tallow at a 4 to 1 conversion ratio.
-Added Potash as an item.
-Added Soap as an item.
-Added Saw Dust as an item.
-Added the ability to smelt ore and produce charcoal in the Kiln.
-Changed the number of wood planks produced when using the Saw on a log to 5 instead of 6.
-Changed the Hopper "filler" item to be brick instead of clay balls.  This is to aid in automating production of Pottery.
-Changed Unfired Pottery to no longer use a tile entity.  This means that it can now be pushed by pistons.
-Changed the Kiln to be an actual block.  This change is invisible to the player but allows the Kiln to be far more flexible in its functionality.  Unfortunately, this has also required changing the time it takes Pottery to cook and may mess with existing auto-Kilns as a result.
-Changed high-efficiency Saw recipe for the sign to use 1 Moulding and 1 Siding.
-Changed amount of Rotten Flesh required to render into glue from 2 units to 4.
-Changed trap door filter on the Hopper to allow narrow objects (bones, arrows, sticks, etc.) to pass through (instead of items that stack up to 64) as the old functionality was no longer really useful with the changes made to stack sizes in 1.8.
-Changed the Hopper filters to properly process new items added in 1.8 (pumpkin/melon seeds, ender pearls, etc.).
-Changed the way the Hopper processes items slightly (a larger refactor is coming for the API), so as per usual with such changes, let me know if you spot any oddities with the Hopper filters over the next little while.
-Changed the Wicker and Rollers Hopper filters to not allow Ink Sacks to pass through (they previously could because the Minecraft code considers them to be "dye powders").
-Changed the Block Dispenser to be able to pick-up vine blocks and tall grass.
-Changed the Block Dispenser to place clay blocks if it contains 4 or more clay balls to aid in the automated creation of Pottery.
-Changed the Block Dispenser to have 16 inventory slots instead of 9 to facilitate its usage as a ROM.  This also makes some sense considering the BD doesn't really have any kind of internal mechanism taking up space, unlike the regular dispenser.
-Changed the Axle recipe to be horizontal instead of vertical, as it's far more intuitive.
-Fixed problem with the Saw cutting saplings when it's not supposed to.  Also applied this to Melon & Pumpkin stems.
-Fixed problem that would sometimes cause Stoked Fire to periodically go back to being regular fire even though it was being continually blown upon by the Bellows.  Stoked fire should be much more consistent as a result.

Version 2.98

-Fixed problem with non-Steel tools not being able to harvest various mod-blocks and redstone.  This major bug is the main reason for this small release.
-Fixed problem with Hemp Fibre-based Filament recipe producing 2 Filaments instead of 1.

Version 2.97

-Added ability to throw Urns, and fire them out of dispensers & Block Dispensers.
-Added ability to convert cobblestone to smoothstone in the Crucible.
-Added ability to turn sand into glass in the Crucible.
-Added ability for the Block Dispenser  to pick up and place whole melons.
-Added ability to render rotten flesh into Glue (requires 2 units of flesh).
-Added ability to render chicken and steak into Tallow.
-Added ability to block with ALL the refined tools (Long Sword, Battle Axe. Refined Pick, Refined Shovel) EXCEPT the Refined Hoe (since right-clicking is required for tilling).  This should make blocking more interesting as it gives you an option should you be surprised by a monster with a tool other than a weapon in your hand.
-Added ability to fire Broadhead Arrows out of vanilla dispensers.
-Changed the Kiln so that it can be constructed out of 4 brick blocks instead of 5.  This means you can now have two sides open on a Kiln to aid in automation.  As always, the block at the bottom of the Kiln MUST be brick.
-Changed Cement recipe to be produced in a heated Cauldron, and to consist of 1 block of sand, 1 of gravel, a bucket, and a Soul Urn.
-Changed name of 'Steel' to 'Soulforged Steel'...for real this time :)
-Changed Steel recipe in the Crucible to produce 1 piece of Steel for each piece of iron, Carbon Powder, and Soul Urn.  This makes Steel a lot harder to initially produce, but given that you can remelt it indefinitely, is a fair balance IMO and makes it much more satisfying to create your first full set of Steel equipment and encourages automation of the process.
-Changed priority of filament recipe in Cauldron so that Filament are always made first when possible, before converting string into wool.
-Changed the Saw to be able to handle a variety of materials that should prevent it breaking in odd circumstances.  This allows it to handle stuff like sawing pumpkins and melons, amongst other things.
-Changed foul food to work on pumkin stems, melon stems, and mushrooms as fertilizer.
-Changed the way the Block Dispenser creates particles when destroying a block, which will hopefully resolve a problem with them hanging around when the BD is used in massive numbers.  Let me know if the problem persists.
-Changed the 3D model for the unfired Urn to give it a top.
-Changed recipe for the filament to produce 1 unit instead of 2.  Sorry guys, but it was severely devaluing glowstone dust.
-Changed recipe for the filled Planter to no longer include a water bucket so that they can be mass-crafted.
-Changed companion cube being ground in Mill Stone to eject string and red dye only after it has been completely ground down.  No more soul-damning string grinding :)
-Changed the name of Polished Lapis to the "Redstone Eye", moved its recipe to the Anvil, and changed the recipe to require 5 pieces of lapis (top and middle rows), one piece of gold (middle square), and one piece of redstone dust (bottom row) to produce 2 eyes.
-Moved the Detector Block recipe to the Anvil.
-Changed the Block Dispenser recipe so that it could only be made on the Anvil.
-Changed the Axe Tweaks to use the Forge tool system and removed the option to disable them from the config file since they should no longer cause incompatibility problems as a result of this change.  This should also allow axes from other Forge mods to take advantage of the axe tweaks as well, and be effective on BTW blocks.
-Changed the refined Pick, Shovel, and Battle Axe to all use the Forge tool system.  This should extend their usefullness to blocks from other Forge mods (*if* they use the system as well).
-Changed picks to be effective against Siding (both stone and wood since they share the same blockID).
-Changed Refined Pick to be effective on all mod-blocks that normally require a long time to remove (such as the Block Dispenser), and to be effective on some vanilla blocks that function similarly as well (such as the furnace, regular dispenser and stone stairs).  Let me know if I missed any.
-Changed axes to be effective against melons and fence gates.
-Changed the refined shovel to be effective on Soul Sand.
-Fixed the hit-box around the 3D model of the unfired Urn to match its shape.
-Fixed problem that caused tanning leather to require 16 normal wood instead of 32, as intended.  The process requires 16 dark wood, 32 normal, or 64 birch, given that darker barks generally contain more tannin.
-Fixed problem with the Hopper not handling a large influx of souls properly, and only creating 1 Soul Urn when it should have created more.
-Fixed problem with melon or pumpkin stems growing on planters being able to overwrite occupied neighbouring blocks with the melons they produce.
-Fixed the way Detector Blocks detect arrows to prevent various kinds of odd behavior.
-Fixed problem with not being able to pick up arrows and Broadhead Arrows fired out of a Block Dispenser.

Version 2.96

-Added the Urn as an item (a new form of pottery).
-Added the Soul Urn as an item.
-Added Polished Lapis (created with 4 pieces of Lapis and sand within a heated Cauldron).
-Added recipe to convert pumpkins into pumpkin seeds, since it is coming in 1.9 anyways and will allow people to start working on their farms now.
-Added ability to grow pumpkins and melons on Planters.
-Added ability to melt down glass panes into glass blocks in the Crucible at an 8 to 3 ratio.
-Added *temporary* tanning recipes using wood (logs) instead of dung to simulate the creation of tannin out of bark.  The darker the wood, the less is required.  This is a temporary measure since wolf-spawning seems to be so infrequent to non-existant in 1.8, which I'll leave in place until that gets fixed/changed.  If it remains this way, I'll come up with a more permanent solution.
-Changed Detector Block Recipe to use Polished Lapis instead of regular lapis for the eyes.
-Changed Saw to output 6 wooden planks (instead of 4) when processing a wood block.  This makes the Saw a MUCH more effecient solution for cutting down trees than an axe.
-Changed Filament recipe to require either a Hemp Fiber or a String.
-Changed stone Panel (Siding) recipe (on the Anvil) to produce 2 Panels instead of 1.
-Changed Obsidian Pressure Plate to only be craftable on an Anvil.
-Changed Block Dispenser recipe to require a Soul Urn in the centre.
-Changed the name of "Coal Dust" to "Carbon Powder" to avoid confusion with similar items from other mods.
-Changed the name of "Panels" to "Siding" to avoid confusion with similar items from other mods.
-Changed the name of "Steel" to "Soulforged Steel" to avoid confusion with similar items from other mods...and because it contributes significantly to Steve's moral degradation to be making his equipment out of tortured souls.
-Changed Hand Crank to cause exhaustion when operated (equivalent to jumping 4 times).
-Changed Planter so that it won't sprout flowers next to a stem, to prevent interfering with melon and pumpkin farming.
-Fixed problem with Nethercoal and Coal Dust not working properly as furnace fuels.
-Fixed problem with Steel recipe only outputting 1 unit instead of 4.
-Fixed problem with damaged items not being able to be melted down in the Crucible.
-Fixed problem where ingrediants added one at a time to a Crucible or Cauldron would not always start the cooking process when the correct number were finally added.
-Fixed crash when shift-clicking to a full inventory with various mod-blocks.
-Fixed problem with dropping duplicate ghost-items when closing the Anvil crafting-grid.

Version 2.95

-Updated to version 1.81 of Minecraft.  Note that a few items in the mod still need to be adjusted to work with the new systems (like the Composite bow, and proper Hopper filtration of the new items), but everything should be functional.
-Added Padding as an item (Fabric + feather).
-Added Filament as an item (glowstone dust + redstone dust in Cauldron).
-Added recipes to convert Fabric and Rope back into Hemp Fibers for storage purposes.
-Changed the recipe for the Armor Plate to require padding (placed right below the Steel).
-Changed the recipe for the Light Block to use a Filament instead of glowstone dust, and glass panes instead of glass blocks.
-Changed the recipe for the Hibachi to use a Filament instead of glowstone dust.
-Changed Hemp to ONLY grow under Light Blocks if they are underground.  No more growing it under pumpkins :)
-Changed the Crucible over to use the same generic recipe system I introduced for the Cauldron in 2.93.  As before, please keep a close eye on the Crucible and what it is outputting, and please let me know of any problems, as this was a rather large refactor of the way the code for it works and errors could have easily been made.
-Changed the rail to iron conversion in the Crucible to 8 to 3 instead of 16 to 6.  Please forgive my lowest common denominator fail :)
-Fixed problem with the Battle Axe only returning 3 units of Steel when melted down in a Crucible, rather than 5.
-Fixed problem where Planters that didn't contain soil could sprout flowers.
-Removed recipe to convert two Hemp Fibers into string.  Sorry guys, I didn't like it as it blurred the lines between what was spider silk, and what was Hemp within the game, and opened up a whole can of worms design-wise with regards to what could be done with one and not the other.  Besides, there's now a peaceful source of string with webs.


Version 2.94

-Added ability for the Detector Block to see Broadhead Arrows.
-Added ability for Block Dispenser to fire Broadhead Arrows (will apply this to regular Dispenser in the future too).
-Added ability to render leather armor in the Cauldron.
-Fixed problem with flour-based cake recipe.
-Fixed problem with Saw not being able to be placed facing upwards or downwards.
-Fixed Block Dispensers ability to fire regular arrows.

Version 2.93

-Added the Anvil.
-Added the Armor Plate as a new item.
-Added Plate Helm, Plate Breastplate, Plate Leggings, and Plate boots as new items.
-Added the Composite Bow.
-Added Broadhead arrow heads, and Broadhead Arrows.
-Added Coal Dust as an item (which can be made from both coal and charcoal)
-Added ability to cook Coal Dust & Hellfire Dust in the Cauldron to create Nethercoal (and removed the old crafting recipe to create Nethercoal).  1 unit of Coal Dust & 4 units of Hellfire Dust are required to create 2 pieces of Nethercoal.
-Added alternate recipe for the Gear Box using wood Panels instead of wood blocks.
-Added ability to melt down rails in the Crucible at 16 to 6 rail to iron conversion ratio.
-Added an option to the config file to disable the mod's minecart tweeks.
-Added ability for Detector block to "see" fully grown wheat occupying the block to the front and below it.
-Added ability for the Crucible to pick up loose objects on top of it.
-Added ability for items to flow over the top of the Cauldron if they can not be swallowed by it (same thing applies to the Crucible).
-Added ability to dye wool in a heated Cauldron at a ratio of 8 wool to 1 dye.
-Added ability to grind flowers in the mill stone to produce dyes.
-Added ability to cook cactus in the Cauldron to produce green dye.
-Added ability to cook sand and gunpowder into TnT in the Cauldron (complete with hazards).
-Added ability to cook string into wool.  I'm not sure if this makes much sense, but neither does crafting spider silk into wool to begin with and I was sick of having to manually craft string into wool to save on storage space.  Insert magical explanation for what happens to giant-spider-silk when you cook it here :)
-Added ability to render string and wool into glue, but it takes rather massive quantities.
-Added ability for Planters to sprout flowers if left alone without anything planted in them for a long while.
-Added recipe to make torches out of Nethercoal.
-Added Forge version checking.  A descriptive error message will now be displayed if you are using an inappropriate version of the Forge with BTW.
-Changed name of the Refined Axe to the "Battle Axe" and increased the damage it does to mobs.  The recipe also requires 2 more steel than previously (for the double head).  It is now a combination tool/weapon (although not quite as effective as a Longsword as a weapon).
-Changed axes to be effective against cactus.
-Changed Detector Block recipe to use two pieces of lapis (NOT blocks) for the "eyes", instead of 1 block of lapis.
-Changed Cauldron to only produce foul food after the normal cooking time has elapsed (it's no longer instantaneous). This was part of the optimization process involved in the rewrite of the Cauldron code detailed below.
-Changed explosion size when overheating explosive elements in the Cauldron to be proportionate to the quantity involved.
-Changed Steel recipe in Crucible to require Coal Dust and Concentrated Hellfire instead of Nethercoal (this recipe will likely change once again in the future).
-Changed the Hopper filters to work properly on the newer items that I've added to the mod.
-Changed Hibachi recipe to require a piece of glowstone dust in the middle instead of smooth stone.
-Fixed the bouncing on items when they are resting on a filtered Hopper.
-Removed crafting recipe to convert Concentrated Hellfire into Hellfire dust.  This was just a debug recipe I accidentally left in the last version.
-Removed ability to grind stone into panels in the Mill Stone, and moved that functionality to the Anvil.  This will likely not be their final resting place in the tech-tree, but it's certainly better than them being in the Mill Stone.
-Removed delay for items being picked up on top of the Cauldron.
-Rewrote a lot of the Cauldron code to better structure it and make it easier to add new recipes.  I mention this so that players can keep an eye out for any problems that may arise with this functionality.  Please let me know if you spot any issues.
-Integrated Version 1.06 of the Forge, and eliminated a few base-class changes as a result.  Note that 1.06 or later is *required* for this release of the mod to function

Version 2.92

-Added Ground Netherrack, Hellfire Dust, and Concentrated Hellfire as items.
-Added soul sand as a filter to the Hopper.
-Added Wind Mill Sail recipe using wood blocks instead of Moulding.
-Added a shapeless recipe for twisting two Hemp Fibers into a string.
-Added ability to grind bone into bone meal in the Mill Stone.
-Changed Nethercoal recipe to require Concentrated Hellfire instead of Netherrack.
-Changed Hibachi recipe to use Concentrated Hellfire instead of Netherrack, and remove the flint (replaced by smooth stone).
-Changed Belt recipe to use 4 Straps instead of 8 (placed in a diamond pattern).
-Changed Hopper recipe to use two wood Panels and a Corner (for the bottom) instead of wood blocks.
-Changed The Saw to no longer be powered using a Hand Crank.  It must receive continuous power from an axle to function properly.
-Changed The Turntable to no longer be powered using a Hand Crank.  It must receive continuous power from an axle to function properly.
-Changed Bellows to only produce stoked fire over a lit Hibachi.  All other fires will be blown at by the Bellows now.
-Removed recipes for Wood Blade (used in Water Wheel construction) using wood blocks.  They can only be made with wood Panels now.
-Removed grinding wool into string in the Mill Stone (sorry guys, it screwed up the early game when working towards your first bow, and didn't make much sense anyways).
-Removed recipe for Bone Meal plus a white Vase producing a white Vase (since it was totally useless).
-Changed the mod to use the Forge system for handling textures.  On the bright side, this means that this mod now has infinite texture indices for maximum compatibility with other mods.  On the down-side, this means that existing texture packs for the mod will no longer work until they are adpated to the new system.  My sincere apologies for the inconvenience this reperesents, but the decision to make this change is in the long-term best-interest of the mod.
-Along with the above, did a lot of texture work on the mod.  You should notice quite a few subtle visual improvements.
-KNOWN BUG: Currently textures will not be displayed properly on mod-blocks when they are pushed by pistons.  This will be corrected with the release of the next version of the Forge.
-Removed "fcUseDefaultLightTextures" from the mod's config file as it was no longer really relevant anymore with the custom texture packs that exist for the mod, and complicated the switch to the Forge texture system unnecessarily.
-Fixed problem with cement "battling" with water it comes into contact with.  Cement now beats the crap out of water (and lava) without even breaking a sweat, and leave in crying for its mommy (could be useful for underwater construction or filling in lava pits).
-Fixed problem where Hibachi wouldn't immediately extinguish Stoked Fire above it when turned off.
-Fixed problem where pottery couldn't be formed if not placed immediately above a Turntable.
-Fixed problem where Vases would lose their color when swallowed by a Block Dispenser.
-Fixed problem where blocks swallowed by Block dispenser wouldn't display properly textured hit effects for certain block-types (like colored wool and Vases).
-Added flying cows and rabbits that can be worn as hats.

Version 2.91

-Added alternate recipe for cake using Flour instead of unprocessed wheat.
-Added ability to melt-down various items in the Crucible.
-Added custom rendering effects to the Crucible.
-Added Pottery sloughing off clay as it is formed.
-Changed Hopper to not delay when picking up items dropped by the player.
-Fixed problem with Planters where plants could be planted on them in their default state.
-Fixed problem with Block Dispenser not being able to swallow powered cake.
-Fixed problem with Crucible consuming incorrect amounts of iron when multiple stacks were present in its inventory.
-Fixed problem with Crucible not dropping its contents when it is destroyed.

Version 2.90

-Added a pottery system.
-Added a ton of other stuff I'll let you guys figure out on your own :)
-Added support for the Minecraft Forge.  Note that you will now have to install the Forge for the mod to function.

Version 2.82

-Added alternate fence recipe using Moulding.
-Added alternate wood stairs recipe using Moulding.
-Added alternate sign recipe using wood Panels.
-Added alternate door recipe using wood Panels.
-Added alternate trap door recipe using wood Panels.
-Added alternate recipe for the Wood Blade using wood Panels instead of wood blocks.
-Removed some trailing spaces after the fcGrateID line in the mod's config file to fix a problem with all settings after that line not being read by the game.  ****WARNING****: This change may invalidate some save-files IF you had previously reassigned the values that were not being read properly.  In order to get around this, you'll need to use the default values for item ID's for lines after the one mentioned above, since this is what your save was previously using.
-Added code to ignore spaces in the config file to prevent the above kind of problems ever occurring again.
-Fixed problem with mod blocks with inventories ejecting their contents in such a way when they are destroyed, that the resulting items sometimes become stuck in neighboring blocks.  This still occurs with vanilla blocks however (like the chest).
-Block Dispensers now destroy the inventory contents of any other Block Dispensers they swallow to prevent exploits involving this behavior.
-Fixed problem with Bellows not expanding if the Axle powering it was destroyed.
-Fixed problem with player falling down through the block below if minecart he was riding was swallowed by a Block Dispenser.
-Fixed problem with scaling of textures on the switch for the Turntable.
-Made a number of changes to the mod's code structure to make it *less* dependant on the world.class (fd.class in 1.7.3).  This should reduce (not eliminate) the number of problems that people experience with the mod if they overwrite this class with one from another mod (like ShockAhPI, the Aether or MC Extended).
-Fixed problem with the Saw occasionally breaking when trying to cut blocks pushed by pistons.
-Fixed problem with regular torches sometimes rotating improperly on the Turntable.
-Fixed bug with Block Dispenser being able to pick up ice blocks.
-Changed Companion Cube to eject red dye when ground in Mill Stone as opposed to red wool.

Version 2.81

-Added custom icons for Glue and Tallow.
-Fixed problem with stoked fire returning to normal too quickly over a Hibachi.
-Reduced volume of sound-effect when Gear Box powers up.
-Cleaned up the Block Dispenser facing code.  This should correct a number of problems with the facing of dispensed blocks.
-Changed the way rendering works in the Cauldron so that time spent rendering does not translate into time spent cooking, and vice versa.  Also provided the rendering process with a "cooldown timer" so that if the fire beneath the cauldron is not stoked momentarily, rendering progress won't be immediately lost (although it won't progress during this time either).
-Changed a few things about the way stoked fire behaves so that blocks can be placed in it, and it will go out if the player hits it (just like regular fire).
-Added the ability to turn the Water Wheel by dropping water along its sides,
-Bellows now lift entities that are resting on them when they expand.

Version 2.80

-Added the Bellows.
-Added Glue.
-Added Tallow.
-Added the Haft.
-Added alternate recipe for the Wood Blade using Glue instead of goo balls.
-Added alternate recipe for the sticky piston using Glue instead of goo balls.
-Changed the Turntable recipe to use wood Panels instead of wood.
-Adjusted the visual offset of the Turntable switch to be aligned with the markers on its texture.
-Fixed problem with Gear Boxes attached to Wind Mills still sometimes breaking after rain had stopped.
-Removed changes to BlockPistonBase class and moved the code in question elsewhere for the sake of compatibility with piston mods.
-Corrected orientation problem when placing Pistons with the Block Dispenser.
-Increased the size of a couple of arrays in the modified BlockFire class to avoid incompatibilities with MC Extended.

Version 2.71

-Added the Wood Blade as an item.
-Changed Water Wheel recipe to require Wood Blades instead of wood, and to get rid of gear in centre.
-Changed Wind Mill recipe to get rid of gear in centre.
-Reduced the number of settings on the Turntable from 11 to 4 (.5 seconds/1 seconds/2 seconds/4 seconds).
-Reduced the height to which the Turntable rotates blocks above it from 12 to 2.
-Changed the Turntable recipe to replace the Axle with Redstone, and the Redstone with a Gear.
-Fixed problem with repeater always setting its delay to 4 when rotated by the Turntable.
-Fixed a rather major bug in the Detector Block logic that was introduced within the past couple of versions and which was causing it to malfunction under a wide range of circumstances.
-Fixed problem with upwards-facing Detector Blocks taking up to 5 seconds to detect something in front of them.


Version 2.70

-Added the Turntable.  Let the good times rotate!
-Added Rollers as a new item that acts as an additional filter-type in the Hopper.
-Changed Axle to drop sticks when destroyed, instead of wood, since it can now be crafted using Moulding.
-Changed rope to set an upwards facing Anchor into motion when a Pulley causes the rope to descend on the Anchor.
-Changed placement code for Water Wheels and Wind Mills so that they can not extend beyond max-height (128) in the world.

Version 2.66

-Updated to version 1.7.3 of Minecraft.

Version 2.65 (Unreleased)

-Added ability for Minecart Rails (of all types) and Redstone Wire to be lifted by Platforms.  Note that sloped-rails can not be lifted in this manner and will break if you attempt to do so.  Also, redstone is non-functional while in transit and its shape will change to reflect this.
-Added alternate recipe for Axle using Moulding instead of Wood blocks.
-Restored the ability to "stick" objects (like torches) to the Companion Cube.
-Increased the amount of iron used in the Cauldron recipe to be more consistent with other full-block recipes in the game (2 extra ingots fill in the empty spaces at the top of the Cauldron recipe).
-Fixed a few problems with pistons interacting with the empty space directly in front of a Detector Block.
-Changed moving Platforms and Anchors to break when pushed by pistons to correct a number of problems that this behavior caused.
-Fixed problem with Water Wheels and Wind Mills occasionally duplicating when the axle they were attached to was pushed by a piston.
-Fixed problem with Axles remaining powered after being pushed by pistons, when they shouldn't be powered in their new location.
-Fixed problems with Hibachis being pushed by pistons and not updating their state properly.
-Fixed problem with Light Block not updating properly when pushed by piston.  Note that this involved introducing a small delay (1/10th of a second) between when a Light Block is powered and when it actually lights up, so it may affect existing circuits in a *very* minor way.
-Made changes to Mojang's wolf-code so you can still order them to follow you even if they glitch out and don't recognize you as their owner.  HOWEVER they will likely still not attack your targets and such, as fixing that would require modification of another base-class.  Note: These bugs are entirely Mojang's, I'm just trying to help people out by fixing them up a bit.
-Fixed problem with sand and gravel not always falling properly through the empty space in front of a detector block.
-Changed the way moving Platforms handle collisions to prevent the player occasionally going through them when they stop.
-Changed the way Cauldron renders to fix some slight visual glitches.
-Fixed entity duplication bug with the Block Dispenser.
-Changed Block Dispenser to be able to place and swallow leaf blocks.
-Changed moving Platforms and Anchors to destroy Water Wheels and Wind Mills that they pass through.
-Fixed problem with Block Dispenser swallowing the extended arms of pistons.
-Fixed problem with Block Dispenser not placing pistons properly.

Version 2.64

-Updated the mod to version 1.7.2 of Minecraft.
-Fixed slight rendering glitch with the Cauldron that would appear around the top edges.
-Changed Block Dispenser recipe to tone down the amount of mossy cobble used, and to use smooth stone at the base.
-Changed Hibachi recipe to use smooth stone at the base instead of cobble.
-Changed the Detector Block recipe to use smooth stone at the base instead of cobble.
-Changed the Mill Stone recipe to use smooth stone at the base instead of cobble.
-Changed the way the Mill Stone and sideways-facing Saws eject items so that they do not wind up on top of the device in question.

Version 2.63

-Fixed Block Dispenser destroying block if its inventory is full.
-Changed Block Dispenser recipe to include more mossy cobble to compensate for no longer requireing regular dispenser.
-Changed Saw Placement to be based on player orientation rather than on the block face the saw is placed on (just like Gear Boxes).
-Changed the way the Saw drops items it generates when sawing blocks to prevent them getting stuck in neighbouring blocks.
-Similar to the changes to the Saw, changed the way the Mill Stone drops processed items so they don't get lodged in neighbouring blocks.
-Change the Saw to drop a belt when it is destroyed through misuse.
-Fixed problem with "fcFaceGearBoxAwayFromPlayer" config file setting not working properly.
-Added ability for the Saw to process Corners into Gears.
-Added the ability for the Saw to process Companion Cubes.
-Added ability for Mill Stone to grind sugar-cane into sugar.
-Created custom icon for flour to help differentiate it from sugar.
-Created custom renderer for the Hand Crank when it is in item form to help differentiate it from a lever.
-Added text messages when there's not enough room around a Wind Mill or Water Wheel to place them.
-Changed Platforms and Anchors so that player and mobs won't "pop" on top of them from below.
-Changed Platforms and Anchors so that they deal damage to players and mobs if they descend on them.
-Fixed problems associated with having 2 Anchors connected to Platforms within 2 blocks of each other resulting in Platforms being lifted incorrectly by connected Pullies.
-Added the ability for the Cauldron to "swallow" items dropped on top of it, just like a Hopper.
-Changed Nethercoal recipe to only produce 1 piece of coal instead of 2 for balance purposes.

Version 2.62

-Fixed shimmering rendering problem on Platform when viewed from a distance.
-Fixed problem with moving Anchor occasionally breaking the rope it's attached to for no discernable reason.
-Fixed gaps in Rope that would occasionally form above an Anchor when the connected Pulley was rapidly powered on and off.
-Powered cake.

Version 2.61

-Changed the crafting recipes for Platforms to use Wicker for the top and bottom surfaces.
-Adjusted the rendering of Platforms to fit the change to the Wicker recipe.
-Added custom inventory renderer for the Platform.
-Changed Mill Stone texture to make it more obvious that it needs to be powered from the top or bottom.
-Fixed Block Detector not being able to see moving Anchors and Platforms.
-Added config file setting to change the way Gear Boxes place so that the output faces away from you.
-Changed the Detector Block recipe to use one lapis block instead of two.
-Added *small* chance that Hemp Seeds will drop when you destroy tall grass.
-Changed the way items pass over filtered Hoppers.  They no longer need to descend a level to continue.
-Changed the way mechanical devices update there state to try to avoid problems with them falling out of sync.  This affect the Gear Box, the Hopper, and the Pulley.
-Fixed items popping on top of Platforms when they are lowered onto them.
-Food is now turned into "Foul Food" when you put Dung into a Heated cauldron with it.

Version 2.60

-Added the Platform.
-Added the Pulley.
-Fixed crash bug when you right clicked on a Wind Mill with nothing in your hand.
-Changed Nethercoal recipe to be shapeless.
-Fixed Block Dispenser to not be able to swallow the purple nether-portal blocks.
-Eliminated the need for a seperate Anchor item.  Similar to what I did for the Axle in version 2.10, please place any Anchor items you may have in your inventory into the world, and then re-harvest them to convert them to the proper block type.  If you have an anchor that still looks like a 2D bitmap in your inventory, then this needs to be done as I will recycle the item ID in a future release.
-Changed Block Dispenser Recipe to no longer require a regular dispenser at its centre.

Version 2.59

-Adjusted output of Mill Stone when grinding wool to match changes that Mojang recently made to the string to wool recipe.
-Added growling sound to wolves when they produce dung to help distinguish the event from background mechanical noise.
-Tweaked Gear Box placement code to always orient opposite the face of the block you place it on.  This should make Gear Box placement much more consistent and intuitive.
-Got rid of a couple of custom textures for the mod that were duplicates of ones already found in the game to save on Texture IDs. This affects the bottom of the cauldron and the bottom of the Hibachi.
-Created new custom icon for Rope.
-Added collision to drying cement so that you can walk over it instead of just passing right through it.
-Changed Cement to whimper when poured, and to scream when powered by redstone (just like the old Booster Blocks used to).
-Totally removed placement restrictions on the hatch.  It can now be placed anywhere, with or without a supporting side-block (before it just wouldn't be removed if the side-block was).
-Fixed Block Dispenser processing of snow blocks.
-Changed Block Dispenser to be able to swallow uneaten cake.  However, cake that has slices already eaten from it will still be destroyed if the Block Dispenser attempts to swallow it.
-Changed Block Dispenser to be able to dispense the Hatch.
-Changed Block Dispenser to be able to pick-up clay blocks.
-Fixed the Block Dispenser being able to swallow mob spawners.  Sorry guys, this felt way too much like a cheat to me.
-Changed Block Dispenser to fire its inventory contents in order instead of randomly.  This basically allows you to create sequences of blocks that you wish to place and could even be used to create multi-frame animations using multiple Block Dispensers and colored wool.  There's now an icon in the Dispenser's inventory to indicate which slot will be dispensed next, and manually changing the inventory of the dispenser will reset this indicator to the first inventory slot.

Version 2.58

-Quick bug-fix for problems with converting gravel into sand and flint with the Hopper filter.


Version 2.575

-Changed Wolves so they will not produce Dung or Wolf Chops, or consume loose food, if you are playing multiplayer.
-Added the ability for Wicker to separate gravel into flint and sand when used as a filter on the Hopper.
-Added config file setting to disable the axe modifications, for compatibility with other mods.
-Added the tanning process and Tanned Leather.
-Added the Strap.
-Added the Belt.
-Changed crafting recipe for the Saw to use a Belt.
-Added custom icon for Scoured Leather.
-Fixed problem with wolves cannibalising their own flesh as they die.
-Added wolves turning rabid if you try to feed them Wolf Chops.
-Changed pet Wolves to ditch their collar and display the angry texture if you piss them off.
-Added ability to use clay as "filler" in the Hopper.  The Hopper won't eject clay, so you can fill inventory slots with it to change the Hopper's effective capacity and how long it takes to fill up.
-Removed the placement restrictions on the Anchor, as, like with the hatch, they were serving no useful purpose in a game where blocks of stone can hang suspended in mid-air anyways.

Version 2.55

-Modified the hatch in vanilla Minecraft so that it is no longer destroyed when the block next to it is.  This allows the placement of hatches in the middle of floors, and makes them more versatile overall without affecting their functionality in any other way.
-Added particles to the blade of the Saw to indicate when it is getting mechanically powered.
-Changed Dung production to take into account light levels.  Wolves now output more Dung in very low light conditions (light level of 5 and below).
-Adjusted the overall rate of dung production.  An unfed wolf should now produce Dung on average once every 4 in-game days.  A fed wolf, once a day.  A fed wolf in the dark, twice a day.
-Made the recipe for making two panels into one wood or stone block, shapeless.  This means the panels no longer need to be placed side by side in the crafting grid, but that if you have two panels in any two seperate squares of the grid, they can form a block.
-Added shapeless conversion recipes to convert 2 pieces of Moulding into 1 wood Panel, and 2 corners into 1 piece of Moulding.
-Added ability to color wool and Wind Mills brown using Dung through the usual methods for dye. You can't do it to sheep however, as they tend to react rather badly when you try to rub Dung all over them.
-Changed Hopper to only deposit items into the first slot of a furnace.  This allows for the smelting of stacks greater than 64 items, or the consecutive smelting of different kinds of items in the same furnace.
-Added the Grate as an item.
-Added Wicker as an item.
-Added an extra inventory slot to the Hopper in which you may place various items that act as a filter on what items the hopper will "swallow".  You can use a ladder, a hatch, a Grate, or Wicker as a filter.

Version 2.50

-Added Dung.
-Fixed problem with Fishing Rod displaying as a gear when the line is cast.
-Tweaked Rope item icon to make it more visible.
-Changed wolf to be able to consume nearby food laying on the ground.
-Fixed problem with Detector Block occasionally not detecting precipitation quickly enough to prevent damage to Gear Boxes attached to Wind Mills. 


Version 2.40

-Added the Wind Mill.  For real this time :)
-Added Fabric made of Hemp Fibers.
-Changed the name of the Wind Mill Blade to the 'Sail'.
-Changed the crafting recipe for the Sail to use Fabric instead of Wool.
-Added the ability to individually color each blade of the Wind Mill with dye.
-Changed Detector Block to properly sense snow falling if it is facing upwards.
-Changed Wind Mill to spin out of control in snow storms.

Version 2.31

-Updated the mod to version 1.6.6 of Minecraft.
-Modified properties of all wood-based blocks in the mod so that the axe would be an effective tool on them.
-Also modified the same for all wood based-blocks in the vanilla game so that axes generally behave as you would expect (this affects the note block, wood stairs, work bench, sign, wood door, added wind mills, juke box, fence, pumpkin, Jack'O'Lantern, and the trap door) instead of not working in weird instances as was typical of the game before this change. 

Version 2.30

-Reduced drag on carts without riders.  This effectively increases the distance such a cart can travel without losing speed from 6 blocks between powered rails, to 12 blocks.
-Increased the hardness of Panels.
-Added the ability for the saw to cut Panels into Moulding, and Moulding into Corners.
-Fixed Saw to not be able to be powered from the direction in which its blade is facing.
-Added the ability for the Saw to process Sugar Cane, Wheat, and Hemp.

Version 2.25

-Updated the mod to version 1.6.5 of Minecraft.
-Isolated the code for the Block Dispenser from the regular Dispenser.  This was largely an internal change to aid in updating and to allow for future changes, with the only noticable effect being that the Block Dispenser Gui now correctly displays "Block Dispenser" instead of the old "Dispenser".
-Added shift-click functionality for transferring to and from inventory of the Block Dispenser.
-Added crafting recipe to convert 2 Omni-Slabs back into a block (either smooth stone or wood) by placing them side by side in the crafting area.
-Removed the ability to grind wood into wood Omni-Slabs in the Mill Stone, since you can now create them with the Saw, and it's really not the intent of the Mill to be used for solid blocks like this.  You can still create the smoothstone Omni-Slabs in this manner however (at least for now).
-Fixed problem with mobs and players taking damage from sides of the Saw other than where the blade was located.  Note that this will likely require adjustments to any mob-grinders that involve the Saw.
-Optimized the Water Wheel to only perform updates of certain costly aspects of its state far less frequently.  Theoretically, this should allow for placement of about 20 times as many water wheels without any drop in preformance. It wasn't a problem before, but now it's REALLY not a problem ;)
-Renamed Omni-Slab to the "Panel", because "Omni-Slab" just sounded idiotic, and I was beginning to feel more and more like a tard every time I said it :)
-Changed Block Dispenser so that it could swallow Glow Stone blocks intact.
-Changed Detector Block so that it could instantly react to trees growing in front of it.
-Added Better Than Wolves themed character-skin to the download for those of you who want to show your support for the mod in-game or in SMP :)

Version 2.20

-Added the Saw.
-Modified the Mill Stone to ALWAYS eject ALL processed items to the sides of the mill.  This opens the door to automated milling.
-Fixed problem with Block Dispenser generating pink particles when operating in fron of a Detector Block.
-Fixed Block Dispenser being able to pick-up fire, although I have to admit, it was kinda cool :)
-Changed name of Lens to "NOT A BLOCK" so that people that hack their inventories hopefully stop bothering me about it.  Disabled the crafting recipe as well, although I don't think anyone had discovered it (I had forgotten it was in there), and changed the texture to horrid day-glow pink to further hammer the point home :)
-Changed Item Render for Omni-Slab to make it easier to distringuish from a regular slab.


Version 2.10

-Added the Hopper.
-Changed Detector Block to trigger if it is facing upwards and rain or snow falls on it.  I couldn't test with snow however (rain works fine), so if someone happens to run into a snow-storm and could let me know if it works, I'd be much obliged :)
-Reviewed all the blocks in the mod and made sure they had appropriate hit-effect textures.
-Added functionality to Gear Box where if it is receiving redstone power, it disengages the gears and will not output any power, regardless of the input state.  This effectively allows you to turn mechanical power on and off through redstone control.
-The Hand Crank now breaks if you try to power more than one device with it simultaneously.
-The Axle now breaks into component parts if it is powered in an inappropriate way (for example, a total axle length of over 3 blocks).
-The Mill Stone and Cauldron now eject their contents when they are destroyed (like chests or the Block Dispenser).
-Created custom renderer for Axle block in ineventory.
-Eliminated the need for the Axle Item (the one that looks like a stick).  Please place any items of this type you have in the world, and then remove the block again to reset them to the appropriate state.  The ItemID will be recycled in future versions of the mod.
-Changed the Water Wheel to not be stackable.  I think it's a large enough object to warrant this :)

Version 2.01

WARNING: Version 2.01 of this mod requires a reinstall of the mod onto a clean copy of Minecraft!  Many base-class modifications have been eliminated, so installing over an old copy will likely result in a crash.  ALSO: The old Minecart Pressure Plates and Soul Boosters have been completely eliminated from this version.  MAKE SURE YOU ELIMINATE ALL INSTANCES OF THESE ITEMS FROM YOUR SAVE GAME BEFORE INSTALLING THIS VERSION.

-Added Axle
-Added Gear Box
-Added Water Wheel
-Changed gear recipe to use fewer sticks.
-Added icon for hemp. Thanks to Battosay for the texture (modified)!
-Completely eliminated the old Minecart Booster and Minecart Pressure Plates from the mod.
-Eliminated base-class modifications to: EntityFallingSand.class, EntityMinecart.class, ItemBlock.class, and ItemReed.class.

Version 1.87

-Added ability for player to retract rope from an anchor, by right clicking on it with anything other than a rope in his hand (Thanks to Thalmane for suggesting this!)
-Added ability for Mill Stone to convert wool blocks into string.
-Added ability for Mill Stone to "process" Companion Cubes.
-Added custom Donut icon (thanks to Craftineer for the texture!)
-Companion cubes now show their appreciation for being put out of their misery.
-Boosted resistance of Anchor to make it more obvious that it needs to be destroyed with a Pick.

Version 1.86

-Fixed problem with the Item IDs for Hemp Fibers and Scoured Leather becoming confused.
-Fixed issue with the way food stacks in the Cauldron.


Version 1.85

-Added the Omni-Slab in wood and stone varieties.
-Upgraded the mod to the latest versions of MCP and Modloader to hopefully solve some compatibility issues.
-Modified title screen to display mod-specific instructions and dispense general wisdom.

Version 1.80

-Added the Anchor.
-Added the Rope.
-Changed Gear recipe to produce 2 Gears instead of just 1.
-Fixed problem with the Block Dispenser destroying specific kinds of items in its inventory if the block in front of it already contained something.
-Added collision to the base of the Hand Crank, so that you can now step up onto it, and don't just walk right through it.

Version 1.70

-Added the Hand Crank as a new block type.
-Added the Mill Stone as a new block type.
-Added Gears as an item.
-Added Flour as an Item.
-Added Hemp Fibers as an item.
-Added Scoured Leather as an item.
-Added smelting recipe to bake Bread from Flour in the furnace.
-Added Donuts (cook flour in the cauldron).
-Modified cauldron to spit out cooked items should its inventory be incapable of containing them.
-Changed Block Dispenser so it no longer spits out an item if there is a non-opaque object in front of it.

Version 1.61

-Tweaked the way hemp grows.  It should be *slightly* faster to grow now, especially in dense fields.
-Hemp now only grows under direct sunlight OR if there is a powerful light source up to two blocks above it.  Light-blocks to the side of the plant will no longer work.
-Made Companion Cubes and Hemp Crops flammable.  This means lightning can now send a whole field of hemp up in flames.  You can also set it ablaze when the authorities arrive.
-Rate of hemp seed drop when using hoe on grass is now based on the hoe's material (stone drops more than wood, etc.)  Consistent with other tools in the game, gold is the most effecient (but least durable), with diamond probably being the best mix between effeciency and durability.
-Added custom texture for hemp seeds to make them easier to differentiate from wheat.
-Changed Hibachi code to fix potential performance issues, and to stop it going out in the rain.
-Boosted the hardness of the Hibachi and Cauldron to be more consistent with other block types.
-Added ability for Block Dispenser to "process" chickens.

Version 1.60

-Added Hemp.
-Made changes to Block Dispenser which should allow it to plant seeds from other mods.

Version 1.52

-Fixed crash bug when Block Dispenser picked up redstone dust, which probably affected other block-types as well.

Version 1.51

-Fixed problem with block dispenser not properly handling coloured wool.  This should also resolve potential problems with different sapling types and other similar blocks that may be included in the game in the future, or which are features in other mods.
-Fixed problem with multiple Block Dispensers being able to swallow entities (minecarts, wolves, etc.) at the same time.
-Changed Block Dispenser to not dispense *anything* (objects and entities included), if the block in front of it is blocked.  This may help in the construction of more complex mechanisms and is more consistent with overall behaviour.
-Fixed problem with light-blocks not powering each other indirectly.
-Fixed detector block interacting in weird ways with various other block types (redstone wire, crops, trees, etc.)
-Added sound effect to Detector Block when triggered.
-Added sound effect to Block Dispenser when it is dispensing/swallowing entities (like minecarts and boats).
-Added config file setting for using Minecraft default textures for light blocks.  This is for people using custom texture packs that feel the mod's custom textures clash with other in-game elements.


Version 1.50

-Added the Detector Block
-Disabled Minecart Pressure Plate functionality.  This is likely the last version they'll be in the game in any way shape or form, and I will soon recycle their block ids (along with the booster block).  If you haven't removed them from your worlds yet: DO IT SOON!!!!
-Changed threshold value on angle when placing Companion Cube and Block Dispenser so that they aren't accidentally placed facing up or down as frequently.  You'll have to be looking up or down at a steeper angle now to place them in the corresponding directions.
-Removed maximum value of 255 on block and item IDs in the config file for increased compatibility with Minecraft Extended mod.

Version 1.40

-Added new detector rail-types: wood and obsidian, and modified the way the normal (stone) detector rails works.  Wood triggers on any minecart.  Stone triggers on any minecart containing something (chest, furnace, or mob).  Obsidian only triggers if a minecart contains a player.
-Changed Iron Pressure Plates to Obsidian Pressure Plates.  For greater visibility contrast relative to stone pressure plates, because it makes sense that it takes more weight to move obsidian than stone (not so much with iron), to give an in-game use for obsidian, and because it's impossible to see the difference between a stone and iron detector rail (given how small the pressure plate is on the rail).
-Disabled crafting recipes for minecart pressure plates (since they are replaced by the detector rails), and when a minecart pressure plate already in the game is destroyed, it now drops its constituent resources so that players may recover them.  Note that these blocks will be completely removed from the mod in a future version so it is in your best interest to recover these resources now before they dissapear (same with the old minecart boosters).
-Completely disabled minecart booster functionality in ongoing process of phasing them out.  If you haven't cleared them out of your saves yet, and recovered the resources, now is the time to do it before they are completely gone.
-Fixed problem with nethercoal recipe that didn't allow it to be crafted in any slot.
-Reorganized the way the mod assigns block and item ids, to hopefully resolve an incompatibility problem with other mods.
-Added ability for the Dispenser Block to swallow minecarts, boats...and wolves.
-Added the Companion Cube.


Version 1.31

-Created seperate texture directory for the mod to make tracking down the graphics files associated with it easier.
-Retextured the Hibachi, and replaced the iron in the crafting recipe with cobble.  I think this fits the idea of the Hibachi being an "open-top furnace" and makes sense since stone would melt at higher temperatures than iron.  It also reduces the mod's overdependance on iron.  
-Retextured Cauldron.  Meat your new friend.
-Retextured Light Block.
-Retextured the Block Dispenser.  Also toned down the amount of mossy cobble used in its crafting recipe.
-Retextured cement.


Version 1.30

-Added a new block type: Cauldrons.
-Added Wolfchops (raw and cooked).  Finally!  A use for wolves!
-Added Nethercoal item.


Version 1.25

-Updated mod to be compatible with version 1.5_01 of Minecraft.
-Removed the recipe for the minecart booster as its functionality is replaced by the booster-rail.
-When minecart boosters already in a save file are destroyed, they now return the ingrediants originally used in crafting them.  This can be used by players to salvage any resources they may have already invested in the boosters.
-Changed code to properly register the blocks in the mod through modloader.
-Changed the crafting recipe for cement to use soulsand instead of goo since it is no longer used by the booster, can be more reliably found in-game (some folks seem to never be able to find slimes), and since it makes sense in terms of the logic behind the recipe.  Of course, Steve is now solidfying souls into concrete, with all the moral ramifications that entails...
-Removed mods dependency on modifying TileEntityDispenser base class.
-Removed mods dependency on modifying BlockFire base class.
-Fixed problems where block dispenser would occasionally pick-up flint when removing a gravel block, and cobble when picking up smoothstone.
-Changed block dispenser to be able to place blocks in squares containing entities (like wolves), and to not eject a block in item-form if the block in front of it is already occupied.
-Changed block dispenser to pick-up tnt instead of triggering it to make beahaviour more consistent with other block types, to make construction of semi and full auto cannons more interesting (while convenient the way they were, it really feels like they should have separate loading, priming, and firing mechanisms), and to provide the player with a method of desposing of placed TnT. 
-Changed block dispenser to be able to plant seeds.
-Added a slight turn-on and turn-off delay to Hibachi. Fixes a number of subtle problems with how they behave and makes their function a little more believable and consistent with the rest of the redstone elements in the game.
-Partially implemented cauldron.  This feature is not complete, but I wanted to release a version compatible with 1.5_01 as quickly as possible, so I disabled the crafting recipe and left it in as is.  If you edit it into the game (you can't build it legitimately), it will be an entirely nonfunctional and utterly boring block :)

Version 1.24

-Totally isolated cement code from BlockFLuid and BlockFlowing, eliminating this mod's need to change those base class files.
-Put in fixed distance limit on how far cement could spread.  This increases the distance it can flow on level ground, to aid in it's use in construction, while limiting its down-hill spread restricting its use for griefing and its potentail for disaster.
-Changed the way cement spreads.  Unlike other in-game fluids, it doesn't only flow towards downward slopes, but instead spreads in a circular pattern around the point at which it is put down.
-Changed various aspects about the way cement displays to make it more aesthetically pleasing.
-Added dry time to cement which causes it to slowly dry instead of just instantly turning solid after being placed.
-Added partially dry state to cement which changes the visual when it's about to solidify, and also blends its height closer to that of a full block to smooth the transition.


Version 1.23

-Fixed some problems with how cement spreads, toning down its tendancy to form "the tidal wave of doom"
-Removed custom cement texture and removed mod's dependecy on a modified terrain.png
-Fixed cement bucket recipe so that it can be built in any crafting slot

Version 1.22

-Modified Block Dispensers to be able to place/collect smooth stone without converting it to cobble.
-Toned down the amount of iron used in some of the crafting recipes, as it was extremely heavy.  This affects the recipes for the Hibachi, Minecart Boosters, and Minecart Plates.
-Fixed problem with minecart pressure plate running current to far too many neighboring blocks.  It now needs to have wire running directly to it to supply current.
-Fixed problem with Hibachi burning while submerged in liquid (water, lava & cement) through constantly reigniting.  The Hibachi will no longer burn under these conditions.

Version 1.21

-Added ability for player to orient Block Dispensers upwards and downwards
-Changed Block Dispensers to only accept direct redstone current to the dispenser block, or the block directly above it. 
-Changed Hibachi to accept Redstone current From Block Above


Version 1.20

-Added Block Dispensers.


Version 1.01

-Added ModLoader support.
-Added iron pressure plates.
-Added wood and iron versions of the minecart pressure plater (stone pressure plates from previous versions automatically convert to wood to preserve their functionality).

Version 1.0

-Initial Release