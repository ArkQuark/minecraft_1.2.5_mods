~~~~Read Me~~~~
~~~~~~~~~~~~~~~
By: Nightlord491
How to install Color Outlines 1.2.5:

1) Open up your minecraft.jar with WinRar, 7Zip or something similar, 
then drag and drop the 6 files from this mod into your 
minecraft.jar

2) Remember to delete the folder 'META-INF' from your minecraft.jar
if it's not already deleted.

This mod does not need ModLoader.
____________________________________________________________________

This is all you need, to use this mod!

Here are some quick things you should know about this mod:



You can find the block outline color option in Options > Video Settings > Color Outlines
Now choose a color from the list and your color is set.

New colors will be added in a future update.

____________________________________________________________________

Please report any bugs found in this mod on PlanetMinecraft!

Enjoy!