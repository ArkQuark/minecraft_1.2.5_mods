// Bytecode patcher for GLSL shaders.  
// I don't care what you do with this source but I'd like some credit if you reuse this in part or whole. - daxnitro

import javassist.*;
import javassist.expr.*;

import java.io.File;
import java.io.DataOutputStream;
import java.io.FileOutputStream;

import java.lang.Exception;

import daxnitro.nitrous.ModHooks;
import daxnitro.nitrous.PreferenceManager;

public class Hooks implements ModHooks {
	public boolean install(File installDir) throws Throwable {

		String dirPath = installDir.getPath();
		
		File codesign_rsa = new File(dirPath, "META-INF/CODESIGN.RSA");
		File codesign_sf  = new File(dirPath, "META-INF/CODESIGN.SF");
		
		if (codesign_rsa.exists() || codesign_sf.exists()) {
			System.out.println("Warning: This version of Nitrous is unaware of CODESIGN.RSA and CODESIGN.SF. It's recommended that you download the newest version at nitrous.daxnitro.com.");
		}

		ClassPool pool = ClassPool.getDefault();
		pool.appendClassPath(dirPath);
		pool.appendClassPath(new File(new File(Hooks.class.getProtectionDomain().getCodeSource().getLocation().toURI()).getParentFile(), "files").getPath());
		
		String lwjglPath = new File(new File(PreferenceManager.getStringValue(PreferenceManager.MC_JAR_PATH_KEY)).getParentFile(), "lwjgl.jar").getPath();
		pool.appendClassPath(lwjglPath);

		// EntityRenderer.class

		CtClass entityRenderer = pool.get(EntityRenderer);
 
 		CtClass floatLongParameter[] = {CtClass.floatType, CtClass.longType};
 		
		CtMethod renderWorld = entityRenderer.getDeclaredMethod(EntityRenderer_renderWorld, floatLongParameter);

		final Hooks hooks = this;

		renderWorld.instrument(
			new ExprEditor() {
				public void edit(MethodCall m) throws CannotCompileException {
					if (m.getClassName().equals("Shaders") && m.getMethodName().equals("beginRender")) {
						hooks.alreadyInstalled = true;
					}
				}
			}
		);
		
		if (alreadyInstalled) {
			System.out.println("Already installed.");
			return true;
		}
		
		renderWorld.insertBefore("Shaders.beginRender(" + EntityRenderer_mc +", $1, $2);");

		renderWorld.insertAfter("Shaders.endRender();");

		renderWorld.instrument(
			new ExprEditor() {
				public void edit(MethodCall m) throws CannotCompileException {
					if (m.getClassName().equals(EntityRenderer) && m.getMethodName().equals(EntityRenderer_setupCameraTransform) && m.getSignature().equals("(FI)V")) {
						m.replace("{ Shaders.setClearColor(" + EntityRenderer_fogColorRed + ", " + EntityRenderer_fogColorGreen + ", " + EntityRenderer_fogColorBlue + "); $_ = $proceed($$); Shaders.setCamera($1); }");
					} else if (m.getClassName().equals(RenderGlobal) && m.getMethodName().equals(RenderGlobal_sortAndRender) && m.getSignature().equals(RenderGlobal_sortAndRender_sig)) {
						m.replace("{ if ($2 == 0) { Shaders.beginTerrain(); $_ = $proceed($$); Shaders.endTerrain(); } else if ($2 == 1) { Shaders.beginWater(); $_ = $proceed($$); Shaders.endWater(); } else { $_ = $proceed($$); } }");
					} else if (m.getClassName().equals(RenderGlobal) && m.getMethodName().equals(RenderGlobal_renderAllRenderLists) && m.getSignature().equals("(ID)V")) {
						m.replace("{ Shaders.beginWater(); $_ = $proceed($$); Shaders.endWater(); }");
					} else if (m.getClassName().equals(EntityRenderer) && m.getMethodName().equals(EntityRenderer_renderRainSnow) && m.getSignature().equals("(F)V")) {
						m.replace("{ Shaders.beginWeather(); $_ = $proceed($$); Shaders.endWeather(); }");
					} else if (m.getClassName().equals(EntityRenderer) && m.getMethodName().equals(EntityRenderer_renderHand) && m.getSignature().equals("(FI)V")) {
						m.replace("{ Shaders.beginHand(); $_ = $proceed($$); Shaders.endHand(); }");
					}
				}
			}
		);

 		CtClass doubleParameter[] = {CtClass.doubleType};
 		
 		CtMethod enableLightmap = entityRenderer.getDeclaredMethod(EntityRenderer_enableLightmap, doubleParameter);

 		enableLightmap.insertAfter("Shaders.enableLightmap();");

 		CtMethod disableLightmap = entityRenderer.getDeclaredMethod(EntityRenderer_disableLightmap, doubleParameter);
 		
 		disableLightmap.insertAfter("Shaders.disableLightmap();");
		
		// Tessellator.class
		
		CtClass tessellator = pool.get(Tessellator);
 
 		tessellator.addField(new CtField(pool.get("java.nio.ByteBuffer"), "shadersBuffer", tessellator), "null");
 		tessellator.addField(new CtField(pool.get("java.nio.ShortBuffer"), "shadersShortBuffer", tessellator), "null");
 		tessellator.addField(new CtField(pool.get("short[]"), "shadersData", tessellator), "new short[]{-1, 0}");

 		CtClass int3Parameter[] = {CtClass.intType, CtClass.intType, CtClass.intType};
 
 		CtMethod setEntity = CtMethod.make("public void setEntity(int id) {" +
			"shadersData[0] = (short)id;" +
			"}", tessellator);
 		tessellator.addMethod(setEntity);
 
 		CtClass intParameter[] = {CtClass.intType};
 
 		tessellator.getDeclaredConstructor(intParameter).insertAfter(
			"shadersBuffer = " + GLAllocation + "." + GLAllocation_createDirectByteBuffer + "($1 / 8 * 4);" +
			"shadersShortBuffer = shadersBuffer.asShortBuffer();"
 		);
 		
 		CtClass noParameter[] = {};
 		
		CtMethod draw = tessellator.getDeclaredMethod(Tessellator_draw, noParameter);
		
		draw.instrument(
			new ExprEditor() {
				public void edit(MethodCall m) throws CannotCompileException {
					if (m.getClassName().equals("org.lwjgl.opengl.GL11") && m.getMethodName().equals("glDrawArrays")) {
						m.replace("{" + 
							"if (Shaders.entityAttrib >= 0) {" +
							"org.lwjgl.opengl.ARBVertexProgram.glEnableVertexAttribArrayARB(Shaders.entityAttrib);" +
							"org.lwjgl.opengl.ARBVertexProgram.glVertexAttribPointerARB(Shaders.entityAttrib, 2, false, false, 4, (java.nio.ShortBuffer)shadersShortBuffer.position(0));" +
							"}" +
							"$_ = $proceed($$);" +
							"if (Shaders.entityAttrib >= 0) { org.lwjgl.opengl.ARBVertexProgram.glDisableVertexAttribArrayARB(Shaders.entityAttrib); }" +
							"}");
					}
				}
			}
		);
		
		CtMethod reset = tessellator.getDeclaredMethod(Tessellator_reset, noParameter);
		
		reset.insertBefore("shadersBuffer.clear();");
		 
 		CtClass float3Parameter[] = {CtClass.floatType, CtClass.floatType, CtClass.floatType};
 
 		CtClass double3Parameter[] = {CtClass.doubleType, CtClass.doubleType, CtClass.doubleType};
 		
		CtMethod addVertex = tessellator.getDeclaredMethod(Tessellator_addVertex, double3Parameter);

		addVertex.insertBefore(
			"if ("+Tessellator_drawMode+" == 7 && "+Tessellator_convertQuadsToTriangles+" && ("+Tessellator_addedVertices+" + 1) % 4 == 0 && "+Tessellator_hasNormals+") {" +
			""+Tessellator_rawBuffer+"["+Tessellator_rawBufferIndex+" + 6] = "+Tessellator_rawBuffer+"[("+Tessellator_rawBufferIndex+" - 24) + 6];" +
			"shadersBuffer.putShort(shadersData[0]).putShort(shadersData[1]);" +
			""+Tessellator_rawBuffer+"["+Tessellator_rawBufferIndex+" + 8 + 6] = "+Tessellator_rawBuffer+"[("+Tessellator_rawBufferIndex+" + 8 - 16) + 6];" +
			"shadersBuffer.putShort(shadersData[0]).putShort(shadersData[1]);" +
			"}" +
			"shadersBuffer.putShort(shadersData[0]).putShort(shadersData[1]);"
			);
		
		// RenderBlocks.class
		
		CtClass renderBlocks = pool.get(RenderBlocks);

		CtClass block = pool.get(Block);
		
 		CtClass renderFaceParameter[] = {block, CtClass.doubleType, CtClass.doubleType, CtClass.doubleType, CtClass.intType};
 		
		CtMethod renderBottomFace = renderBlocks.getDeclaredMethod(RenderBlocks_renderBottomFace, renderFaceParameter);
		renderBottomFace.insertBefore(Tessellator+"."+Tessellator_instance+"."+Tessellator_setNormal+"(0.0F, -1.0F, 0.0F);");

		CtMethod renderTopFace = renderBlocks.getDeclaredMethod(RenderBlocks_renderTopFace, renderFaceParameter);		
		renderTopFace.insertBefore(Tessellator+"."+Tessellator_instance+"."+Tessellator_setNormal+"(0.0F, 1.0F, 0.0F);");

		CtMethod renderEastFace = renderBlocks.getDeclaredMethod(RenderBlocks_renderEastFace, renderFaceParameter);		
		renderEastFace.insertBefore(Tessellator+"."+Tessellator_instance+"."+Tessellator_setNormal+"(0.0F, 0.0F, -1.0F);");

		CtMethod renderWestFace = renderBlocks.getDeclaredMethod(RenderBlocks_renderWestFace, renderFaceParameter);		
		renderWestFace.insertBefore(Tessellator+"."+Tessellator_instance+"."+Tessellator_setNormal+"(0.0F, 0.0F, 1.0F);");

		CtMethod renderNorthFace = renderBlocks.getDeclaredMethod(RenderBlocks_renderNorthFace, renderFaceParameter);		
		renderNorthFace.insertBefore(Tessellator+"."+Tessellator_instance+"."+Tessellator_setNormal+"(-1.0F, 0.0F, 0.0F);");

		CtMethod renderSouthFace = renderBlocks.getDeclaredMethod(RenderBlocks_renderSouthFace, renderFaceParameter);		
		renderSouthFace.insertBefore(Tessellator+"."+Tessellator_instance+"."+Tessellator_setNormal+"(1.0F, 0.0F, 0.0F);");

		// RenderGlobal.class
		
		CtClass renderGlobal = pool.get(RenderGlobal);

 		CtClass floatParameter[] = {CtClass.floatType};
 		
		CtMethod renderSky = renderGlobal.getDeclaredMethod(RenderGlobal_renderSky, floatParameter);

		renderSky.instrument(
			new ExprEditor() {
				public void edit(MethodCall m) throws CannotCompileException {
					if (m.getClassName().equals(World) && m.getMethodName().equals(World_getStarBrightness) && m.getSignature().equals("(F)F")) {
						m.replace("{ $_ = $proceed($$); Shaders.setCelestialPosition(); }");
					}
				}
			}
		);

		CtMethod[] methods = renderGlobal.getDeclaredMethods();
		
		for (CtMethod method : methods) {
			method.instrument(
				new ExprEditor() {
					public void edit(MethodCall m) throws CannotCompileException {
						if (m.getClassName().equals("org.lwjgl.opengl.GL11") && m.getMethodName().equals("glEnable")) {
							m.replace("{ Shaders.glEnableWrapper($$); }");
						} else if (m.getClassName().equals("org.lwjgl.opengl.GL11") && m.getMethodName().equals("glDisable")) {
							m.replace("{ Shaders.glDisableWrapper($$); }");
						}
					}
				}
			);
		}

		// RenderLiving.class
		
		CtClass renderLiving = pool.get(RenderLiving);
 		
		methods = renderLiving.getDeclaredMethods();
		
		for (CtMethod method : methods) {
			method.instrument(
				new ExprEditor() {
					public void edit(MethodCall m) throws CannotCompileException {
						if (m.getClassName().equals("org.lwjgl.opengl.GL11") && m.getMethodName().equals("glEnable")) {
							m.replace("{ Shaders.glEnableWrapper($$); }");
						} else if (m.getClassName().equals("org.lwjgl.opengl.GL11") && m.getMethodName().equals("glDisable")) {
							m.replace("{ Shaders.glDisableWrapper($$); }");
						}
					}
				}
			);
		}
		
		// WorldRenderer.class
		
		CtClass worldRenderer = pool.get(WorldRenderer);
		
		CtMethod updateRenderer;
		
		try {
			// for optifine
			updateRenderer = worldRenderer.getDeclaredMethod("updateRenderer");
			System.out.println("Optifine detected.");
		} catch (Exception e) {
			updateRenderer = worldRenderer.getDeclaredMethod(WorldRenderer_updateRenderer, noParameter);
		}

		updateRenderer.instrument(
			new ExprEditor() {
				public void edit(MethodCall m) throws CannotCompileException {
					if (m.getClassName().equals(RenderBlocks) && m.getMethodName().equals(RenderBlocks_renderBlockByRenderType) && m.getSignature().equals(RenderBlocks_renderBlockByRenderType_sig)) {
						m.replace("{ if (Shaders.entityAttrib >= 0) { " + Tessellator + "." + Tessellator_instance + ".setEntity($1." + Block_blockID + "); } $_ = $proceed($$); }");
					}
				}
			}
		);

		updateRenderer.insertAfter("if (Shaders.entityAttrib >= 0) { " + Tessellator + "." + Tessellator_instance + ".setEntity(-1); }");
		
		// Finish up
		
		renderLiving.writeFile(dirPath);	
		renderGlobal.writeFile(dirPath);
		entityRenderer.writeFile(dirPath);
		tessellator.writeFile(dirPath);
		renderBlocks.writeFile(dirPath);
		worldRenderer.writeFile(dirPath);

		return true;
	}
	
	public boolean alreadyInstalled = false;
	
	// Obfuscated names.
	
	static final String EntityRenderer = "lr";
	static final String EntityRenderer_mc = "r";
	static final String EntityRenderer_renderWorld = "a";
	static final String EntityRenderer_fogColorRed = "this.n";
	static final String EntityRenderer_fogColorGreen = "o";
	static final String EntityRenderer_fogColorBlue = "p";
	static final String EntityRenderer_setupCameraTransform = "a";
	static final String EntityRenderer_renderRainSnow = "c";
	static final String EntityRenderer_renderHand = "b";
	static final String EntityRenderer_disableLightmap = "a";
	static final String EntityRenderer_enableLightmap = "b";

	static final String EntityLiving = "acq";

	static final String RenderGlobal = "l";
	static final String RenderGlobal_renderSky = "a";
	static final String RenderGlobal_sortAndRender = "a";
	static final String RenderGlobal_sortAndRender_sig = "(Lacq;ID)I";
	static final String RenderGlobal_renderAllRenderLists = "a";

	static final String Tessellator = "adz";
	static final String Tessellator_instance = "a";
	static final String Tessellator_draw = "a";
	static final String Tessellator_reset = "d";
	static final String Tessellator_setNormal = "b";
	static final String Tessellator_normal = "y";
	static final String Tessellator_addVertex = "a";
	static final String Tessellator_addedVertices = "s";
	static final String Tessellator_drawMode = "u";
	static final String Tessellator_convertQuadsToTriangles = "b";
	static final String Tessellator_hasNormals = "q";
	static final String Tessellator_rawBuffer = "h";
	static final String Tessellator_rawBufferIndex = "r";

	static final String Block = "pb";
	static final String Block_blockID = "bO";

	static final String RenderBlocks = "vl";
	static final String RenderBlocks_renderBottomFace = "a";
	static final String RenderBlocks_renderTopFace = "b";
	static final String RenderBlocks_renderEastFace = "c";
	static final String RenderBlocks_renderWestFace = "d";
	static final String RenderBlocks_renderNorthFace = "e";
	static final String RenderBlocks_renderSouthFace = "f";
	static final String RenderBlocks_renderBlockByRenderType = "b";
	static final String RenderBlocks_renderBlockByRenderType_sig = "(Lpb;III)Z";

	static final String World = "xd";
	static final String World_getStarBrightness = "h";

	static final String RenderLiving = "fe";

	static final String WorldRenderer = "ct";
	static final String WorldRenderer_updateRenderer = "a";

	static final String GLAllocation = "ew";
	static final String GLAllocation_createDirectByteBuffer = "c";
}