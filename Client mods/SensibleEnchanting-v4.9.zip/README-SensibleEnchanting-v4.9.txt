Sensible Enchanting v4.9
for Minecraft 1.2.5 (SSP)

by FifthWhammy

New in v4.9:  1.2.5 compatibility!  That's all for now.  ;)

New in v4.8:  1.2.4 compatibility!  Also, turning off reversal item damage actually works now.  I mean it this time, I promise!  Thanks to DarkWerr for the bug report.

New in v4.7:  1.2.3 compatibility!  Also fixed a couple readme typos.  That's all for now. ;)

New in v4.6:  Bugfix release.  Turning off reversal item damage actually works now.  (Before, it would actually increase durability loss instead!)  Thanks to Renegrade for the bug report.

New in v4.5:  1.1 compatibility!  Some of the more powerful enchantment effects--Protection, Sharpness, Fortune, Silk Touch, and Infinity--now cost more XP to repair.  These repair cost balancing changes can be turned off in the settings file if you don't like them.  If you want to turn off the item damage side effect of reversal, you can do that now too.  Additionally, you may now reverse an enchantment even if you won't get any XP back.

--------
Overview
--------

This minor, customizable mod is intended to take away some of the annoyances you might experience while enchanting items in Minecraft 1.2.5.  Specifically:

- By default, all enchantment costs are halved, rounded down.  (You may adjust this or turn it off using a custom settings file--see below.)  A level 50 enchantment now only costs 25 experience levels, a level 15 enchantment now only costs 7 experience levels, and so on.  (Minimum cost is 1 experience level, so no free level 1 enchantments.)  The enchant window still displays the enchantment's power, but the new cost is visible as well.  You'll still need 30 bookshelves for the maximum power of 50.

Why?  Because as it stands now, getting the 50 XP levels for a max enchantment requires you to kill 925 hostile mobs without dying or enchanting anything else.  Frankly, I think that's ridiculous.  In my opinion, high level enchantments shouldn't be limited to those willing to construct mob grinders and stand in one place whacking mobs for hours.  In comparison, reaching XP level 25 requires 244 hostile mob kills, which seems more reasonable.

- You may now increase and decrease the levels of the available enchantments at will!  When you place a valid item on an enchantment table, plus and minus buttons will appear at the top right of the GUI.  Click them to increase or decrease the slots' enchantment levels by 1; shift-click them to increase or decrease the levels by 10 instead!  For convenience, the third enchantment slot will always start with a maximum power enchantment.  Note that you cannot increase the enchantment level beyond the table's capability, so you'll still need bookshelves.

Why?  Because currently, anyone who wants a certain level has to sit at the enchantment table and drop the item on it over and over and over again, and what fun is that?

- High level enchantments are now more likely to produce multiple effects!  For instance, the average level 50 enchantment on a diamond sword would receive multiple effects about 56% of the time.  With Sensible Enchanting, that chance is increased to over 70%!  Note that low level enchantments (and checks for third and fourth effects) receive a much smaller benefit.  If you prefer, this bonus may be adjusted or turned off using a custom settings file.

Why?  Because having almost half of highest level enchantments be single-effect seems a bit too weak to me.

- If you enchant an item and are disappointed with the enchantment--say, Knockback II on a level 50 diamond sword--you can immediately reverse the enchantment to recover 80% of the levels you spent!  (You may adjust this or turn it off using a custom settings file.)  Once you enchant an item, a red reversal slot will appear with the number of levels you can regain displayed in yellow.  If, after seeing how your item turned out, you elect to reverse the enchantment, the just-enchanted item will revert to normal and you'll regain those levels!  However, due to the strain placed on the item, some of its durability will be lost depending on the strength of the original enhancement.  (In v4.5, this can now be turned off in the settings file.)  Furthermore, reversal is a one-time opportunity--if you take the item from the table, the enchantment becomes final and you won't get another chance to recover your XP.  Choose wisely!

Why?  Because if you don't get a satisfactory result, you shouldn't have to earn all of those levels again just for another shot.  Although enchanting is random by nature, you deserve to be rewarded for your work.

- At any enchantment table, you can now repair enchanted items for a modest XP cost.  (If you prefer, you may disable enchanted item repair or modify the XP cost for repairs using a custom settings file--see below.)  The exact cost varies depending on the number of enchantments and the strength of each individual enchantment, but is not affected by the item's type, material, or remaining durability.  With the default settings, some enchantment effects add more to the XP costs than others.  To repair an enchanted item, simply place it on any enchantment table, and a blue repair slot will appear with the XP cost displayed.  (You'll also see the repair slot just after you enchant an item.)  However, just as with normal repairs, you'll need to use another item of the same type and material, although this item does not have to be enchanted.  After placing that item in the new component space, click the repair slot to add durability back to your enchanted item for the cost of your component item and some XP.  Note that attempting to repair enchanted items using a standard crafting grid will still result in the loss of the enchantment, so make sure to do your enchanted item repairs at an enchantment table!

Why?  Because enchanted items are meant to be used, after all.

- Bookshelves are no longer obstructed by objects in between them and the enchantment table.

Why?  Because some players get confused when they have 30 bookshelves but aren't getting maximum level enchantments because of an errant torch, ladder, or sign.  (If you prefer Minecraft's original bookshelf-counting algorithm, you can reactivate it using a custom settings file.)

------------
Installation
------------

Like most other mods, installation is simple:  open your minecraft.jar, drop in the .class files included, and copy the new SEenchant.png file into the jar's gui folder.  Delete the jar's META-INF folder if you haven't already.  That's it!

Sensible Enchanting is designed for maximum compatibility with other Minecraft mods, overwriting only one base class--the enchantment table block.  Most mods that don't modify the enchanting system or the enchanting table block, including TooManyItems, SinglePlayerCommands, and practically all ModLoader mods, can be used alongside SE.  However, since SE uses a separate enchantment GUI, inventory mods and GUI mods such as Customizible Inventory may not be able to modify it.  (All other GUIs should be changed as expected.)

If you're using a texture pack with custom GUIs, SE's variant of the enchantment GUI won't match your texture pack.  Unfortunately, I can't do much about this--I'm a modder, not a magician.  Of course, you're welcome to modify or replace SEenchant.png for use with your texture pack.

---------------
Custom Settings
---------------

With the optional custom settings file (SensibleEnchanting.txt), you can disable enchanted item repair or alter the enchantment and repair cost modifiers.  Place SensibleEnchanting.txt in your .minecraft directory (where lastlogin and options.txt are found) and modify it to suit your tastes.  (The settings file is annotated, so reading it will tell you what sorts of settings are available and what they do.)  If you don't install the custom settings file, Sensible Enchanting will use the default values.

If you already have a custom settings file from an earlier version of SE, you can safely keep using it without issue.  SE will just use the default values for any new settings that your old file doesn't define.

------------------------------
Odds and Ends, But Mostly Ends
------------------------------

Special thanks to the fine fellows (http://mcp.ocean-labs.de/index.php/The_MCP_Team) responsible for Minecraft Coder Pack (http://mcp.ocean-labs.de/index.php/Main_Page).  If you'd like to get started with your own Minecraft mods, MCP's a great way to start.

Disclaimer:  This Minecraft modification was created by FifthWhammy, who does not own the rights to Minecraft or Minecraft source code.  (That's Mojang AB, not me.)  You may distribute this modification freely as long as credit is given and this README file is also included.  Neither I nor Mojang are responsible for any damage, distress, or data loss suffered by you, the user of this modification.  Use at your own risk.  Batteries not included.