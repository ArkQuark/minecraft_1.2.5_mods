HOW TO INSTALL

Install ModLoader and Forge API -->IN THAT ORDER<--
Put the Explosives+ v3.3.jar into your minecraft/mods folder
Put the nuke folder into the resources/newsound folder

The configs will auto-generate in /minecraft/config under Explosives+.cfg and Explosives+IDs.cfg

DISCLAIMER: I WILL NOT BE HELD RESPONSIBLE FOR THE ACCIDENTAL REGENERATION OF WORLDS USING THE GENESIS BOMB. EXERCISE DISCRETION!

Copyright 2012 Pheenixm all rights reserved
Post error logs on the forum, see troubleshooting section for further help.

BLOW SHI† UP!