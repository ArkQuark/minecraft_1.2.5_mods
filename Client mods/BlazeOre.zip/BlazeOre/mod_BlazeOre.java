package net.minecraft.src;
import java.util.Random;

public class mod_BlazeOre extends BaseMod
{
	public static final Block KevinBlazeOre = new BlockBlazeOre(200,0).setHardness(2.0F).setResistance(1.0F).setBlockName("KBlazeOre").setLightValue(1.0F);
	public mod_BlazeOre()
	{
			ModLoader.registerBlock(KevinBlazeOre);
			KevinBlazeOre.blockIndexInTexture = ModLoader.addOverride("/terrain.png","/BlazeOre.png");
			ModLoader.addName(KevinBlazeOre, "Blaze Ore");
		
	}
	
	public void generateSurface(World world, Random rand, int chunkX, int chunkZ)
	{
		for (int i=0; i <0.5; i++);
		{
			int randPosX = chunkX + rand.nextInt(2);
			
			int randPosY = rand.nextInt(16);
			
			int randPosZ = chunkZ + rand.nextInt(2);
			
			(new WorldGenMinable(KevinBlazeOre.blockID, 50)).generate(world, rand, randPosX, randPosY, randPosZ);
		}
	}

	public String getVersion()
	{
		return "3.14159265";
	}
	public void load()
	{
		
	}
}
