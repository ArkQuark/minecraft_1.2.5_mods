Automated Installation

1. Unzip ********.zip by clicking Extract to *******/
2. On windows open InstallWindows.bat on mac open EasyModInstaller.jar with java
3. Click Install
4. If it asks you if you want to delete META-INF say "yes"
   If it asks you if you want to install Modloader say "no"
   If it asks you if you want to install AudioMod say "no"
5. Close the installer
6. Open Minecraft and ENJOY!
