To Install:

1) Download Modloader(http://www.minecraftforum.net/topic/75440-v100-risugamis-mods-everything-updated/) and ModloaderMp(http://www.minecraftforum.net/topic/182918-181-100smp-flans-mods-planes-ww2-guns-vehicles-playerapi-moods-mputils-teams/#MLM). If you are setting up a server to run this, download both the server and client versions. Otherwise you only need the client version.

2) Download the lastest version of the Quidditch mod (see link above).

3) Navigate to your .minecraft folder (in Start type %appdata% then hit enter)

4) Navigate to .minecraft/bin and open minecraft.jar using winrar, winzip, or another archiving program

5) Drag the files from the modloader folder into minecraft.jar, then do the same with the files from modloadermp client folder, and then the same with the files in the Quidditch mod/client folder

6) Delete the folder titled META-INF from minecraft.jar

7) If you are setting up a server: open the minecraft_server.jar file and drag the contents of modloadermpserver inside, then do the same with the contents of the Quidditch mod/server folder

8) Run minecraft and enjoy

Mod made by: Justintib
Minecraft made by: Mojang
Harry Potter made by: J. K. Rowling
Several textures made by minecraftforum user musicdudez