=========================
Installation:
=========================

1. Go to your minecraft folder. (If you don't know how to, look it up)
2. Extract the "portalgun" folder in the zip archive into the /mods/ folder. (DO NOT place the zip in that 
   folder)
3. If you want to change a setting (eg: a block id), go to /mods/portalgun/ and open mod_PortalGun.properties
   with your favourite text editor.

Note:
- The mod requires Forge 3.3.8.164 or later.
- If you are installing Optifine, do it AFTER Forge.
- The mod DOES NOT auto resolve ID issues like some other mods.
- Do check the default properties file, enough comments have been added for your understanding.
- A regenerated properties file will not have the comments!
- Also do check the FAQ before asking a question to see if it has already been answered. Questions answered
  in the FAQ are normally ignored!

=========================
Known issues:
=========================

- If your screen turns black or freezes when there's a portal around, disable see through portals 
  as that is causing the issue.
- See through portals are NOT PERFECT. This means there may be conflicts with other GUIs and such.
  If the issues caused by it are unbearable, turn it off or set to static image.
- Advanced OpenGL being enabled causes flickering issues with see through portals.
- The sky will flicker while you're in your inventory and looking at a see through portal.
- Certain Intel cards do not support see through portals.
- Seperate mod part loading is still experimental. If there's issues do not hesitate to let me know.
- Thermal Discouragement Beams do not render with optifine installed. I Am not sure why.

=========================
Others:
=========================
Mod made by iChun, more info can be found here:
- http://www.minecraftforum.net/topic/199391-/

Donations also appreciated!
- http://bit.ly/zJfKIo