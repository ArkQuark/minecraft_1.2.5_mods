Installation:
1. Go to the .minecraft/bin directory and backup your minecraft.jar
2. Using 7zip or WinRar, open minecraft.jar in an archive
3. Delete the META-INF folder
4. Copy the "pb.class" file contained within the mod to minecraft.jar, replacing the existing file.
5. Close minecraft.jar
6. Enjoy!