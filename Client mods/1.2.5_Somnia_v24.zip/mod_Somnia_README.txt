+-----------------------------------------------------------------------------+
|                             [v1.2.5] Somnia v24                             |
|              http://www.minecraftforum.net/topic/162771-somnia              |
+-----------------------------------------------------------------------------+

REQUIREMENTS
============
Minecraft Client 1.2.5
ModLoader 1.2.5
(Optional) Minecraft Forge


INSTALLATION
============
   ModLoader only
   --------------
   1. Install Mod Loader into your minecraft.jar file.
      http://www.minecraftforum.net/topic/75440-risugamis-mods/
   2. Run Minecraft and make sure it still works.  If not, reinstall Mod Loader
      and make sure you didn't miss any steps (like removing the META-INF
      folder).
   3. Copy the contents of the Somnia ZIP into your minecraft.jar.
   4. Enjoy!

   ModLoader + Minecraft Forge
   ---------------------------
   1. Download Mod Loader and Minecraft Forge and install both it into your
      minecraft.jar file.
      http://www.minecraftforum.net/topic/75440-risugamis-mods/
	  http://www.mod-buildcraft.com/forums/topic/forge-downloads/
   2. Run Minecraft and make sure it still works.  If not, reinstall Mod Loader
      and Minecraft Forge and make sure you didn't miss any steps (like
	  removing the META-INF folder).
   3. Copy the Somnia ZIP into .minecraft/mods.
   4. Enjoy!

   
CONFIGURATION
=============
Open .minecraft/config/mod_Somnia.cfg in a text editor to see the options.


FEATURES
========
This mod replaces the behavior of Minecraft's bed in a number of ways.  Most of
these changes only apply to single-player.

Normal: If you activate a bed, you go to sleep immediately.
Somnia: If you activate a bed, you are presented with a confirmation dialog
        before you sleep.

Normal: You can only sleep at night.
Somnia: You can sleep at any time.

Normal: Only time progresses while you are sleeping.  Nothing in the world
        changes.
Somnia: The world is simulated while you are sleeping.  Time passes, crops and
        trees grow, smelting continues, monsters and animals are active, and
        dropped items decay.

Normal: Sleep is more or less instantaneous.
Somnia: Sleep takes some time because the world is being simulated.

Normal: Sleeping resets your spawn point.
Somnia: Sleeping only resets your spawn point if "Reset Spawn" is set to "Yes".

Normal: If you sleep within 2 blocks of an "unsafe area," there is a random
        chance that a monster will spawn on you and interrupt your sleep.
Somnia: Monsters spawn normally and are active while you sleep.  They may
        still interrupt you, but only if they actually reach you and damage
        you.

Normal: If a monster interrupts your sleep, no time passes.
Somnia: Time passes continuously until you wake or are interrupted.

Normal: You automatically wake at dawn.  You cannot manually wake.
Somnia: You automatically wake at dawn or dusk, whichever is next in the
        day/night cycle.  If you have a Clock, you can wake automatically at
        several points throughout the day.  You can wake up manually at any
        time.

Normal: You do not regenerate any health while sleeping.
Somnia: You regenerate hearts based on the difficulty setting and the amount of
        in-game time spent sleeping (configurable).
        Peaceful - full hearts instantly
        Easy     - heals 1 heart per "hour"
        Medium   - heals half a heart per "hour"
        Hard     - heals half a heart per 2 "hours"

Normal: You do not grow hungry while sleeping.
Somnia: You lose food based on the difficulty setting and the amount of in-game
        time spent sleeping (configurable).  The rates are reduced if you're at
		full health.
        Peaceful - no food lost
        Easy     - lose half a food per 2 "hours"
        Medium   - lose half a food per 1.5 "hours"
        Hard     - lose half a food per "hour"

Normal: It takes very few hits to disassemble a bed.
Somnia: It takes a few more hits to disassemble a bed so that clicking the GUI
        buttons does not disassemble your bed.

Normal: You can sleep no matter what you're wearing.
Somnia: On Hard difficulty (configurable), you can't sleep if you're wearing
        armor.