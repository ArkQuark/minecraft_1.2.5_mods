-----------------------------------------------------------------


Windows (Tested on Windows 7, may be different for other versions):


-----------------------------------------------------------------


1: Download and install WinRAR


2: Navigate to your .minecraft/bin folder in %APPDATA%


3: Secondary-click "minecraft.jar" and select open with, WinRAR


4: Drag everything inside "jar Files" into minecraft.jar.

5: !!!DELETE META-INF!!!


6: Play Minecraft!



-----------------------------------------------------------------
OS X (Tested effective on Lion and Snow Leopard. Should work just fine on any other version, though:


-----------------------------------------------------------------


1: Open Terminal.app, and copy/paste the following text:



cd ~
mkdir mctmp
cd mctmp
jar xf ~/Library/Application\ Support/minecraft/bin/minecraft.jar



2: Navigate to "mctmp" in your home directory, and drag in everything inside "jar Files" Allow it to replace all files.


3: After you're finished copying, go back to Terminal.app, and copy/paste the following text:



rm META-INF/MOJANG_C.*
jar uf ~/Library/Application\ Support/minecraft/bin/minecraft.jar ./
cd ..
rm -rf mctmp

4: Play Minecraft!
-----------------------------------------------------------------


Linux (Debain and debian derivatives such as Ubuntu, Linux Mint, ElementaryOS, ect. Should also work on Fedora):


-----------------------------------------------------------------


1: Navigate to your home directory, and hit ctrl+h to show hidden files.


2: Still in the home directory, navigate to .minecraft/bin. Secondary click "minecraft.jar" and select "Open With Archive Manager"


3: Drag everything inside "jar Files" into minecraft.jar.


4: !!!DELETE META-INF!!!


5: Play Minecraft!



-----------------------------------------------------------------