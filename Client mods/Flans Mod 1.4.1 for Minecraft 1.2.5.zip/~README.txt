Flan's Mod 1.4 for Minecraft 1.2.5
To install :
Install Modloader
Install ModloaderMp
Install PlayerAPI
Install TurboModelThingy
Install MinecraftForge
Put this zip in the "/.minecraft/mods/" folder.
Get some content packs from my mod page
http://www.minecraftforum.net/topic/182918-/