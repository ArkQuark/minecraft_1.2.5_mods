You have downloaded Italian Food 2.1.2!

2.1.2 Change List:
*Fixed plant generation, made them form in groups.
*Removed 4 non-essential class files.

INSTRUCTIONS:

Thank you for downloading Italian Food 2.1.2!

INSTRUCTIONS FOR INSTALLING ITALIAN FOOD 2.1.2:
***
I expect you to have already installed ModLoader 1.2.4
***
There will be one file:
1. Jar

PC:
AFTER INSTALLING MODLOADER:
Click on the 'Start' menu, and click run.  In run, type in, "%appdata%". From there, locate the .minecraft folder, and open up bin.  Using WinZip (or some other unarchiver), open up the minecraft.jar file and place all the files in 'Jar' into it.  You can close out of all these windows now.  Run the game and you should be good to go!
***
Mac:
AFTER INSTALLING MODLOADER:
In finder, on the top toolbar, click on the 'Go' drop-down menu and then click 'Go to Folder.'  In that text box, type in "/Users/<username>/Library/Application Support".  Please note to type in your computer's user in the place where I said '<username>'.  From there, locate your 'minecraft' folder, and after opening it click 'bin'.  Locate the file "minecraft.jar", and rename it "minecraft.jar.zip".  Double click the renamed file and then you should see a new file called "minecraft.jar".  Throw away the .zip file and open up the new 'minecraft.jar' file.  Drag all the files in "Jar" into this folder.  Yay, you're finished!  Close out of all these windows now, and run minecraft.  You should be good to go!

NOTE:
Be sure to not place the mod's entire folders into the specified minecraft ones, only place the included files. 
***
THIS MOD WORKS WITH ALL OTHERS I HAVE TESTED.  If there is an incompatibility, message me.

If it doesn't work, please contact me at aidancbrady@yahoo.com.

Thank you for installing!

