=Thanks for using EnderBro+=

To install this mod simply do the following:

Step 1: Download Modloader. Download ModloaderMp. Download MinecraftForge.(Skip step 2 if you already have winrar)

Step 2: Download Winrar and install it.

Step 3: Open Modloader.zip, ModloaderMp.zip and MinecraftForge.zip with Winrar.

Step 4: press the start/windows button in the bottom left corner and in the search bar type %appdata% . if you are on windows xp goto run and type %appdata% .

Step 5: Goto .minecraft then goto bin.

Step 6: Right click minecraft or minecraft.jar and click open with then click winrar archiver.

Step 7: in minecraft.jar delete the META-INF folder.(MUST DO THIS OR YOU CANT USE THE MOD. IT WILL BLACK SCREEN.)

Step 8: Drag all of the files from Modloader.zip, ModloaderMp.zip and MinecraftForge.zip into the minecraft.jar

Step 9: open EnderBro+.zip with winrar and drag all the class files and the enderbro folder into the minecraft.jar

Step 10: close winrar.

Step 11: Play Minecraft.

Step 12: Enjoy!

=============================================================================================================================================================
Remember to report bugs or any ideas to LouD_NinJa.

Thank Sir_tiffy for first Creating the mod.
