More Health ENHANCED! 1.0

For Minecraft 1.2.5

New in V1.0:
-Mod revamp/consolidation. Combined More health RPG and Classic.
-Updated config file to allow the user to customize a lot of settings, like:
	-RPG mode only
	-heart containers and heart pieces only
	-Max health variable
	-Enhanced mode (both rpg and heart containers)
-Updated and made the default level ramp more difficult and cap at 30 hearts.
-Increased cap to 30 hearts, as requested.
-included finding heart containers/pieces in dungeon chests and patched the ender dragon to drop 3 heart containers.

ModLoader required!
Links in my thread on the forum

---------------------------------------
Installation Instructions
---------------------------------------
1. Install Modloader

Now, for my mod:

1.Go to %appdata%/.minecraft/bin/minecraft.jar

2.Drag the class files and the "moreHealth" folder into the minecraft jar. Basically Copy & Paste EVERYTHING in the folder " into your minecraft.jar (besides the readme and the crafting picture!)


3. Delete the Meta-inf folder.


4. Run minecraft, enjoy! :D

5. Any questions/suggestions, post in the thread!

**Find heart pieces and containers in dungeon chests. Ender dragon drops 3 heart containers!
*some mods have heart item functions. I remember tales of kingdom sold them. 
*You can edit the config in better dungeons to add heart containers and pieces


Backup your minecraft jar! Might conflict with other mods!

--------------------------------
Configuration File.
--------------------------------

How to:

1. Start up minecraft with this mod.

2.Shut down Minecraft.

3.Open %appdata%/.minecraft/config/mod_moreHealthRPG.cfg with a program like notepad. (Note you have to run minecraft once after installing mod for this file to pop up).

4.Do not edit the lines starting with #! they are just comments!
You have two things you can configure yourself, anyway you want!

LevelRamp=1,3,5,6,7,8... (Set the levels you want to gain hearts on! <default> below)
StartingHearts=20 (change the starting hearts, from 1 to 20), default 10. 

5. Start Minecraft, enjoy! These config settings will affect ALL your worlds.



More health RPG:

Level Up to gain more health!

You get hearts based on this <default> ramp:

Lvl 1: Gain 1 Heart, 11 hearts total
Lvl 4: 12 hearts total
Lvl 8: 13 
lvl 12: 14 
lvl 16: 15 
lvl 20: 16 
lvl 24: 17 
lvl 28: 18 
lvl 32: 19 
lvl 36: 20 
lvl 40: 21 
lvl 45: 22 
lvl 50: 23 
lvl 55: 24 
lvl 60: 25
lvl 65: 26
lvl 70: 27
lvl 75: 28
lvl 80: 29
lvl 85: 30 hearts

When you DIE or if you ENCHANT an item, you lose experience. HOWEVER, you will NOT lose your hearts!
Aka, if you got to lvl 14, you would have 16 hearts. If you die, you would STILL have 16 hearts, but you will have
to work your way up the levels to gain hearts again (aka to get to 17 hearts you have to get to lvl 18.)


