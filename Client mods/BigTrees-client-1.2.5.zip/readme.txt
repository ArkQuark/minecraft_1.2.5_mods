BigTrees (client) 1.2.5
A Minecraft mod by Karob.
Site: http://www.minecraftforum.net/index.php?showtopic=782646

Installation
""""""""""""
1) Backup minecraft and any saves you don't want corrupted. (Suggested)
2) Start with a fresh, new installation of Minecraft 1.2.5. (May not be
   necessary.)
3) Open minecraft.jar and BigTrees-client-1.2.5.zip with an appropriate archiver.
4) Copy all files (except readme.txt) directly from the "jar" folder of
   BigTrees-client-1.2.5.zip to minecraft.jar.
5) Delete the folder "META-INF" in minecraft.jar.
6) If you want to be able to change the configuration file, copy
   kbigtrees.txt to the '.minecraft' folder.
6) Play Minecraft!

You may be asking one of the following questions:
- Where is minecraft.jar?
    Start Minecraft. Click "Mods and Texture Packs". Click "Open texture pack
    folder". Now go up one directory. In Windows, that means press backspace.
    In Linux, it's Alt+Up. That should put you in the ".minecraft" folder.Now
    double-click on the "bin" folder. And you should see minecraft.jar.
- What is an appropriate archiver?
    In Windows, 7-Zip is a good free one. Not all free archivers will work
    properly, but 7-Zip has worked every time for me. In Linux everything
    seems to work fine. :)
- Is this compatible with other mods?
    It is compatible with some mods. It really depends on what classes are
    modified and how critical they are. If you want to try this mod with
    another, try installing one of them first. If that doesn't work, try
    installing the other first. Further down is a list of possibly
    compatible mods.

Features
""""""""
- Big trees added to different biomes:
   * Most biomes have Great Oak, Thick Pine, Block Oak, and Post Oak.
   * Desert has big dead trees. It may not make sense, but it looks cool. :)
   * Swamp biome has Great Swamp Oak, Cyprus, and Hat Trees.
   * Taiga biome has Thick Pine in some regions.
   * The classic birch and pine trees are taller.
   * Jungle trees are taller and have longer branches.
- Roots from some trees grow through ground, sometimes into caves.
- Place sapling and blocks in patterns to choose what sort of tree grows there. (See below)
- Config file 'kbigtrees.txt' allows for changing many things.
- New look, same great taste!

Tree Growth Guide
"""""""""""""""""
To grow a tree of any of these types, place saplings and wood blocks in these
patterns. There must be an air block over each wood block. The wood blocks
must be the same elevation as the sapling.

    [o = sapling (any type), w = wood (any type)]

        w w                             w w w w
      w w w w      w w         w        w w w w
      w w w w      w w           o      w w w w
        w w o          o                w w w o
      -------    -------  ---------    ---------
     great oak  block oak  post oak    swamp oak

              w      w     w     w w
            w w w      w w     w     w
              w o      w w     w     w
                     w     o     w w o
          --------   ------   ---------
         thick pine  cyprus    hat tree

Two new patterns added by request:

       w
       w             w
       w             w
 w w w o w w w   w w o w w
       w             w
       w             w
       w
--------------   ---------
 7x7 hat tree   5x5 hat tree


Cool Compatible Mods
""""""""""""""""""""
These might still work with BigTrees. (Some may not be updated yet.)
  Tale of Kingdoms (you have a role to play and a kingdom to build!)
    http://www.minecraftforum.net/index.php?showtopic=751960
  Twilight Forest (an amazing new ethereal dimension!)
    http://www.minecraftforum.net/index.php?showtopic=561673
  Huge Trees Are Huge (they really are huge.)
    http://www.minecraftforum.net/index.php?showtopic=680540
  Height Mod (makes minecraft world much taller.)
    http://www.minecraftforum.net/index.php?showtopic=544429
  Premium Wood (it's not just wood, it's /premium/ wood!)
    http://www.minecraftforum.net/index.php?showtopic=228940
  Timber Mod (oh my goodness there's a billion wood blocks on the ground.)
    http://www.minecraftforum.net/index.php?showtopic=119361
  Mountain Gen Mod (makes Minecraft more... bumpy?)
    http://www.minecraftforum.net/index.php?showtopic=827699
  Extra Biomes (all the world needs is a few extra biomes.)
    Download the ALTERNATE version!
    http://www.minecraftforum.net/index.php?showtopic=907403
  Mo' Creatures (has goats!)
    http://www.minecraftforum.net/index.php?showtopic=81771
  Millenaire (has people!)
    http://www.minecraftforum.net/index.php?showtopic=227822
  IndustrialCraft2 (has its own website!)
    http://forum.industrial-craft.net/
  Nandonalt's More Trees, ported by Coupon (More trees!)
    http://www.minecraftforum.net/index.php?showtopic=658494
  Wedge (The WorldGen Editor!)
    http://www.minecraftforum.net/index.php?showtopic=1077039
  Possibly: Trees++, Meteor Mod, Clay Soldiers, Powercraft, Uranium Mod,
    Useful Chest, StickyTNT, Rei's Minimap, SSP Commands, More Piston Mod,
    Too Many Items...


Contact
"""""""
If you have any questions, you can find me on the official Minecraft forums as
"Karob". I'll probably respond to your question within 12 years. :)

